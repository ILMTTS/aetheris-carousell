# Carousell 自動上架工具

這個工具把「放產品圖片」變成 Carousell 商品草稿。每個產品使用一個子資料夾：

```text
Carousell自動上架/
├─ 待發布/
│  └─ 黃色熊耳帽貓咪/
│     ├─ 01.png
│     └─ 02.png
├─ config.json
└─ carousell_publish.py
```

子資料夾名稱會作為商品標題。圖片會先做 EXIF 方向校正、限制尺寸並整理成適合上傳的 PNG，再上傳到 Carousell。支援 JPG、PNG、WEBP、BMP、GIF、TIFF、ICO、TGA、PPM、PGM、PBM 和 PNM；程序會自動將可讀取的格式轉成 PNG。日常操作由獨立狀態網頁控制，發布流程會自動完成。

如果只放一批圖片，也可以直接放在 `待發布` 資料夾；程序會把它們視為一個商品，標題使用 `config.json` 的 `default_title`。

## 第一次設定

1. 雙擊 `一鍵安裝環境.bat`，讓程序自動安裝 Python 3.13+、Python 套件和瀏覽器元件。
2. 將 `config.example.json` 複製成 `config.json`，修改價格、地區和描述模板；商品狀況會一律設為「幾乎全新」。
3. 把產品圖片放進 `待發布\產品名稱\`，或在狀態網頁「未處理」區域一次拖入大量圖片；程序會按檔名的商品編號或名稱分組，沒有可靠線索時再按圖片色塊相似度自動分組。
4. 雙擊 `啟動工具.bat`，日常操作都在狀態網頁完成。

第一次執行會開啟瀏覽器，請在瀏覽器內登入 Carousell；程式不會讀取或儲存密碼。登入狀態會留在 `browser_data`，日後可以直接使用。

如果 Carousell 顯示安全檢查或「Verify you are human」，請在開啟的瀏覽器視窗完成驗證，再回到黑色程序視窗按 Enter；這是網站的安全機制，程序不會代替你處理驗證碼。

程序預設會自動關閉商品頁的「購買」按鈕；如要重新開啟，可在 `config.json` 將 `enable_buy_button` 改成 `true`。

程序預設保留 Carousell 的圖片識別自動填寫，不會用草稿資料覆蓋 Carousell 產生的標題、描述、價格、狀況和類別。上傳圖片後會自動偵測欄位內容是否完成並在穩定後繼續，不再固定等待 10 秒；`carousell_auto_fill_timeout_seconds`（預設 60 秒）只作為頁面沒有回應時的安全上限。如需使用程序自己的欄位填寫，可將 `carousell_auto_fill` 改成 `false`。

對 iPad 類別，Carousell 自動填寫後程序會補選「系列」；「儲存容量」必須在產品的 `商品資料.json` 填入真實值，例如 `"storage": "64GB"`，程序不會自行猜測容量。

自動填寫後如果分類欄位仍然空白，程序會先用 Carousell 自動產生的標題和產品資料夾名稱開啟 Google 圖片參考頁面，而且保留該分頁。程序會給你 `manual_review_seconds`（預設 120 秒）在 Carousell 補填；狀態頁會顯示「跳過這件，處理下一件」按鈕，未按下時時間到會自動跳過並繼續。你手動填妥欄位後，程序會即時偵測並繼續發布。

其他有分類專用欄位的二手商品，也會在出現必填問題時開啟 Google 圖片參考頁面。可在 `config.json` 將 `web_research_enabled` 改成 `false` 停用網上參考；查不到可靠資料時會保留空白並記錄問題，不會用猜測值刊登。

打開 `啟動工具.bat` 時會先啟動本機狀態服務並用普通 Google Chrome 的 `--new-window` 開啟一個獨立狀態視窗。網頁內可以直接按「接管 Chrome 發布」、「打開新 Chrome」、「整理圖片」、「檢查環境」或「一鍵安裝環境」；「打開新 Chrome」只會開啟瀏覽器，不會開始發布。在「未處理」區域可以一次拖入大量圖片，程序會先按檔名中的商品編號或名稱分組，再用圖片的主色塊比例和構圖相似度整理沒有可靠檔名線索的圖片，不需要使用者先計算每件商品有多少張圖片。右側會同步列出已處理、正在處理和未處理的檔案，每個有名稱的商品會顯示該資料夾第一張原始圖片的小縮圖。未處理商品左側的 🗑 按鈕會把商品資料夾移到 `已刪除檔案`（可從該資料夾找回），旁邊的「手動填寫」會只開啟該商品的 Carousell 預覽頁，保留自動填寫但不會發布，也不會移動原始圖片。若不需要狀態頁，可將 `status_dashboard_enabled` 改成 `false`。

如果重複開啟工具後留下多個隱藏背景程序，可按主畫面的「清理背景程序」。它只會關閉命令列明確包含 `carousell_publish.py` 的本程序 Python 工作，保留目前狀態頁和其他 Chrome、Python 或應用程式不受影響。

按「打開新 Chrome」會啟動一個已開啟遠端接管功能的普通 Chrome 視窗，方便你先登入或檢查 Carousell；完成後按「接管 Chrome 發布」即可開始處理，不需要另外執行開啟 Chrome 批次檔。

如果 Carousell 顯示必填欄位或驗證問題，程序會把商品名稱和問題記錄在狀態頁下方，並在商品名稱旁加上紅色警告標記；下次按「接管 Chrome 發布」時，曾出錯的商品會自動排到最後，讓其他商品先處理。成功發布或判定重複後會清除標記。程序仍會跳過問題商品並繼續處理下一件，不會停住整批流程。

整批工作完成後，狀態頁會彈出動畫摘要，顯示已完成、跳過重複和需要留意的商品數量。

發布模式會在同一個 Carousell 分頁自動偵測自動填寫完成，完成後關閉「購買」按鈕，並在真正按下「立即刊登」前再次檢查「我的刊登商品」，確認沒有同款才會發布。程序會自動按下「立即刊登」，等待成功頁面或帳戶回查確認成功後，才在同一分頁處理下一件商品，不需要最後手動按鈕。如需在發布前額外等待，可在 `config.json` 增加 `publish_wait_seconds`；預設為 0。舊版 `require_publish_confirmation` 設定會被保留但不再讓流程停下來。

新電腦可以雙擊 `一鍵安裝環境.bat`，程序會嘗試安裝 Python、Python 套件和 Playwright 瀏覽器元件。手動下載網址：

- Python：https://www.python.org/downloads/windows/
- Google Chrome：https://www.google.com/chrome/
- Playwright 說明：https://playwright.dev/python/docs/intro

日常使用只需雙擊 `啟動工具.bat`，然後在狀態網頁按按鈕，不需要在終端機輸入指令。 狀態頁的時間欄會顯示整批商品從開始到完成的預計總時間，完成後顯示本次實際總耗時。

主畫面下方的「測試功能」包含三個帳戶操作：`刪除全部已刊登`、`開啟未開啟的購買按鈕` 和 `關閉所有已開啟的購買按鈕`。這三個按鈕不屬於一般發布流程，會逐件操作 Carousell 帳戶內容；使用前請先確認登入帳戶，並閱讀彈出的確認提示。

如果要直接使用普通 Chrome 裡已開啟的 Carousell 頁面：先雙擊 `開啟可接管Chrome.bat`，在該 Chrome 登入並開啟 Carousell；再雙擊 `啟動工具.bat`，在狀態網頁按「接管 Chrome 發布」。程序會建立一個持續的接管連線，優先重用你已開啟的 Carousell 分頁，整批商品都在同一頁完成自動填寫、檢查和發布；完成後只斷開控制連線，不會關閉你的 Chrome 分頁。一般已經開啟但沒有遠端控制的 Chrome，程序無法直接接管。

程序現在預設使用電腦安裝的普通 Google Chrome（`browser_channel: "chrome"`），不再使用 Playwright 測試版 Chrome。如果 Carousell 使用 Google 登入，Google 仍可能拒絕自動化登入並顯示「目前無法登入帳戶」；這時請改用 Carousell 的電郵／手機登入。程序不會繞過 Google 驗證或安全檢查。

如果不同產品需要不同價格或描述，可以在產品資料夾加入 `商品資料.json`：

```json
{
  "title": "黃色熊耳帽貓咪玩偶",
  "price": 299,
  "condition": "Like new",
  "category": "Toys & Games",
  "series": "",
  "storage": "",
  "description": "保存良好，圖片為實物拍攝。",
  "brand": "",
  "location": "Hong Kong",
  "delivery": "Meet-up / Delivery"
}
```

若分類是 iPad 等有額外必填欄位的類別，請在同一個 `商品資料.json` 填寫網站要求的值，例如 `"series": "iPad"` 和 `"storage": "64GB"`。儲存容量必須按照實物資料填寫，不能留空；程式會自動點選對應的自訂選項。

這個檔案只會覆蓋該產品的設定，其他產品仍使用 `config.json`。

每次執行完成後，程序會在本資料夾產生 `last_run.json`，記錄成功和失敗的產品。某個產品出錯時，其他產品仍會繼續處理。

發布模式開始時會只開一次清單頁掃描全部未處理商品，在已登入的 Carousell 帳戶「我的刊登商品」清單中，比對商品標題和已刊登圖片；每件商品真正發布前也會再檢查一次。如果標題不同但圖片相同，也會判定為同款，跳過發布並把原產品資料夾移到 `已完成檔案`。新商品成功刊登後，原產品資料夾也會移到 `已完成檔案`，避免下次再次處理。終端機會顯示「正在檢查帳戶現有刊登」及檢查結果；重複項目會記錄在 `last_run.json` 的 `duplicates`。

## 發布模式

```powershell
# 預設：只建立草稿並停在商品頁
py carousell_publish.py

# 填完後逐一詢問是否按發布
py carousell_publish.py --publish

# 只處理指定產品資料夾
py carousell_publish.py --product "黃色熊耳帽貓咪"

# 只整理圖片和建立 draft.json，不開啟瀏覽器
py carousell_publish.py --prepare-only

```

Carousell 網頁欄位可能因地區、帳號或網站更新而不同；如果找不到某個欄位，程式會保存已整理好的圖片和 `draft.json`，並顯示需要手動完成的欄位。驗證碼、安全提示和登入一定由使用者自行處理。
