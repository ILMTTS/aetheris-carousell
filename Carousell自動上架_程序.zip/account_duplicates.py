"""Read-only account photo index. Match the SAME PHOTO, not a similar product.

All local originals are checked, independently of the ten-photo upload limit.
An incomplete account scan is never permission to publish an unchecked group.
Only links harvested from the signed-in account's management page are followed.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from io import BytesIO
from pathlib import Path
import re
from urllib.parse import urlsplit, urlunsplit

from PIL import Image, ImageOps, ImageStat


class DuplicateScanIncomplete(RuntimeError):
    pass


def listing_key(url: str) -> str:
    parts = urlsplit(url)
    # A listing keeps its identity when its title/query changes.
    match = re.search(r"(?:-|/)(\d{6,})/?$", parts.path)
    return match.group(1) if match else urlunsplit((parts.scheme, parts.netloc, parts.path.rstrip('/'), '', ''))


def is_carousell(url: str) -> bool:
    host = (urlsplit(url).hostname or '').lower()
    return bool(re.fullmatch(r"(?:[a-z0-9-]+\.)*carousell\.(?:com(?:\.[a-z]{2})?|sg|hk|ph|my|tw)", host))


@dataclass(frozen=True)
class View:
    gradient: int
    pixels: bytes
    contrast: float


@dataclass(frozen=True)
class Photo:
    digest: str
    views: tuple[View, ...]


def fingerprint(data: bytes) -> Photo:
    """EXIF/alpha aware; the square view handles CDN cover-thumbnail crops."""
    with Image.open(BytesIO(data)) as original:
        image = ImageOps.exif_transpose(original).convert('RGBA')
        rgb = Image.new('RGB', image.size, 'white')
        rgb.paste(image, mask=image.getchannel('A'))
        rgb.thumbnail((384, 384), Image.Resampling.LANCZOS)
        views = []
        for source in (rgb, ImageOps.fit(rgb, (256, 256), method=Image.Resampling.LANCZOS)):
            gray = source.convert('L').resize((17, 16), Image.Resampling.LANCZOS)
            values = gray.tobytes()
            gradient = 0
            for y in range(16):
                for x in range(16):
                    gradient = (gradient << 1) | (values[y * 17 + x + 1] > values[y * 17 + x])
            small = source.resize((32, 32), Image.Resampling.LANCZOS)
            views.append(View(gradient, small.tobytes(), ImageStat.Stat(small.convert('L')).stddev[0]))
    return Photo(sha256(data).hexdigest(), tuple(views))


def same_photo(left: Photo, right: Photo) -> bool:
    if left.digest == right.digest:
        return True
    for a in left.views:
        for b in right.views:
            # A hash alone merges different white-background toys. Verify
            # spatial RGB pixels as well, with stricter limits for flat photos.
            if (a.gradient ^ b.gradient).bit_count() > 28:
                continue
            limit = min(12.0, max(2.5, min(a.contrast, b.contrast) * 0.22))
            error = sum((x - y) ** 2 for x, y in zip(a.pixels, b.pixels)) / len(a.pixels)
            if error <= limit ** 2:
                # Localised changes (a different face/logo on similar toys)
                # must not disappear into a large white background average.
                largest_patch = 0.0
                for top in range(0, 32, 8):
                    for column in range(0, 32, 8):
                        patch_error = 0
                        for y in range(top, top + 8):
                            start = (y * 32 + column) * 3
                            patch_error += sum((x - z) ** 2 for x, z in zip(a.pixels[start:start + 24], b.pixels[start:start + 24]))
                        largest_patch = max(largest_patch, patch_error / 192)
                if largest_patch <= max(6, min(26, limit * 2.5)) ** 2:
                    return True
    return False


@dataclass
class AccountIndex:
    records: list[tuple[Photo, str, str]] = field(default_factory=list)
    listings: set[str] = field(default_factory=set)
    errors: list[str] = field(default_factory=list)
    complete: bool = False
    local_cache: dict = field(default_factory=dict, repr=False)

    def add(self, data: bytes, listing_url: str, image_url: str) -> None:
        self.records.append((fingerprint(data), listing_url, image_url))

    def match(self, paths: list[Path]) -> dict | None:
        """ANY one original matches -> the caller skips the entire group."""
        failures = []
        for path in paths:
            try:
                stat = path.stat()
                key = (str(path.resolve()), stat.st_size, stat.st_mtime_ns)
                local = self.local_cache.get(key)
                if local is None:
                    local = fingerprint(path.read_bytes())
                    self.local_cache[key] = local
                for remote, listing, image in self.records:
                    if same_photo(local, remote):
                        return {'local_image': str(path), 'listing_url': listing, 'account_image_url': image}
            except (OSError, ValueError) as exc:
                failures.append(f'{path.name}: {exc}')
        if failures or not paths:
            raise DuplicateScanIncomplete('無法讀取全部原始圖片：' + '; '.join(failures or ['沒有原始圖片']))
        return None

    def remember_published(self, paths: list[Path]) -> None:
        # A subsequent folder may share only ONE photo with this just-published
        # group. Keep those originals in this run's index before moving files.
        for path in paths:
            self.add(path.read_bytes(), 'published-in-this-run', str(path))

    def summary(self) -> dict:
        return {'complete': self.complete, 'listings': len(self.listings),
                'photos': len(self.records), 'errors': self.errors[:30]}


MANAGEMENT_SCRIPT = r"""() => {
    const root = document.querySelector('main,[role=main]') || document.body;
    const excluded = '[data-testid*=recommend i],[class*=recommend i],[aria-label*=recommend i]';
    const rows = [], seen = new Set();
    for (const a of root.querySelectorAll('a[href]')) {
        if (a.closest(excluded)) continue;
        let u; try { u = new URL(a.href); } catch { continue; }
        if (u.origin !== location.origin || !/\/(p|item|product|listing)\//i.test(u.pathname)) continue;
        u.search = ''; u.hash = '';
        if (seen.has(u.href)) continue;
        seen.add(u.href);
        rows.push({url:u.href, title:(a.innerText || a.getAttribute('aria-label') || '').trim()});
    }
    const body = root.innerText || '';
    const empty = /no listings yet|you (?:have not|haven't) listed|you have no listings|no items yet|沒有任何刊登|尚未刊登|未有刊登|沒有刊登商品|還沒有商品|未有任何商品/i.test(body);
    const busy = !!root.querySelector('[aria-busy=true],[role=progressbar]');
    const buttons = [...root.querySelectorAll('button,[role=button],a')];
    const more = buttons.find(b => /^(瀏覽更多|查看更多|載入更多|加载更多|Load more|View more|Show more)$/i.test((b.innerText || '').trim()) && b.getClientRects().length);
    const next = buttons.find(b => /^(下一頁|下一页|Next|Next page)$/i.test((b.getAttribute('aria-label') || b.innerText || '').trim()) && b.getClientRects().length && !b.disabled && b.getAttribute('aria-disabled') !== 'true');
    const target = more || next;
    root.querySelectorAll('[data-aetheris-scan-next]').forEach(e=>e.removeAttribute('data-aetheris-scan-next'));
    if (target) target.setAttribute('data-aetheris-scan-next', '1');
    const range = body.match(/\b\d+\s*[-–]\s*\d+\s*(?:of|\/)\s*(\d+)\b/i);
    const total = body.match(/(?:My listings|All listings|全部商品|所有商品|我的刊登商品)\s*[(（]\s*(\d+)\s*[)）]/i);
    return {rows, empty, busy, total:Number((range || total || [])[1] || 0), more:!!target, disabled:!!target && (target.disabled || target.getAttribute('aria-disabled')==='true')};
}"""


def management_listings(page, progress=None) -> list[dict]:
    """Load every management page/card, including lazy and paginated lists.

    Keep accumulated rows even on virtual lists. A stalled load-more button,
    login/challenge, unexplained blank page or scan cap is an explicit failure.
    """
    if not is_carousell(page.url) or '/manage-listings' not in urlsplit(page.url).path.lower():
        raise DuplicateScanIncomplete('未能進入登入帳戶的「我的刊登商品」。')
    rows, quiet, stalled = {}, 0, 0
    for turn in range(400):
        snapshot = page.evaluate(MANAGEMENT_SCRIPT)
        before = set(rows)
        for row in snapshot['rows']:
            rows[listing_key(row['url'])] = row
        if progress:
            progress(f'正在載入帳戶全部刊登，已找到 {len(rows)} 件…')
        if snapshot['more']:
            quiet = 0
            if snapshot['disabled']:
                stalled += 1
                if stalled > 10:
                    raise DuplicateScanIncomplete('「瀏覽更多」仍未完成載入，未能確認全部刊登。')
                page.wait_for_timeout(500)
                continue
            old_signature = [(r['url']) for r in snapshot['rows']]
            page.locator('[data-aetheris-scan-next="1"]').last.click(timeout=5000)
            changed = False
            for _ in range(30):
                page.wait_for_timeout(300)
                update = page.evaluate(MANAGEMENT_SCRIPT)
                if [r['url'] for r in update['rows']] != old_signature or (not update['more'] and not update['busy']):
                    changed = True
                    break
            stalled = 0 if changed else stalled + 1
            if stalled >= 2:
                raise DuplicateScanIncomplete('「瀏覽更多」沒有載入下一批商品，檢查尚未完成。')
        else:
            page.evaluate('window.scrollTo(0, document.documentElement.scrollHeight)')
            quiet = quiet + 1 if before == set(rows) and not snapshot['busy'] else 0
            if quiet >= 3 and snapshot['total'] > len(rows):
                raise DuplicateScanIncomplete(f"帳戶顯示 {snapshot['total']} 件，但只讀取 {len(rows)} 件；其餘清單尚未載入。")
            if quiet >= 3 and (rows or snapshot['empty']):
                return list(rows.values())
            if turn >= 25 and not rows:
                raise DuplicateScanIncomplete('帳戶清單沒有完成載入，請確認登入及網站驗證。')
            page.wait_for_timeout(500)
    raise DuplicateScanIncomplete('帳戶清單仍有未讀取商品，這次不會將未確認的商品當作沒有重複。')


GALLERY_SCRIPT = r"""() => {
    const urls = new Set(), expected = [], albumLengths = [], main = document.querySelector('main,[role=main]') || document.body;
    const id = (location.pathname.match(/(?:-|\/)(\d{6,})\/?$/) || [])[1];
    let authoritative = false;
    const add = value => {
        if (typeof value === 'string') {
            try { const u = new URL(value, location.href); if (/^https?:$/.test(u.protocol) && (/media\/photos\/products/i.test(u.href) || /\.(jpe?g|png|webp)(\?|$)/i.test(u.href))) urls.add(u.href); } catch {}
        } else if (Array.isArray(value)) value.forEach(add);
        // This walker is called only on an image/photos field, never an
        // entire listing or recommendation object. Handle resolution maps.
        else if (value && typeof value === 'object') Object.values(value).forEach(add);
    };
    const product = (value, insideList=false) => {
        if (!value || typeof value !== 'object') return;
        if (Array.isArray(value)) { value.forEach(x=>product(x,insideList)); return; }
        const types = [].concat(value['@type'] || []);
        const inList = insideList || types.some(t=>/ItemList|ListItem/.test(t));
        if (types.includes('Product') && !inList) {
            const u = String(value.url || value['@id'] || '');
            const nameMatches = value.name && String(value.name).trim()===(main.querySelector('h1')?.textContent || '').trim();
            if (((u && id && u.includes(id)) || (!u && nameMatches)) && value.image) {
                add(value.image); authoritative = true;
                expected.push([].concat(value.image).length);
                albumLengths.push([].concat(value.image).length);
            }
        }
        for (const [k,v] of Object.entries(value)) if (typeof v === 'object') product(v,inList);
    };
    let budget = 100000;
    const hydrated = (value, objectKey='') => {
        if (!value || typeof value !== 'object' || --budget<0) return;
        if (Array.isArray(value)) {value.forEach(x=>hydrated(x)); return;}
        const keys = ['id','listingId','listing_id','productId','product_id'];
        if (id && (objectKey===id || keys.some(k=>String(value[k] || '')===id))) {
            for (const k of ['images','photos','imageUrls','photoUrls','image_urls','photo_urls']) {
                if (Array.isArray(value[k]) && value[k].length) {
                    add(value[k]); authoritative=true;expected.push(value[k].length);albumLengths.push(value[k].length);
                }
            }
        }
        for (const [k,v] of Object.entries(value)) if(typeof v==='object') hydrated(v,k);
    };
    for (const script of document.querySelectorAll('script[type="application/ld+json"],script[type="application/json"],script#__NEXT_DATA__')) {
        try { const value=JSON.parse(script.textContent);script.type==='application/ld+json'?product(value):hydrated(value); } catch {}
    }
    for (const state of [window.__NEXT_DATA__,window.__INITIAL_STATE__,window.INITIAL_STATE,window.__PRELOADED_STATE__]) {
        try { hydrated(typeof state==='string'?JSON.parse(state):state); } catch {}
    }
    const related = [...main.querySelectorAll('h2,h3,h4')].find(h=>/similar listings|recommended|you may also like|相關商品|相似商品|為你推薦|猜你喜欢/i.test(h.textContent));
    const structuredCount = urls.size;
    for (const img of main.querySelectorAll('img')) {
        if (img.closest('[data-testid*=recommend i],[class*=recommend i],[aria-label*=recommend i]')) continue;
        if (related && (related.compareDocumentPosition(img)&Node.DOCUMENT_POSITION_FOLLOWING)) continue;
        const a=img.closest('a[href]');
        if(a && /\/(p|item|product|listing)\//i.test(a.pathname) && a.pathname!==location.pathname) continue;
        // Structured data is authoritative. Add DOM photos only in a known
        // gallery when present, so an unlabelled recommendation cannot match.
        if(authoritative && !img.closest('[data-testid*=gallery i],[class*=gallery i],[aria-roledescription=carousel]')) continue;
        for(const src of [img.currentSrc,img.getAttribute('src'),img.getAttribute('data-src')]) {
            if(src && /media\/photos\/products/i.test(src)) add(src);
        }
    }
    const gallery=main.querySelector('[data-testid*=gallery i],[class*=gallery i],[aria-roledescription=carousel]') || main;
    const count=(gallery.innerText || '').match(/\b\d+\s*(?:\/|of)\s*(\d+)\b/i);
    if(count) expected.push(Number(count[1]));
    const next=[...gallery.querySelectorAll('button,[role=button]')].find(b=>/^(Next (?:image|photo|slide)|下一張|下一张|下一幅)$/i.test(b.getAttribute('aria-label') || '') && !b.disabled && b.getAttribute('aria-disabled')!=='true');
    gallery.querySelectorAll('[data-aetheris-photo-next]').forEach(e=>e.removeAttribute('data-aetheris-photo-next'));
    if(next)next.setAttribute('data-aetheris-photo-next','1');
    return {urls:[...urls], authoritative, structuredCount, albumLength:Math.max(0,...albumLengths), expected:Math.max(0,...expected), next:!!next, ready:!!main.querySelector('h1')};
}"""


def gallery_urls(page) -> list[str]:
    """Read only the current listing's gallery, never recommendation photos."""
    urls, expected, ready, authoritative, signatures = set(), 0, False, False, set()
    for turn in range(40):
        result = page.evaluate(GALLERY_SCRIPT)
        urls.update(result['urls'])
        expected = max(expected, result['expected'])
        ready |= result['ready']
        authoritative |= result['authoritative']
        signature = tuple(result['urls'])
        # A singular JSON-LD cover with a Next-image control is NOT a full
        # gallery. Follow it instead of incorrectly stopping at the cover.
        known_album = authoritative and result['albumLength'] > 1
        if urls and len(urls) >= max(expected, 1) and (known_album or (ready and not result['next'])):
            return sorted(urls)
        if urls and expected > 1 and len(urls) >= expected:
            return sorted(urls)
        if result['next'] and signature in signatures and len(signatures) > 1 and expected <= len(urls):
            return sorted(urls)  # The carousel wrapped around all photos.
        signatures.add(signature)
        if result['next'] and urls:
            page.locator('[data-aetheris-photo-next="1"]').last.click(timeout=3000)
        page.wait_for_timeout(250)
    raise DuplicateScanIncomplete('商品相簿沒有完整載入（可能需要登入或完成網站驗證）。')


def download_photo(context, url: str) -> bytes:
    """APIRequestContext shares browser cookies and is not blocked by CORS.

    Use only actual gallery URLs read from the account's own listings. Dispose
    responses so a large inventory does not retain every downloaded body twice.
    """
    last = None
    for _ in range(2):
        response = None
        try:
            response = context.request.get(url, timeout=15000)
            if not response.ok:
                raise OSError(f'HTTP {response.status}')
            data = response.body()
            if len(data) > 30 * 1024 * 1024:
                raise ValueError('圖片超過 30MB')
            return data
        except Exception as exc:
            last = exc
        finally:
            if response is not None:
                response.dispose()
    raise DuplicateScanIncomplete(f'無法讀取帳戶商品圖片：{url} ({last})')


def scan_account(context, management_page, progress=None) -> AccountIndex:
    index = AccountIndex()
    try:
        rows = management_listings(management_page, progress)
    except Exception as exc:
        index.errors.append(str(exc))
        return index
    if not rows:
        index.complete = True  # Explicit empty-account state was verified.
        return index
    detail = context.new_page()
    seen_urls = {}
    try:
        for number, row in enumerate(rows, 1):
            listing_url = row['url']
            index.listings.add(listing_key(listing_url))
            if progress:
                progress(f'正在檢查帳戶商品相簿 {number}/{len(rows)}，已讀取 {len(index.records)} 張照片…')
            try:
                detail.goto(listing_url, wait_until='domcontentloaded', timeout=30000)
                if listing_key(detail.url) != listing_key(listing_url):
                    raise DuplicateScanIncomplete('商品頁面被重新導向，未能確認原商品相簿。')
                for url in gallery_urls(detail):
                    try:
                        if url not in seen_urls:
                            seen_urls[url] = fingerprint(download_photo(context, url))
                        index.records.append((seen_urls[url], listing_url, url))
                    except Exception as exc:
                        index.errors.append(f'{listing_url}: {exc}')
            except Exception as exc:
                index.errors.append(f'{listing_url}: {exc}')
    finally:
        detail.close()
    index.complete = not index.errors
    return index
