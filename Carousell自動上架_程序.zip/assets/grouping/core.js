/* Product identity grouping, shared by the worker and regression tests.
 * All vectors are normalized explicitly. Filenames are never identity labels.
 * Strong same-view matches are collapsed first. Cross-view joins must be
 * reciprocal or unambiguous AND compatible with every existing view.
 */
export const GROUPING_VERSION = 'dino-instance-v1';
export const SIMILARITY_THRESHOLD = 0.92;
export const CROSS_VIEW_THRESHOLD = 0.70;
const AMBIGUITY_MARGIN = 0.035;

export function normalizeEmbedding(data) {
  let norm = 0;
  for (const n of data) norm += n * n;
  norm = Math.sqrt(norm);
  if (!Number.isFinite(norm) || norm < 1e-8) throw new Error('Invalid image embedding');
  return Array.from(data, x => x / norm);
}

export function cosine(a, b) {
  if (!a || !b || a.length !== b.length) return -1;
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return Math.max(-1, Math.min(1, sum));
}

function histogramDistance(a, b) {
  if (!a || !b || a.length !== b.length) return 1;
  return a.reduce((sum, x, i) => sum + Math.abs(x - b[i]), 0) / 2;
}

export function compareFeatures(a, b) {
  const raw = cosine(a.global, b.global);
  let focused = -1;
  for (const x of a.views) for (const y of b.views) focused = Math.max(focused, cosine(x, y));
  const similarity = Math.max(raw, focused);
  const color = histogramDistance(a.color, b.color);
  const accent = histogramDistance(a.accent, b.accent);
  // Two independently framed views agreeing very strongly are also robust
  // evidence under exposure changes, which shift absolute RGB histograms.
  const sameAcquisition = raw >= .96 || (raw >= .945 && focused >= .96);
  const score = sameAcquisition ? raw : similarity - .10 * color;
  // Coarse color is supporting evidence only; it never merges products by
  // itself. Weak shape matches also need matching distinctive accent colors.
  const compatible = sameAcquisition || (color <= .55 && accent <= .65 &&
    ((similarity >= .72 && (similarity >= .80 || accent <= .50)) ||
     (similarity >= .65 && color <= .35 && accent <= .35)));
  return {raw, focused, similarity, color, accent, score, compatible, sameAcquisition};
}

export function groupFeatures(features, keys = []) {
  const n = features.length;
  if (!n) return {groups: [], uncertain: [], version: GROUPING_VERSION};
  const matrix = Array.from({length: n}, () => new Array(n));
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++)
    matrix[i][j] = matrix[j][i] = compareFeatures(features[i], features[j]);
  // Stable keys make shuffled uploads produce the same partition. Keys are
  // content hashes, not names; they are only tie breakers for equal scores.
  const stable = i => String(keys[i] || i.toString().padStart(8, '0'));
  const indices = Array.from({length:n}, (_, i) => i).sort((a,b)=>stable(a).localeCompare(stable(b)));
  const valid = (a,b) => matrix[a][b].compatible && matrix[a][b].score >= CROSS_VIEW_THRESHOLD;
  const score = (a,b) => matrix[a][b].score;

  // Only very strong same-view edges collapse acquisition variants. The
  // graph allows exposure/scale variants to reach their original photo;
  // weaker cross-view edges below are deliberately NOT transitive.
  const parent=Array.from({length:n},(_,i)=>i);
  const root=i=>{while(parent[i]!==i){parent[i]=parent[parent[i]];i=parent[i];}return i;};
  for(let a=0;a<n;a++)for(let b=a+1;b<n;b++){
    const p=matrix[a][b];
    if(p.sameAcquisition || (p.similarity>=SIMILARITY_THRESHOLD && p.raw>=.84 && p.color<=.45)){
      const ra=root(a),rb=root(b);if(ra!==rb)parent[rb]=ra;
    }
  }
  const byRoot=new Map();
  for(const i of indices){const r=root(i);if(!byRoot.has(r))byRoot.set(r,[]);byRoot.get(r).push(i);}
  const units=Array.from(byRoot.values());
  const unitScore = (a,b) => Math.max(...a.flatMap(i=>b.map(j=>score(i,j))));
  // Lighting variants can change the histogram: each acquisition unit needs
  // at least one compatible image in the opposite unit in both directions.
  const unitValid = (a,b) => a.some(i=>b.some(j=>valid(i,j)));
  const unitCompatible = (a,b) => a.some(i=>b.some(j=>matrix[i][j].compatible && score(i,j)>=.62));
  const best = units.map((g,i) => {
    const options = units.map((other,j)=>({j,s:i===j?-Infinity:unitScore(g,other)}))
      .filter(x=>x.j!==i && unitValid(g,units[x.j]))
      .sort((a,b)=>b.s-a.s || stable(units[a.j][0]).localeCompare(stable(units[b.j][0])));
    return options.length ? options[0].j : -1;
  });
  const clusters=[], used=new Set();
  // Reciprocal nearest units create anchors, so two already coherent sets of
  // similar-looking toys do not subsequently swallow one another.
  for (let i=0;i<units.length;i++) {
    const j=best[i];
    if (j>=0 && best[j]===i && !used.has(i) && !used.has(j)) {
      clusters.push([i,j]); used.add(i); used.add(j);
    }
  }
  const loose=units.map((_,i)=>i).filter(i=>!used.has(i))
    .sort((a,b)=>(best[b]<0?-Infinity:unitScore(units[b],units[best[b]]))-
      (best[a]<0?-Infinity:unitScore(units[a],units[best[a]])) || stable(units[a][0]).localeCompare(stable(units[b][0])));
  for (const i of loose) {
    // A unit that already has repeat acquisition evidence is an established
    // anchor. Do not absorb it merely because another coherent product set
    // looks similar; a reciprocal match would have joined it above.
    if (units[i].length > 1) continue;
    const options=clusters.map(g=>({g,s:Math.max(...g.map(j=>unitScore(units[i],units[j])))}))
      .filter(x=>x.g.every(j=>unitCompatible(units[i],units[j])) &&
        x.g.reduce((s,j)=>s+unitScore(units[i],units[j]),0)/x.g.length>=CROSS_VIEW_THRESHOLD-.02)
      .sort((a,b)=>b.s-a.s);
    if (!options.length) continue;
    const {g,s}=options[0];
    const outside=Math.max(-1,...units.map((other,j)=>j===i || g.includes(j)?-1:unitScore(units[i],other)));
    if (s-outside < AMBIGUITY_MARGIN) continue;
    g.push(i); used.add(i);
  }
  for (let i=0;i<units.length;i++) if (!used.has(i)) clusters.push([i]);
  const groups=clusters.map(g=>g.flatMap(i=>units[i]).sort((a,b)=>a-b)).sort((a,b)=>a[0]-b[0]);
  const uncertain=groups.map((g,index)=>({g,index})).filter(({g})=>
    g.length===1 && matrix[g[0]].some(p=>p && p.similarity>=.68)).map(x=>x.index);
  return {groups, uncertain, version: GROUPING_VERSION};
}
