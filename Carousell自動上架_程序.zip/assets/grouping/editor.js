/* Editable grouping manifest. Dragging only changes the draft; originals
 * move after the server validates and commits an exact photo partition. */
(() => {
  const s={groups:[],photos:new Map(),selected:new Set(),history:[],dirty:false,saving:false,loading:false,revision:'',sources:[],retry:null,notice:''};
  const en=()=>typeof pageLang!=='undefined'&&pageLang==='en';
  const t=(zh,english)=>en()?english:zh;
  const copy=x=>JSON.parse(JSON.stringify(x));
  const element=(tag,className,text)=>{const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;};
  let initial=[],drag=null,loadNumber=0;
  function button(id,zh,english,handler){const b=element('button','group-editor-button',t(zh,english));b.type='button';b.id=id;b.addEventListener('click',handler);return b;}
  function controls(){
    const grid=document.querySelector('#uploadProducts');if(!grid||document.querySelector('#groupEditorTools'))return;
    const help=element('p','group-editor-help');help.id='groupEditorHelp';grid.before(help);
    const tools=element('div','group-editor-tools');tools.id='groupEditorTools';
    const count=element('span','group-selection-count');count.id='groupSelectionCount';
    tools.append(count,button('groupSplit','選取照片另建一組','New group from selection',()=>split([...s.selected])),button('groupClear','清除選取','Clear selection',()=>{s.selected.clear();render();}),button('groupUndo','復原上一步','Undo',undo));grid.before(tools);
    const status=element('p','group-editor-status');status.id='groupEditorStatus';status.setAttribute('role','status');grid.before(status);
    const zone=element('div','group-new-zone');zone.id='groupNewZone';zone.tabIndex=0;grid.after(zone);
    dropTarget(zone,data=>{if(data.kind==='photos')split(data.ids);});
    const footer=element('div','group-editor-footer');footer.id='groupEditorFooter';
    footer.append(button('groupReload','重新讀取','Reload',()=>open(null)),button('groupSave','儲存分組','Save groups',save));zone.after(footer);
    document.querySelector('#uploadModal')?.classList.add('group-editor-modal');
    for(const id of ['closeUpload','closeUploadBottom'])document.querySelector('#'+id)?.addEventListener('click',event=>{
      if(s.saving||s.loading||(s.dirty&&!confirm(t('還有尚未儲存的分組調整。確定放棄調整並關閉？','Discard unsaved grouping changes and close?')))){event.preventDefault();event.stopImmediatePropagation();return;}
      if(s.dirty){s.groups=copy(initial);s.dirty=false;s.selected.clear();s.history=[];}
    },true);
  }
  function remember(){s.history.push(copy(s.groups));if(s.history.length>30)s.history.shift();s.retry=null;s.notice='';}
  function changed(){s.groups=s.groups.filter(g=>g.photos.length);s.selected.clear();s.dirty=true;render();}
  function move(ids,targetKey){
    if(s.saving||s.loading)return;
    const target=s.groups.find(g=>g.key===targetKey),wanted=new Set(ids);
    if(!target)return;
    const incoming=s.groups.flatMap(g=>g.key===targetKey?[]:g.photos.filter(id=>wanted.has(id)));
    if(!incoming.length)return;
    remember();for(const g of s.groups)if(g!==target)g.photos=g.photos.filter(id=>!wanted.has(id));target.photos.push(...incoming);changed();
  }
  function split(ids){
    if(s.saving||s.loading)return;
    const wanted=new Set(ids),valid=s.groups.flatMap(g=>g.photos.filter(id=>wanted.has(id)));
    if(!valid.length)return;
    remember();for(const g of s.groups)g.photos=g.photos.filter(id=>!wanted.has(id));
    s.groups.push({key:'new:'+crypto.randomUUID(),name:'',photos:valid});changed();
  }
  function merge(sourceKey,targetKey){const source=s.groups.find(g=>g.key===sourceKey);if(source&&sourceKey!==targetKey)move([...source.photos],targetKey);}
  function undo(){if(s.saving||s.loading||!s.history.length)return;s.groups=s.history.pop();s.dirty=JSON.stringify(s.groups)!==JSON.stringify(initial);s.selected.clear();s.retry=null;s.notice='';render();}
  function startDrag(event,data){
    if(s.saving||s.loading){event.preventDefault();return;}
    drag=data;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('application/x-aetheris-grouping',JSON.stringify(data));event.dataTransfer.setData('text/plain','Aetheris product photos');
  }
  function dragData(event){try{return JSON.parse(event.dataTransfer.getData('application/x-aetheris-grouping'));}catch{return drag;}}
  function dropTarget(target,handler){
    target.addEventListener('dragover',event=>{if(s.saving)return;if(drag||[...event.dataTransfer.types].includes('application/x-aetheris-grouping')){event.preventDefault();event.stopPropagation();event.dataTransfer.dropEffect='move';target.classList.add('group-drop-over');}});
    target.addEventListener('dragleave',event=>{if(!target.contains(event.relatedTarget))target.classList.remove('group-drop-over');});
    target.addEventListener('drop',event=>{const data=dragData(event);target.classList.remove('group-drop-over');if(!data)return;event.preventDefault();event.stopPropagation();if(!s.saving)handler(data);drag=null;});
  }
  function render(){
    controls();const grid=document.querySelector('#uploadProducts');if(!grid)return;grid.replaceChildren();
    document.querySelector('#groupEditorHelp').textContent=t('拖曳「整組」到另一組即可合併。點選照片可多選，再拖到其他組；也可按「選取照片另建一組」。','Drag a group header onto another group to merge. Click photos to select several, then drag them to another group or create a new group.');
    document.querySelector('#groupSelectionCount').textContent=t(`已選 ${s.selected.size} 張`,`${s.selected.size} selected`);
    const text={groupSplit:['選取照片另建一組','New group from selection'],groupClear:['清除選取','Clear selection'],groupUndo:['復原上一步','Undo'],groupReload:['重新讀取','Reload'],groupSave:[s.saving?'正在儲存…':'儲存分組',s.saving?'Saving…':'Save groups']};
    for(const [id,pair] of Object.entries(text))document.querySelector('#'+id).textContent=t(...pair);
    document.querySelector('#groupSplit').disabled=s.saving||!s.selected.size;document.querySelector('#groupClear').disabled=s.saving||!s.selected.size;
    document.querySelector('#groupUndo').disabled=s.saving||s.loading||!s.history.length;document.querySelector('#groupSave').disabled=s.saving||s.loading||!s.dirty;document.querySelector('#groupReload').disabled=s.saving||s.loading;
    const summary=document.querySelector('#uploadSummary');summary.dataset.grouping='true';summary.dataset.count=String(s.groups.length);
    const count=s.groups.reduce((n,g)=>n+g.photos.length,0);summary.textContent=t(`目前 ${s.groups.length} 件商品，共 ${count} 張原始圖片。`,`${s.groups.length} products with ${count} original photos.`);
    document.querySelector('#groupEditorStatus').textContent=s.notice||(s.dirty?t('尚未儲存；實際資料夾未更動。','Unsaved changes; folders have not changed.'):t('可拖曳調整分組，完成後按「儲存分組」。','Adjust the groups, then click Save groups.'));
    document.querySelector('#groupEditorStatus').classList.toggle('is-unsaved',s.dirty);
    s.groups.forEach((g,index)=>{
      const card=element('div','upload-product grouped-product');card.dataset.groupKey=g.key;
      const header=element('div','group-drag-header',t(`整組 ${index+1} · 拖曳合併`,`Group ${index+1} · Drag to merge`));header.draggable=!s.saving;header.dataset.groupKey=g.key;header.setAttribute('aria-label',t('拖曳整組合併','Drag whole group to merge'));
      header.addEventListener('dragstart',event=>startDrag(event,{kind:'group',key:g.key}));header.addEventListener('dragend',()=>{drag=null;document.querySelectorAll('.group-drop-over').forEach(e=>e.classList.remove('group-drop-over'));});
      const thumbs=element('div','group-thumbnails');
      g.photos.forEach(id=>{
        const photo=s.photos.get(id);const tile=element('button','group-photo'+(s.selected.has(id)?' is-selected':''));tile.type='button';tile.dataset.photoId=id;tile.draggable=!s.saving;tile.disabled=s.saving;tile.title=photo.name;tile.setAttribute('aria-label',photo.name);tile.setAttribute('aria-pressed',String(s.selected.has(id)));
        const img=element('img');img.loading='lazy';img.alt=photo.name;img.src=photo.url;img.draggable=false;tile.append(img);
        tile.addEventListener('click',()=>{if(s.saving||s.loading)return;if(s.selected.has(id))s.selected.delete(id);else s.selected.add(id);render();});
        tile.addEventListener('dragstart',event=>{event.stopPropagation();startDrag(event,{kind:'photos',ids:s.selected.has(id)?[...s.selected]:[id]});});
        tile.addEventListener('dragend',()=>{drag=null;document.querySelectorAll('.group-drop-over').forEach(e=>e.classList.remove('group-drop-over'));});thumbs.append(tile);
      });
      const label=element('strong','group-folder-name',g.name||t('新商品組（儲存後建立資料夾）','New product (folder created on save)'));
      const number=element('span','group-photo-count',t(`${g.photos.length} 張圖片`,`${g.photos.length} photos`));card.append(header,thumbs,label,number);
      if(s.selected.size){const moveHere=button('', '將選取照片移到這組','Move selected photos here',()=>move([...s.selected],g.key));moveHere.classList.add('group-move-here');card.append(moveHere);}
      dropTarget(card,data=>data.kind==='group'?merge(data.key,g.key):move(data.ids,g.key));grid.append(card);
    });
    document.querySelector('#groupNewZone').textContent=t('拖曳照片到這裡，另建一組','Drop photos here to create a new group');
    document.querySelector('#closeUploadBottom').textContent=t('完成','Done');
  }
  function adopt(data){
    s.photos=new Map(data.groups.flatMap(g=>g.photos.map(p=>[p.id,p])));
    s.groups=data.groups.map(g=>({key:g.key,name:g.name,photos:g.photos.map(p=>p.id)}));initial=copy(s.groups);
    s.revision=data.version;s.sources=data.source_folders;s.history=[];s.selected.clear();s.dirty=false;s.retry=null;
  }
  async function open(folders=null){
    if(s.saving||s.loading)return;
    if(s.dirty&&!confirm(t('重新讀取會放棄尚未儲存的調整，確定繼續？','Reload and discard unsaved grouping changes?')))return;
    controls();s.loading=true;document.querySelector('#groupReload').disabled=true;document.querySelector('#groupSave').disabled=true;const number=++loadNumber;
    try{
      const response=await fetch('/grouping/inspect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folders})});const data=await response.json();
      if(!response.ok||!data.ok)throw new Error(data.message||'Cannot load groups');if(number!==loadNumber)return;
      adopt(data);s.notice=data.skipped?.length?t(`另有 ${data.skipped.length} 個已含商品資料或沒有圖片的資料夾未納入調整。`,`${data.skipped.length} prepared or empty folders were left unchanged.`):'';
      if(!s.groups.length){s.notice=t('目前沒有可調整的照片，請先加入商品圖片。','No editable photos. Add product photos first.');}
      s.loading=false;render();document.querySelector('#uploadModal').classList.add('show');
    }catch(error){document.querySelector('#notice').textContent=t('無法開啟分組：','Could not open groups: ')+error.message;throw error;}
    finally{s.loading=false;}
  }
  async function save(){
    if(!s.dirty||s.saving||s.loading)return;
    const draft={version:s.revision,source_folders:s.sources,groups:s.groups.map(g=>({key:g.key,photos:g.photos}))};const signature=JSON.stringify(draft);
    if(!s.retry||s.retry.signature!==signature)s.retry={signature,payload:{...draft,request_id:crypto.randomUUID().replaceAll('-','')}};
    s.saving=true;s.notice='';render();
    try{
      const response=await fetch('/grouping/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(s.retry.payload)});const data=await response.json();
      if(!response.ok||!data.ok)throw new Error(data.message||'Could not save groups');adopt(data);
      s.notice=t(`已儲存 ${s.groups.length} 件商品；原分組已自動備份。`,`Saved ${s.groups.length} products. Original groups were backed up.`);
      if(typeof refreshFiles==='function')await refreshFiles();
    }catch(error){s.notice=t('儲存未確認：','Save not confirmed: ')+error.message;}
    finally{s.saving=false;render();}
  }
  window.AetherisGroupEditor={open,save,hasUnsaved:()=>s.dirty};
  window.addEventListener('beforeunload',event=>{if(s.dirty||s.saving){event.preventDefault();event.returnValue='';}});
  document.addEventListener('DOMContentLoaded',()=>{
    controls();document.querySelector('#languageToggle')?.addEventListener('click',()=>setTimeout(()=>{if(document.querySelector('#uploadModal').classList.contains('show'))render();},0));
    document.querySelector('#editPendingGroups')?.addEventListener('click',()=>open(null).catch(()=>{}));
  });
})();
