import {normalizeEmbedding} from './core.js';

export const MODEL_ID = 'Xenova/dinov2-small';

function canvas(w,h) {return new OffscreenCanvas(w,h);}

export async function prepareImage(blob) {
  const bitmap=await createImageBitmap(blob, {imageOrientation:'from-image'});
  try {
    // Bound both dimensions, including tall photographs, to bound memory.
    const scale=Math.min(1,128/Math.max(bitmap.width,bitmap.height));
    const w=Math.max(1,Math.round(bitmap.width*scale)), h=Math.max(1,Math.round(bitmap.height*scale));
    const small=canvas(w,h), ctx=small.getContext('2d',{willReadFrequently:true});
    ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(bitmap,0,0,w,h);
    const pixels=ctx.getImageData(0,0,w,h).data, border=[];
    for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(x===0||y===0||x===w-1||y===h-1) {
      const k=(y*w+x)*4;border.push([pixels[k],pixels[k+1],pixels[k+2]]);
    }
    const bg=[0,1,2].map(c=>border.reduce((s,p)=>s+p[c],0)/border.length);
    let x0=w,y0=h,x1=0,y1=0,count=0;
    const color=new Array(64).fill(0),accent=new Array(64).fill(0);let accents=0;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++) {
      const at=(y*w+x)*4,r=pixels[at],g=pixels[at+1],b=pixels[at+2];
      if(Math.hypot(r-bg[0],g-bg[1],b-bg[2])<=32)continue;
      x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);count++;
      const bin=(r>>6)*16+(g>>6)*4+(b>>6);color[bin]++;
      if(Math.max(r,g,b)-Math.min(r,g,b)>=24||Math.max(r,g,b)<=205){accent[bin]++;accents++;}
    }
    if(count<.02*w*h || count>.94*w*h){x0=0;y0=0;x1=w-1;y1=h-1;}
    else{x0=Math.max(0,x0-3);y0=Math.max(0,y0-3);x1=Math.min(w-1,x1+3);y1=Math.min(h-1,y1+3);}
    const source=[x0/w*bitmap.width,y0/h*bitmap.height,(x1-x0+1)/w*bitmap.width,(y1-y0+1)/h*bitmap.height];
    const focused=[];
    // Keep the whole photo and a letterboxed subject view. Wide subjects get
    // both upright orientations; lying toys are compared with standing toys.
    const angles=source[2]/source[3]>1.25?[0,90,270]:[0];
    for(const angle of angles){
      const c=canvas(384,384),cctx=c.getContext('2d');cctx.fillStyle='#fff';cctx.fillRect(0,0,384,384);
      const s=340/Math.max(source[2],source[3]);cctx.translate(192,192);cctx.rotate(angle*Math.PI/180);
      cctx.drawImage(bitmap,...source,-source[2]*s/2,-source[3]*s/2,source[2]*s,source[3]*s);
      focused.push(c);
    }
    const full=canvas(Math.max(1,Math.round(bitmap.width*Math.min(1,640/Math.max(bitmap.width,bitmap.height)))),
      Math.max(1,Math.round(bitmap.height*Math.min(1,640/Math.max(bitmap.width,bitmap.height)))));
    const fctx=full.getContext('2d');fctx.fillStyle='#fff';fctx.fillRect(0,0,full.width,full.height);fctx.drawImage(bitmap,0,0,full.width,full.height);
    return {full,focused,color:color.map(x=>x/Math.max(1,count)),
      accent:accents>=8?accent.map(x=>x/accents):color.map(x=>x/Math.max(1,count))};
  } finally {bitmap.close();}
}

export async function extractFeatures(blob,extractor,RawImage) {
  const prepared=await prepareImage(blob);
  async function vector(c){
    const rgba=c.getContext('2d').getImageData(0,0,c.width,c.height);
    const image=new RawImage(new Uint8ClampedArray(rgba.data),c.width,c.height,4);
    const output=await extractor(image);
    // DINOv2 returns [batch,tokens,384]. Token zero is the CLS image vector.
    // Flattening all patch tokens or using text-pipeline options is incorrect.
    const dimension=output.dims[output.dims.length-1];
    return normalizeEmbedding(output.data.subarray(0,dimension));
  }
  const global=await vector(prepared.full),views=[];
  for(const view of prepared.focused)views.push(await vector(view));
  return {global,views,color:prepared.color,accent:prepared.accent};
}
