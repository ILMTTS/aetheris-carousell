/* Local-only product grouping. Inference runs in a cancellable Web Worker;
 * upload errors never re-submit the whole batch to a weaker algorithm. */
(() => {
  const state={active:false,display:false,percent:0,message:'',cancelled:false};
  let worker, pending, cards=[],urls=[];
  const en=()=>typeof pageLang!=='undefined'&&pageLang==='en';
  const t=(zh,eng)=>en()?eng:zh;
  function progress(percent,message,english){
    Object.assign(state,{display:true,percent,message,zhMessage:message,enMessage:english||message});
    message=en()?state.enMessage:state.zhMessage;state.message=message;
    const fill=document.querySelector('#fill'),label=document.querySelector('#percent');
    if(fill){fill.style.width=percent+'%';fill.style.background=percent===100?'#34d399':'#e74454';}
    if(label)label.textContent=Math.round(percent)+'%';
    const notice=document.querySelector('#notice');if(notice)notice.textContent=message;
    const stop=document.querySelector('[data-action="stop"]');if(stop)stop.disabled=!state.active;
  }
  function abortError(){return new DOMException(t('已停止圖片分組','Photo grouping stopped'),'AbortError');}
  function cancel(){
    if(!state.active)return;
    state.cancelled=true;
    if(pending){worker?.terminate();worker=null;pending.reject(abortError());pending=null;}
    progress(state.percent,'正在停止；已保存的商品會保留。','Stopping; products already saved will be kept.');
  }
  function infer(files){
    if(!worker){
      worker=new Worker('/assets/grouping/worker.js?v=72',{type:'module'});
      worker.onmessage=({data})=>{
        if(data.type==='progress')progress(data.percent,data.message,data.english||'Analyzing product photos…');
        if(data.type==='result'){const task=pending;pending=null;task?.resolve(data);}
        if(data.type==='error'){const task=pending;pending=null;worker.terminate();worker=null;task?.reject(new Error(data.message));}
      };
      worker.onerror=event=>{const task=pending;pending=null;worker?.terminate();worker=null;task?.reject(new Error(event.message||t('本機辨識模型無法啟動，請重新開啟工具。','The local image model could not start. Restart the tool.')));};
    }
    return new Promise((resolve,reject)=>{pending={resolve,reject};worker.postMessage({type:'group',files});});
  }
  function releaseURLs(){urls.forEach(url=>URL.revokeObjectURL(url));urls=[];}
  async function showGroups(){
    if(!cards.length)return;
    await window.AetherisGroupEditor.open(cards.map(card=>card.name));
  }
  async function upload(files){
    if(state.active){document.querySelector('#notice').textContent=t('正在處理上一批圖片，完成後可再加入。','The previous batch is processing. Add more after it finishes.');return;}
    if(window.AetherisGroupEditor?.hasUnsaved()){document.querySelector('#notice').textContent=t('請先儲存或放棄目前的分組調整，再加入新照片。','Save or discard your grouping changes before adding photos.');return;}
    const selected=Array.from(files||[]);
    if(!selected.length){if(typeof showNoPhoto==='function')showNoPhoto(t('請先把商品照片放入「自動分組商品」。','Add product photos to Auto-group photos first.'));return;}
    const unsupported=selected.filter(f=>!/^image\//.test(f.type)&&!/[.](jpe?g|png|webp|bmp|gif|tiff?|ico|tga|ppm|pgm|pbm|pnm)$/i.test(f.name));
    if(unsupported.length){document.querySelector('#notice').textContent=t('無法處理這些檔案：','Unsupported files: ')+unsupported.map(f=>f.name).join(', ');return;}
    if(selected.length>500||selected.some(f=>f.size>95*1024*1024)){
      document.querySelector('#notice').textContent=t('每批最多 500 張，每張圖片需小於 95 MB。','Use up to 500 photos per batch, each under 95 MB.');return;
    }
    Object.assign(state,{active:true,cancelled:false,started:Date.now()});cards=[];
    const input=document.querySelector('#fileInput');if(input)input.disabled=true;
    document.querySelector('#dropzone')?.setAttribute('aria-busy','true');
    progress(1,`正在準備 ${selected.length} 張圖片…`,`Preparing ${selected.length} photos…`);
    const batch=crypto.randomUUID().replaceAll('-','').slice(0,16);
    try{
      const result=await infer(selected);
      for(let i=0;i<result.groups.length;i++){
        if(state.cancelled)throw abortError();
        const indices=result.groups[i],groupFiles=indices.map(index=>selected[index]);
        const body=new FormData();
        body.append('group_id',`視覺組${String(i+1).padStart(2,'0')}`);
        body.append('request_id',batch+'-'+i);
        groupFiles.forEach(file=>body.append('files',file,file.name));
        const response=await fetch('/upload',{method:'POST',body}),saved=await response.json();
        if(!response.ok||!saved.ok)throw new Error(saved.message||t('商品保存失敗','Could not save product'));
        cards.push({name:saved.folders[0],files:groupFiles,uncertain:result.uncertain.includes(i)});
        progress(85+Math.round(15*(i+1)/result.groups.length),`正在保存商品 ${i+1} / ${result.groups.length}…`,`Saving product ${i+1} / ${result.groups.length}…`);
      }
      progress(100,`完成：${selected.length} 張圖片，自動分成 ${cards.length} 件商品。`,`Done: ${selected.length} photos grouped into ${cards.length} products.`);
    }catch(error){
      const stopped=error.name==='AbortError';
      progress(state.percent,(stopped?t('已停止。','Stopped. '):t('分組未完成：','Grouping incomplete: ')+error.message+' ')+t(`已保存 ${cards.length} 件商品；其餘圖片未加入，不會改用色塊強行分組。`,`Saved ${cards.length} products. Remaining photos were not added; no color-only fallback was used.`));
    }finally{
      if(cards.length){try{await showGroups();}catch{}}
      state.active=false;if(input){input.disabled=false;input.value='';}
      document.querySelector('#dropzone')?.removeAttribute('aria-busy');
      const stop=document.querySelector('[data-action="stop"]');if(stop)stop.disabled=true;
      if(typeof refreshFiles==='function')refreshFiles();
    }
  }
  window.AetherisGrouping={state,upload,cancel,showGroups,
    clear(){if(!state.active)state.display=false;},
    decorateStatus(s){if(!state.display)return s;state.message=en()?state.enMessage:state.zhMessage;return {...s,title:t('自動分組商品','Auto-group photos'),message:state.message,percent:state.percent,phase:'grouping',total:0,completion_summary:null,total_estimate_seconds:null};}};
  document.addEventListener('DOMContentLoaded',()=>{
    document.querySelector('#closeUpload')?.addEventListener('click',releaseURLs);
    document.querySelector('#closeUploadBottom')?.addEventListener('click',releaseURLs);
  });
})();
