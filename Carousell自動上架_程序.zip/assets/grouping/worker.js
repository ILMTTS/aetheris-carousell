import {groupFeatures,GROUPING_VERSION} from './core.js';
import {extractFeatures,MODEL_ID} from './features.js';

let extractorPromise,lastProgress='';
function progress(percent,message,english){const key=percent+message;if(lastProgress===key)return;lastProgress=key;postMessage({type:'progress',percent,message,english});}
async function extractor(){
  if(!extractorPromise)extractorPromise=(async()=>{
    const {pipeline,env,RawImage}=await import('../vendor/transformers/transformers.min.js');
    env.allowLocalModels=true;env.allowRemoteModels=false;
    env.localModelPath='/assets/models/';
    env.backends.onnx.wasm.numThreads=1;
    env.backends.onnx.wasm.wasmPaths='/assets/vendor/transformers/';
    const model=await pipeline('image-feature-extraction',MODEL_ID,{quantized:true,
      progress_callback:()=>progress(3,'正在載入本機圖片辨識模型…','Loading the local image model…')});
    return {model,RawImage};
  })();
  return extractorPromise;
}
async function cache(){
  try{return await new Promise((resolve,reject)=>{
    const r=indexedDB.open('aetheris-product-features',1);
    r.onupgradeneeded=()=>r.result.createObjectStore('features');
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
  });}catch{return null;}
}
async function read(db,key){if(!db)return null;return await new Promise(resolve=>{
  try{const r=db.transaction('features').objectStore('features').get(key);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>resolve(null);}catch{resolve(null);}
});}
async function write(db,key,value){if(!db)return;try{
  const transaction=db.transaction('features','readwrite');transaction.objectStore('features').put(value,key);
  await new Promise(resolve=>{transaction.oncomplete=transaction.onerror=transaction.onabort=resolve;});
}catch{}}

onmessage=async({data})=>{
  if(data.type!=='group')return;
  const db=await cache();
  try{
    const features=[],keys=[];let runtime;
    for(let i=0;i<data.files.length;i++){
      const file=data.files[i];
      const digest=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());
      const key=GROUPING_VERSION+':'+Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');
      let feature=await read(db,key);
      if(!feature){
        runtime=runtime||await extractor();
        let decodable=file;
        try{const bitmap=await createImageBitmap(file);bitmap.close();}
        catch{
          // Decode uncommon formats locally; originals are saved unchanged.
          // No external image service or remote inference is involved.
          const response=await fetch('/decode-image',{method:'POST',body:file});
          if(!response.ok)throw new Error(file.name+'：圖片損壞或格式無法讀取 / Cannot decode image');
          decodable=await response.blob();
        }
        try{feature=await extractFeatures(decodable,runtime.model,runtime.RawImage);}
        catch(e){throw new Error(file.name+'：無法辨識這張圖片 / Cannot analyze image ('+e.message+')');}
        await write(db,key,feature);
      }
      features.push(feature);keys.push(key);
      progress(5+Math.round(75*(i+1)/data.files.length),`正在辨識商品 ${i+1} / ${data.files.length}…`,`Analyzing photo ${i+1} / ${data.files.length}…`);
    }
    progress(82,'正在比較商品主體及不同拍攝角度…','Comparing product details and camera angles…');
    const result=groupFeatures(features,keys);
    postMessage({type:'result',...result,features:data.debug?features:undefined,keys:data.debug?keys:undefined});
  }catch(e){postMessage({type:'error',message:e.message||String(e)});}
  finally{if(db)db.close();}
};
