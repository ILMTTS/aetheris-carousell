/* An explicit account duplicate-check result, not a generic job-complete
 * animation. No extra polling, publishing action, or filesystem mutation. */
(() => {
  if (window.AetherisDuplicateResults) return;
  const seenKey = 'aetheris_last_duplicate_result';
  let lastEvent, lastSeen = '', dialog, lastFocus;
  const en = () => typeof pageLang !== 'undefined' && pageLang === 'en';
  const t = (zh, english) => en() ? english : zh;
  try { lastSeen = sessionStorage.getItem(seenKey) || ''; } catch {}

  function safeListingURL(value) {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && !url.username && !url.password &&
        /^(?:[a-z0-9-]+\.)*carousell\.(?:com(?:\.[a-z]{2})?|sg|hk|ph|my|tw)$/i.test(url.hostname)
        ? url.href : '';
    } catch { return ''; }
  }

  function build() {
    if (dialog) return;
    const style = document.createElement('style');
    style.textContent = `
      .duplicate-results{box-sizing:border-box;width:min(760px,calc(100vw - 32px));max-height:85vh;padding:0;border:1px solid #e6dada;border-radius:16px;background:#fff;color:#252525;font-family:inherit;box-shadow:0 20px 70px #0003}
      .duplicate-results::backdrop{background:rgba(20,20,20,.52)}
      .duplicate-results-header{padding:24px 26px 16px;border-bottom:1px solid #eee}
      .duplicate-results-header h2{margin:0 0 10px;font-size:23px;line-height:1.35;font-weight:750;color:#b42332}
      .duplicate-results[data-outcome=clear] h2{color:#15724a}
      .duplicate-results[data-outcome=incomplete] h2{color:#9b5c08}
      .duplicate-results-message{margin:0;font-size:14px;line-height:1.7;color:#444}
      .duplicate-results-counts{margin:10px 0 0;font-size:12px;line-height:1.6;color:#666}
      .duplicate-results-content{max-height:52vh;overflow:auto;padding:8px 26px 16px;overscroll-behavior:contain}
      .duplicate-results-list{list-style:none;margin:0;padding:0;display:grid;gap:10px}
      .duplicate-results-list li{display:flex;align-items:center;gap:16px;padding:12px;border:1px solid #eee;border-radius:10px;background:#fffafa}
      .duplicate-results-list img{flex:none;width:84px;height:84px;object-fit:contain;border:1px solid #eee;border-radius:7px;background:white}
      .duplicate-result-copy{min-width:0;flex:1}
      .duplicate-result-name{display:block;font-size:15px;font-weight:700;overflow-wrap:anywhere;line-height:1.5}
      .duplicate-result-evidence{margin-top:4px;font-size:12px;color:#666;overflow-wrap:anywhere;line-height:1.5}
      .duplicate-result-link{display:inline-block;margin-top:7px;color:#b42332;font-size:13px;text-decoration:underline;text-underline-offset:3px}
      .duplicate-results-errors{margin-top:14px;font-size:12px;color:#666;overflow-wrap:anywhere}
      .duplicate-results-errors summary{cursor:pointer;font-weight:600}
      .duplicate-results-footer{display:flex;justify-content:flex-end;padding:14px 26px;border-top:1px solid #eee}
      .duplicate-results-close{border:0;border-radius:8px;padding:11px 25px;background:#ed4047;color:white;font-family:inherit;font-size:14px;font-weight:700;cursor:pointer}
      .duplicate-results-close:focus-visible{outline:3px solid #171717;outline-offset:3px}
      @media(max-width:520px){.duplicate-results-header{padding:18px}.duplicate-results-content{padding:8px 18px 14px}.duplicate-results-footer{padding:12px 18px}.duplicate-results-list img{width:64px;height:64px}.duplicate-results-list li{gap:10px}}
    `;
    document.head.appendChild(style);
    dialog = document.createElement('dialog');
    dialog.id = 'duplicateResultsModal';
    dialog.className = 'duplicate-results';
    dialog.setAttribute('aria-labelledby', 'duplicateResultsTitle');
    dialog.innerHTML = '<header class="duplicate-results-header"><h2 id="duplicateResultsTitle"></h2><p class="duplicate-results-message" id="duplicateResultsMessage"></p><p class="duplicate-results-counts" id="duplicateResultsCounts"></p></header><div class="duplicate-results-content"><ul class="duplicate-results-list" id="duplicateResultsList"></ul><details class="duplicate-results-errors" id="duplicateResultsErrors"><summary></summary><div></div></details></div><footer class="duplicate-results-footer"><button type="button" class="duplicate-results-close" id="closeDuplicateResults" autofocus></button></footer>';
    document.body.appendChild(dialog);
    dialog.querySelector('#closeDuplicateResults').addEventListener('click', () => dialog.close());
    dialog.addEventListener('close', () => { if (lastFocus?.isConnected) lastFocus.focus({preventScroll: true}); });
    dialog.addEventListener('click', event => {
      const rect = dialog.getBoundingClientRect();
      if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
    });
  }

  function render() {
    if (!dialog || !lastEvent) return;
    const event = lastEvent, items = Array.isArray(event.items) ? event.items : [], count = items.length;
    dialog.dataset.outcome = event.outcome;
    let title, message;
    if (event.outcome === 'incomplete') {
      title = t('重複檢查未完成', 'Duplicate check incomplete');
      message = count
        ? t(`已確認以下 ${count} 件商品刊登過，已移到「已完成檔案」。其餘商品未能完成檢查，已保留，不會因此繼續發布。`, `${count} products below are confirmed as already listed and were moved to Completed files. Remaining products could not be fully checked; they are kept and will not be published on this result.`)
        : t('這次未能完成帳戶檢查，尚不能確認哪些商品已刊登。商品已保留，請確認登入及網頁狀態後再試。', 'The account check could not finish, so previously listed products cannot yet be confirmed. Products are kept. Check your sign-in and page status, then try again.');
    } else if (event.outcome === 'no_products') {
      title = t('沒有待檢查的商品', 'No products to check');
      message = t('請先把照片放入「自動分組商品」，再檢查帳戶重複。', 'Add photos to Auto-group photos first, then check account duplicates.');
    } else if (count) {
      title = t(`以下 ${count} 件商品已刊登過`, `${count} ${count === 1 ? 'product has' : 'products have'} already been listed`);
      message = t('只要組內任意一張照片已出現在帳戶刊登，便略過整組。以下商品已移到「已完成檔案」，不會再次發布，原圖完整保留。', 'One group photo matching an account listing skips the whole group. These products were moved to Completed files and will not be published again. Original photos are preserved.');
    } else {
      title = t('沒有找到已刊登過的商品', 'No previously listed products found');
      message = t('這次已完成帳戶照片比對，沒有找到重複；商品仍保留在未處理。', 'The account photo comparison is complete. No duplicates were found; products remain in Pending.');
    }
    dialog.querySelector('#duplicateResultsTitle').textContent = title;
    dialog.querySelector('#duplicateResultsMessage').textContent = message;
    const counts = dialog.querySelector('#duplicateResultsCounts');
    counts.hidden = event.outcome === 'no_products';
    counts.textContent = t(`已完整檢查 ${event.checked_groups || 0} 組 · 帳戶 ${event.account_listings || 0} 件商品／${event.account_photos || 0} 張照片`, `${event.checked_groups || 0} groups fully checked · Account: ${event.account_listings || 0} listings / ${event.account_photos || 0} photos`);
    const list = dialog.querySelector('#duplicateResultsList');
    list.replaceChildren();
    for (const item of items) {
      const row = document.createElement('li'), copy = document.createElement('div');
      copy.className = 'duplicate-result-copy';
      if (typeof item.thumbnail === 'string' && item.thumbnail.startsWith('/thumbnail?')) {
        const img = document.createElement('img');
        img.src = item.thumbnail; img.alt = ''; img.loading = 'lazy';
        img.addEventListener('error', () => img.remove(), {once: true});
        row.appendChild(img);
      }
      const name = document.createElement('strong');
      name.className = 'duplicate-result-name'; name.textContent = item.title || item.folder_name || '';
      copy.appendChild(name);
      if (item.matched_image) {
        const evidence = document.createElement('div');
        evidence.className = 'duplicate-result-evidence';
        evidence.textContent = t('相同照片：', 'Matching photo: ') + item.matched_image;
        copy.appendChild(evidence);
      }
      const url = safeListingURL(item.listing_url);
      if (url) {
        const link = document.createElement('a');
        link.className = 'duplicate-result-link'; link.href = url;
        link.target = '_blank'; link.rel = 'noopener noreferrer';
        link.textContent = t('查看已刊登商品', 'View existing listing');
        copy.appendChild(link);
      }
      row.appendChild(copy); list.appendChild(row);
    }
    const errors = dialog.querySelector('#duplicateResultsErrors');
    errors.hidden = !Array.isArray(event.errors) || !event.errors.length;
    errors.querySelector('summary').textContent = t('技術詳情（原始訊息）', 'Technical details (original messages)');
    errors.querySelector('div').replaceChildren();
    for (const error of event.errors || []) {
      const line = document.createElement('p'); line.textContent = String(error);
      errors.querySelector('div').appendChild(line);
    }
    dialog.querySelector('#closeDuplicateResults').textContent = t('關閉', 'Close');
  }

  function receive(status) {
    const event = status?.duplicate_check_result;
    if (!event || typeof event.id !== 'string' || !['duplicates', 'clear', 'incomplete', 'no_products'].includes(event.outcome)) return;
    if (event.id === lastSeen) return;
    lastEvent = event;
    build(); render();
    lastFocus = document.activeElement;
    if (!dialog.open) dialog.showModal();
    lastSeen = event.id;
    try { sessionStorage.setItem(seenKey, lastSeen); } catch {}
  }

  function boot() {
    // Both existing status renderers already call this function. Reuse that
    // data stream instead of polling twice or triggering from any 'done' state.
    if (typeof applyFileState !== 'function') return;
    const previous = applyFileState;
    applyFileState = function(status) { previous(status); receive(status); };
    if (typeof setLanguage === 'function') {
      const previousLanguage = setLanguage;
      setLanguage = function(language) { previousLanguage(language); if (dialog?.open) render(); };
    }
    window.AetherisDuplicateResults = {receive, version: 75};
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once: true});
  else boot();
})();
