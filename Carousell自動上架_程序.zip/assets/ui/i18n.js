/* Complete dashboard localization. Product/folder names remain original.
 * This extends the existing dictionaries and renderer; it never starts an
 * account operation or changes the publishing worker's state. */
(() => {
  if (window.AetherisLocalization) return;
  const extra = {
    '正在安裝並驗證本工具的獨立環境...': 'Installing and validating the dedicated environment...',
    '環境安裝未完成，請查看檢查結果及 logs/install.log。': 'Environment setup is incomplete. Check the diagnostics and logs/install.log.',
    '環境安裝完成，請重新開啟「啟動工具.bat」套用新環境。': 'Environment installed. Reopen the launcher to use the new environment.',
    '環境安裝完成，可以開始使用。': 'Environment installed. You can start using the tool.',
    '測試功能': 'Test functions',
    '以下操作會逐件處理 Carousell 帳戶商品，請先確認登入的是正確帳戶。': 'These actions process Carousell account listings one by one. Make sure the correct account is signed in first.',
    '準備中': 'Preparing',
    '已完成': 'Completed',
    '檢查帳戶刊登': 'Checking account listings',
    'Carousell 自動填寫': 'Carousell autofill',
    '等待你補填': 'Waiting for your input',
    '已跳過重複商品': 'Duplicate product skipped',
    '已跳到下一件': 'Moved to the next product',
    '需要處理': 'Needs attention',
    '等待狀態更新...': 'Waiting for a status update...',
    '全部流程預計：計算中': 'Estimated total: calculating',
    '目前沒有商品': 'No current product',
    '已從狀態頁啟動操作，正在準備...': 'Starting the requested operation...',
    '環境檢查完成，全部必要元件可用。': 'Environment check complete. All required components are available.',
    '如果你想成功重新上架這件商品，建議嘗試以下做法：': 'If you want to relist this product, try the following:',
    '更換全新拍攝的實物圖片（最有效）': 'Take new photos of the actual product (most effective)',
    '不要再使用原本那張白底圖，也不要單純把原圖裁剪或調色，系統的圖像識別通常能認出來。': 'Do not reuse the original white-background photo or simply crop or recolor it. Image recognition can usually identify it.',
    '拿實物重新拍幾張不同角度、不同背景的照片上傳。': 'Take new photos of the actual product from different angles and against different backgrounds, then upload them.',
    '修改標題與商品描述': 'Revise the title and product description',
    '避免使用與之前完全一模一樣的字眼，稍微調整標題結構並重寫描述內容。': 'Avoid using exactly the same wording as before. Adjust the title structure and rewrite the description.',
    '等待冷卻時間或聯絡客服恢復原帖': 'Wait before relisting, or contact support to restore the original listing',
    '如果之前是誤刪原帖，可以聯絡 Carousell 幫助中心客服，要求恢復（Restore）先前刪除的帖文。': 'If you deleted the original listing by mistake, contact Carousell Help Centre to request restoration of the deleted listing.',
    '若不急著上架，通常等待 1 至 2 星期後，再配合新照片重新發布即可。': 'If you are not in a hurry, you can usually wait one to two weeks and then relist with new photos.',
    'Carousell 顯示必填或驗證問題，已保留目前分頁供檢查，並繼續下一件商品。': 'Carousell shows required-field or validation issues. The current tab has been kept for review, and processing continues with the next product.',
    'Carousell 頁面有問題，已跳過並繼續下一件商品。': 'There is a problem with the Carousell page. This product was skipped, and processing continues with the next one.',
    'Carousell 仍有必填或驗證問題，已保留商品並繼續處理下一件。': 'Carousell still shows required-field or validation issues. This product has been kept, and processing continues with the next one.',
    'Carousell 顯示此商品與已刊登商品相似，未確認發布成功，已保留在未處理。': 'Carousell says this product resembles an existing listing. Publication is unconfirmed, so it remains in Pending.',
    'Carousell 顯示此商品與已刊登商品相似，未確認發布成功；已保留在未處理並標記 error。': 'Carousell says this product resembles an existing listing. Publication is unconfirmed; it remains in Pending and is marked as an error.',
    '已記錄問題，繼續處理下一件商品。': 'The issue was recorded. Processing continues with the next product.',
    '表單未在 30 秒內穩定完成，已保留商品並繼續處理下一件。': 'The form did not stabilize within 30 seconds. This product has been kept, and processing continues with the next one.',
    '購買按鈕確認視窗已處理，但刊登表單尚未恢復可發布狀態。': 'The Buy-button confirmation was handled, but the listing form is not ready to publish yet.',
    '全部處理完成，可以查看這次作業摘要。': 'Processing is complete. You can view the summary of this run.',
    '正在檢查帳戶的「我的刊登商品」...': 'Checking the account’s My Listings...',
    '發布前再次檢查「我的刊登商品」...': 'Checking My Listings again before publishing...',
    '正在自動選擇「幾乎全新」...': 'Selecting “Like new”...',
    '刪除 Carousell 帳戶內所有已刊登商品': 'Delete every published listing in the Carousell account',
    '只開啟目前關閉的購買按鈕': 'Enable only the Buy buttons that are currently disabled',
    '關閉所有目前開啟的購買按鈕': 'Disable all Buy buttons that are currently enabled',
    '移到已刪除檔案': 'Move to Deleted files',
    '開啟待發布資料夾': 'Open the Pending folder',
    '曾出現問題': 'An issue occurred previously',
    '比對帳戶全部商品相簿，任意一張相同就略過整組並移到已完成檔案': 'Compare all account galleries. One matching photo skips the whole group and moves it to Completed files.',
    '這會刪除 Carousell 帳戶內所有已刊登商品，操作不可逆。確定要繼續嗎？': 'This will permanently delete all published listings in the Carousell account. Continue?',
    '這會開啟所有目前關閉的購買按鈕，已開啟的商品會略過。確定要繼續嗎？': 'This will enable every currently disabled Buy button. Products with Buy already enabled will be skipped. Continue?',
    '這會關閉所有目前開啟的購買按鈕，已關閉的商品會略過。確定要繼續嗎？': 'This will disable every currently enabled Buy button. Products with Buy already disabled will be skipped. Continue?'
  };
  const originals = new Map();
  const en = () => typeof pageLang !== 'undefined' && pageLang === 'en';
  let baseRuntime;

  function text(value) {
    const raw = String(value || '');
    if (!en()) return originals.get(raw) || (baseRuntime ? baseRuntime(raw) : raw);
    let translated = extra[raw];
    let match;
    if (!translated && (match = raw.match(/^正在偵測 Carousell 自動填寫(?:…|\.\.\.)\s*已讀取 (\d+) 個欄位$/))) {
      translated = `Detecting Carousell autofill... ${match[1]} fields read`;
    }
    if (!translated && (match = raw.match(/^工作程序已退出（代碼 (.+?)），尚未確認完成。請查看問題記錄或檢查環境後重試。$/))) {
      translated = `The worker exited (code ${match[1]}) before completion was confirmed. Review the issue log or check the environment, then retry.`;
    }
    if (!translated && (match = raw.match(/^環境檢查完成：有 (\d+) 項缺失或版本不符。$/))) {
      translated = `Environment check complete: ${match[1]} components are missing or have an incompatible version.`;
    }
    if (!translated && (match = raw.match(/^(.+?)：([\s\S]+)$/))) {
      // Issue messages may start with a product name. Translate only the
      // recognized diagnostic after it; leave the original name untouched.
      const diagnostic = extra[match[2]];
      if (diagnostic) translated = `${match[1]}: ${diagnostic}`;
    }
    if (!translated) translated = baseRuntime ? baseRuntime(raw) : raw;
    if (translated !== raw) originals.set(translated, raw);
    return translated;
  }

  function translateRegion(root) {
    if (!root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      // Product/folder names are data, not interface labels.
      if (node.parentElement?.closest('script,style,.file-name,.issue>strong,#product')) continue;
      const raw = node.nodeValue, key = raw.trim();
      if (!key) continue;
      const next = text(key);
      if (next !== key) node.nodeValue = raw.replace(key, next);
    }
  }

  function apply() {
    for (const selector of ['.test-tools', '#solutionGuide', '#issues']) {
      translateRegion(document.querySelector(selector));
    }
    for (const element of document.querySelectorAll('[title],[aria-label]')) {
      for (const attribute of ['title', 'aria-label']) {
        const raw = element.getAttribute(attribute);
        if (!raw) continue;
        const next = text(raw);
        if (next !== raw) element.setAttribute(attribute, next);
      }
    }
  }

  function boot() {
    if (typeof runtimeText !== 'function' || typeof langMap === 'undefined') return;
    // Previously runtimeZhEn was used only by a few selected elements. Add
    // those same static translations to the ordinary page translation pass.
    Object.assign(langMap, runtimeZhEn, extra);
    Object.assign(reverseLangMap, Object.fromEntries(Object.entries(langMap).map(([zh, english]) => [english, zh])));
    Object.assign(runtimeEnZh, Object.fromEntries(Object.entries(extra).map(([zh, english]) => [english, zh])));
    baseRuntime = runtimeText;
    runtimeText = text;
    const oldSetLanguage = setLanguage;
    setLanguage = function(next) { oldSetLanguage(next); apply(); translateRuntime(); };
    const oldRenderIssues = renderIssues;
    let issueKey;
    renderIssues = function(items) {
      const key = JSON.stringify([en(), items || []]);
      if (key === issueKey) return;
      issueKey = key;
      oldRenderIssues((items || []).map(issue => ({...issue, message: text(issue.message)})));
      translateRegion(document.querySelector('#issues'));
    };
    const nativeConfirm = window.confirm.bind(window);
    window.confirm = message => nativeConfirm(text(message));
    // Extend the existing runtime pass instead of adding a competing whole-
    // page observer. Assign only changed strings to prevent observer loops.
    const oldTranslateRuntime = translateRuntime;
    translateRuntime = function() { oldTranslateRuntime(); apply(); };
    translatePage();
    translateRuntime();
    const observer = new MutationObserver(() => apply());
    for (const selector of ['#issues', '#unprocessed', '#solutionGuide']) {
      const root = document.querySelector(selector);
      if (root) observer.observe(root, {childList: true, characterData: true, subtree: true});
    }
    window.AetherisLocalization = {version: 74, text, apply};
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once: true});
  else boot();
})();
