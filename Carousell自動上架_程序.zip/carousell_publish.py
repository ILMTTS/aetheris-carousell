from __future__ import annotations

import argparse
import base64
import hashlib
import math
from contextlib import nullcontext
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
import os
import re
import shutil
import subprocess
import threading
import sys
import time
from dataclasses import dataclass, asdict
from io import BytesIO
from pathlib import Path
from typing import Iterable
from urllib.parse import parse_qs, quote, quote_plus, urlsplit
from urllib.request import urlopen
import webbrowser

from PIL import Image, ImageOps
from grouping_store import GroupingStore, GroupingError
from account_duplicates import AccountIndex, DuplicateScanIncomplete, scan_account


# Pillow can read these formats and normalize them to PNG before upload.
IMAGE_EXTS = {
    ".jpg", ".jpeg", ".png", ".webp", ".bmp",
    ".gif", ".tif", ".tiff", ".ico", ".tga",
    ".ppm", ".pgm", ".pbm", ".pnm",
}
IMAGE_FORMAT_LABEL = "JPG、PNG、WEBP、BMP、GIF、TIFF、ICO、TGA、PPM、PGM、PBM 或 PNM"
ROOT = Path(__file__).resolve().parent
INBOX = ROOT / "待發布"
PROCESSED = ROOT / "已整理圖片"
COMPLETED = ROOT / "已完成檔案"
DELETED = ROOT / "已刪除檔案"
BROWSER_DATA = ROOT / "browser_data"
STATUS_STATE_FILE = ROOT / "status_state.json"
STATUS_URL_FILE = ROOT / "status_dashboard_url.txt"
STATUS_SERVER_LOCK = ROOT / "status_server.lock"
CONTROL_FILE = ROOT / "status_control.json"
ERROR_PRODUCTS_FILE = ROOT / "error_products.json"
WORKER_PID_FILE = ROOT / "worker.pid"
DASHBOARD_VERSION = 74
# Browser-side visual grouping threshold. A higher value keeps similarly
# coloured but unrelated products in separate groups.
SIMILARITY_THRESHOLD = 0.92


class StatusState:
    def __init__(self, total: int):
        self._lock = threading.Lock()
        self._started_monotonic = time.monotonic()
        self._data = {
            "title": "Aetheris",
            "message": "",
            "phase": "starting",
            "current": 0,
            "total": total,
            "percent": 0,
            "warning": False,
            "issues": [],
            "eta_seconds": None,
            "total_estimate_seconds": None,
            "manual_review_seconds": None,
            "manual_review_url": "",
            "completion_summary": None,
            "allow_completion": False,
            "environment": None,
            "updated": datetime.now().astimezone().isoformat(timespec="seconds"),
        }
        self._save()

    def _save(self) -> None:
        try:
            STATUS_STATE_FILE.write_text(json.dumps(self._data, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass

    def update(self, **values) -> None:
        with self._lock:
            self._data.update(values)
            self._update_eta()
            self._data["updated"] = datetime.now().astimezone().isoformat(timespec="seconds")
            self._save()

    def _update_eta(self) -> None:
        total = int(self._data.get("total") or 0)
        current = int(self._data.get("current") or 0)
        if total <= 0:
            self._data["eta_seconds"] = None
            self._data["total_estimate_seconds"] = None
            return
        phase_progress = {
            "starting": 0.0,
            "prepare": 0.12,
            "check": 0.28,
            "autofill": 0.58,
            "manual_review": 0.72,
            "publish": 0.86,
            "account_action": 0.5,
            "error": 0.94,
            "done": 1.0,
            "duplicate": 1.0,
            "skip": 1.0,
        }.get(str(self._data.get("phase")), 0.0)
        progress = max(0.0, min(1.0, ((max(current, 1) - 1) + phase_progress) / total))
        elapsed = time.monotonic() - self._started_monotonic
        if str(self._data.get("phase")) in {"done", "duplicate", "skip"}:
            self._data["eta_seconds"] = None
            self._data["total_estimate_seconds"] = None
            return
        if progress < 0.08 or elapsed < 2:
            self._data["eta_seconds"] = None
            self._data["total_estimate_seconds"] = None
            return
        remaining = max(0.0, elapsed * (1.0 - progress) / progress)
        self._data["eta_seconds"] = int(round(remaining))
        self._data["total_estimate_seconds"] = int(round(elapsed / progress))

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self._data)

    def add_issue(self, message: str) -> None:
        """Record a product problem without pausing the batch."""
        with self._lock:
            issues = list(self._data.get("issues", []))
            issues.append({
                "title": self._data.get("title", "目前商品"),
                "message": message,
                "time": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
            self._data["issues"] = issues[-30:]
            self._data["phase"] = "error"
            self._data["warning"] = False
            self._data["message"] = message
            self._update_eta()
            self._data["updated"] = datetime.now().astimezone().isoformat(timespec="seconds")
            self._save()

    def clear_issues(self, title: str | None = None) -> None:
        with self._lock:
            if title is None:
                self._data["issues"] = []
            else:
                self._data["issues"] = [
                    issue for issue in self._data.get("issues", [])
                    if issue.get("title") != title
                ]
            self._data["updated"] = datetime.now().astimezone().isoformat(timespec="seconds")
            self._save()


class StatusController:
    def __init__(self):
        self._lock = threading.Lock()
        self.process = None

    def start(self, action: str):
        commands = {
            "attach_publish": ["--attach", "--publish", "--non-interactive"],
            "open_chrome": ["--open-chrome"],
            "prepare": ["--prepare-only", "--non-interactive"],
            "check": ["--check", "--non-interactive"],
            "setup": ["--setup", "--non-interactive"],
            "delete_duplicates": ["--account-action", "delete_duplicates"],
            "delete_all_listings": ["--account-action", "delete_all_listings"],
            "enable_all_buy_buttons": ["--account-action", "enable_all_buy_buttons"],
            "disable_all_buy_buttons": ["--account-action", "disable_all_buy_buttons"],
        }
        if action not in commands:
            return False, "不認識的操作。"
        with self._lock:
            if self.process is not None and self.process.poll() is None:
                return False, "已有工作正在處理，請先等待完成。"
            if action in {"attach_publish", "prepare"}:
                pending_images = bool(image_files(INBOX)) if INBOX.exists() else False
                if not pending_images and INBOX.exists():
                    pending_images = any(
                        folder.is_dir() and not folder.name.startswith("_") and bool(image_files(folder))
                        for folder in INBOX.iterdir()
                    )
                if not pending_images:
                    return False, f"目前沒有照片，請先把照片放入右側的「自動分組商品」區域後再開始。支援 {IMAGE_FORMAT_LABEL}。"
            if action == "attach_publish":
                cleaned, cleanup_message = cleanup_background_processes(self)
                if not cleaned:
                    return False, f"發布前清理背景程序失敗：{cleanup_message}"
            try:
                self.process = subprocess.Popen(
                    [sys.executable, str(Path(__file__).resolve()), *commands[action]],
                    cwd=str(ROOT),
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                return True, "已開始處理。"
            except OSError as exc:
                return False, f"無法啟動工作：{exc}"

    def start_preview(self, product: str):
        if not product or Path(product).name != product:
            return False, "無效的商品名稱。"
        with self._lock:
            if self.process is not None and self.process.poll() is None:
                return False, "已有工作正在處理，請先等待完成。"
            try:
                self.process = subprocess.Popen(
                    [
                        sys.executable,
                        str(Path(__file__).resolve()),
                        "--attach",
                        "--manual-preview",
                        "--product",
                        product,
                        "--non-interactive",
                    ],
                    cwd=str(ROOT),
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                return True, f"已開始預覽「{product}」，不會自動發布。"
            except OSError as exc:
                return False, f"無法啟動預覽工作：{exc}"

    def stop(self):
        with self._lock:
            pids: set[int] = set()
            if self.process is not None and self.process.poll() is None:
                pids.add(int(self.process.pid))
            try:
                worker_pid = int(WORKER_PID_FILE.read_text(encoding="ascii").strip())
                if worker_pid > 0:
                    pids.add(worker_pid)
            except (OSError, ValueError):
                pass
            if not pids:
                return False
            stopped = False
            for pid in pids:
                try:
                    if os.name == "nt":
                        # Playwright has a Node driver and browser child.  A
                        # plain terminate() leaves those children running;
                        # taskkill /T stops the complete worker tree.
                        result = subprocess.run(
                            ["taskkill", "/PID", str(pid), "/T", "/F"],
                            capture_output=True,
                            text=True,
                            timeout=8,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                        )
                        stopped = stopped or result.returncode == 0
                    else:
                        os.kill(pid, 15)
                        stopped = True
                except (OSError, subprocess.SubprocessError):
                    continue
            if self.process is not None:
                try:
                    self.process.wait(timeout=3)
                except Exception:
                    pass
            try:
                WORKER_PID_FILE.unlink()
            except OSError:
                pass
            self.process = None
            return stopped


def clear_control_request() -> None:
    try:
        CONTROL_FILE.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def request_control(action: str) -> None:
    """Send a one-shot command from the dashboard process to the worker."""
    payload = {
        "action": action,
        "created": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    CONTROL_FILE.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")


def consume_control(action: str) -> bool:
    try:
        payload = json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    if payload.get("action") != action:
        return False
    clear_control_request()
    return True


def write_worker_pid() -> None:
    try:
        WORKER_PID_FILE.write_text(str(os.getpid()), encoding="ascii")
    except OSError:
        pass


def clear_worker_pid() -> None:
    try:
        current = WORKER_PID_FILE.read_text(encoding="ascii").strip()
        if current == str(os.getpid()):
            WORKER_PID_FILE.unlink()
    except (OSError, ValueError):
        pass


def load_error_products() -> dict[str, dict]:
    try:
        data = json.loads(ERROR_PRODUCTS_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError, json.JSONDecodeError):
        # Import failures from the previous run once, so upgrading an
        # existing installation does not lose products that already failed.
        try:
            report = json.loads((ROOT / "last_run.json").read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return {}
        imported = {}
        for item in report.get("failed", []):
            folder_value = str(item.get("folder", ""))
            folder_name = Path(folder_value).name
            if folder_name:
                imported[folder_name] = {
                    "folder": folder_value,
                    "title": item.get("title", folder_name),
                    "message": item.get("error", "上次處理時出現問題"),
                    "updated": report.get("finished_at", ""),
                }
        return imported
    if not isinstance(data, dict):
        return {}
    return {str(key): value for key, value in data.items() if isinstance(value, dict)}


def save_error_products(products: dict[str, dict]) -> None:
    try:
        ERROR_PRODUCTS_FILE.write_text(json.dumps(products, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError:
        pass


def mark_product_error(folder: Path, title: str, message: str) -> None:
    products = load_error_products()
    products[folder.name] = {
        "folder": str(folder),
        "title": title or folder.name,
        "message": message,
        "updated": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    save_error_products(products)


def clear_product_error(folder: Path) -> None:
    products = load_error_products()
    if folder.name in products:
        products.pop(folder.name, None)
        save_error_products(products)

STATUS_HTML = """<!doctype html>
<html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Aetheris</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#f8fafc url('/assets/ui/background.png') center/cover fixed no-repeat;font-family:"Segoe UI","Microsoft JhengHei",sans-serif;color:#334155;display:flex;align-items:center;justify-content:center}
.card{width:min(1180px,96vw);background:#ffffffec;border:1px solid #bae6fd;border-radius:28px;padding:30px;box-shadow:0 18px 55px #0f172a1c}.layout{display:grid;grid-template-columns:minmax(0,1.45fr) minmax(260px,.8fr);gap:28px}.main{min-width:0}.side{background:#f8fafc;border-radius:22px;padding:18px;border:1px solid #e2e8f0}.side h2{margin:0 0 12px;font-size:18px;color:#0f766e}.lists{display:grid;gap:12px}.list{background:#fff;border-radius:14px;padding:12px}.list h3{font-size:14px;margin:0 0 7px}.list ul{list-style:none;margin:0;padding:0;max-height:145px;overflow:auto}.list li{font-size:13px;padding:4px 0;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:6px}.list li:before{content:'📄 ';flex:0 0 auto}.file-thumb{width:28px;height:28px;object-fit:cover;border-radius:7px;border:1px solid #bae6fd;background:#f8fafc;flex:0 0 auto}.file-name{overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0}.manual-preview-btn{border:0;border-radius:8px;padding:4px 7px;background:#0e7490;color:#fff;font-size:11px;font-weight:700;cursor:pointer;flex:0 0 auto}.manual-preview-btn:disabled{opacity:.5;cursor:wait}.delete-product-btn{border:0;border-radius:7px;padding:3px 5px;background:#ffe4e6;color:#be123c;font-size:12px;cursor:pointer;flex:0 0 auto}.delete-product-btn:hover{background:#fecdd3}.delete-product-btn:disabled{opacity:.5;cursor:wait}.error-badge{color:#be123c;font-size:15px;flex:0 0 auto;cursor:help}.file-name.has-error{color:#be123c;font-weight:700}.product-thumb{display:none;width:58px;height:58px;object-fit:cover;border-radius:12px;border:1px solid #99f6e4;background:#fff;flex:0 0 auto}.product-thumb.show{display:block}.list.processing li:before{content:'⏳ ';}.list.completed li:before{content:'✅ ';}.empty{color:#94a3b8;font-size:12px}
.head{display:flex;align-items:center;gap:18px}.bear{width:96px;height:112px;display:grid;place-items:center}.bear img{max-width:96px;max-height:112px;display:block}.eyebrow{font-size:14px;color:#0891b2;font-weight:700;letter-spacing:1px}.title{margin:3px 0 0;font-size:28px;color:#0f766e}.item{margin:24px 0 14px;padding:16px 18px;background:#f0fdfa;border-radius:18px;display:flex;align-items:center;gap:12px}.item small{color:#64748b}.item strong{display:block;margin-top:4px;font-size:20px;color:#134e4a;word-break:break-word}.bar{height:16px;background:#e2e8f0;border-radius:99px;overflow:hidden}.fill{height:100%;width:0;background:linear-gradient(90deg,#2dd4bf,#06b6d4);border-radius:99px;transition:width .4s ease}.row{display:flex;justify-content:space-between;gap:12px;margin:9px 0 20px;font-size:14px;color:#64748b}.message{font-size:19px;font-weight:700;color:#0f766e;min-height:30px}.reference-link{display:none;margin-top:8px;font-size:13px}.reference-link.show{display:block}.reference-link a{color:#0369a1;font-weight:700}.message.warning{color:#be123c;background:#fff1f2;border:1px solid #fda4af;padding:12px 14px;border-radius:12px}.dropzone{margin:10px auto 0;width:150px;height:150px;border:3px dashed #67e8f9;border-radius:22px;background:#ecfeff;display:flex;align-items:center;justify-content:center;text-align:center;padding:25px;color:#0e7490;cursor:pointer;transition:.2s}.dropzone.dragover,.dropzone:hover{border-color:#0f766e;background:#ccfbf1;transform:translateY(-1px)}.upload-guide{margin:4px 0 8px;color:#64748b;font-size:12px;line-height:1.45}.dropzone strong{display:block;font-size:15px;color:#0f766e}.dropzone span{display:block;margin-top:5px;font-size:11px;color:#64748b}.dropzone img{width:100px;height:70px;object-fit:contain;display:block;margin:0 auto 5px}.dropzone input{display:none}.steps{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:22px}.step{text-align:center;font-size:13px;color:#94a3b8}.dot{width:48px;height:48px;margin:0 auto 7px;border-radius:50%;display:grid;place-items:center;background:#e2e8f0;font-size:20px}.dot img{width:31px;height:31px;object-fit:contain}.step.active,.step.done{color:#0f766e}.step.active .dot{background:#a7f3d0;animation:pulse 1.2s infinite}.step.done .dot{background:#ccfbf1}@keyframes pulse{50%{transform:scale(1.08)}}.actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:24px}.btn{border:0;border-radius:13px;padding:11px 14px;font-weight:700;cursor:pointer;color:#fff;background:#0f766e}.btn.secondary{background:#0e7490}.btn.light{background:#64748b}.btn.stop{background:#e11d48}.btn.skip{background:#f59e0b;display:none}.btn:disabled{opacity:.5;cursor:wait}.notice{min-height:22px;margin-top:12px;color:#0f766e;font-size:14px}.download-note{margin:0 0 8px;color:#64748b;font-size:11px;line-height:1.4}.completion-modal{position:fixed;inset:0;z-index:20;display:none;align-items:center;justify-content:center;background:#0f172a66;backdrop-filter:blur(4px)}.completion-modal.show{display:flex}.completion-card{position:relative;width:min(460px,90vw);padding:30px;border:1px solid #99f6e4;border-radius:26px;background:#fff;box-shadow:0 22px 70px #0f172a44;text-align:center;animation:completion-pop .45s cubic-bezier(.2,.8,.2,1)}.completion-card .celebrate{font-size:58px;animation:completion-bounce 1s ease-in-out infinite}.completion-card h2{margin:8px 0;color:#0f766e;font-size:25px}.completion-card p{margin:0;color:#64748b}.summary-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:22px 0}.summary-stat{padding:12px 8px;border-radius:15px;background:#f0fdfa}.summary-stat strong{display:block;font-size:25px;color:#0f766e}.summary-stat span{font-size:12px;color:#64748b}.completion-close{border:0;border-radius:12px;padding:10px 24px;background:#0f766e;color:#fff;font-weight:700;cursor:pointer}@keyframes completion-pop{from{opacity:0;transform:scale(.8) translateY(20px)}to{opacity:1;transform:scale(1) translateY(0)}}@keyframes completion-bounce{50%{transform:translateY(-8px)}}.download-actions{display:grid;gap:7px;margin-top:10px}.download-actions .btn{width:100%;padding:9px 10px;font-size:12px}.issues{margin-top:10px;max-height:180px;overflow:auto;text-align:left}.issue{margin-top:7px;padding:8px 10px;border-left:4px solid #fb7185;background:#fff1f2;border-radius:8px;color:#9f1239;font-size:12px}.issue strong{display:block;font-size:12px}.issue small{display:block;margin-top:3px;color:#be123c}.foot{margin-top:20px;font-size:12px;color:#94a3b8;text-align:right}@media(max-width:800px){.layout{grid-template-columns:1fr}.side{order:2}}

/* UI refresh: airy lavender-blue workspace with clearer hierarchy */
:root{--ink:#172554;--muted:#64748b;--brand:#4f46e5;--brand-2:#7c3aed;--mint:#0f766e;--line:#dbe4f0;--soft:#f6f8ff}
body{padding:28px 18px;align-items:flex-start;background:radial-gradient(circle at 8% 8%,#e0f2fe 0,transparent 31%),radial-gradient(circle at 92% 4%,#ede9fe 0,transparent 30%),linear-gradient(135deg,#f8fbff 0%,#f5f3ff 48%,#f0fdfa 100%);color:var(--ink)}
body:before,body:after{content:'';position:fixed;z-index:-1;border-radius:999px;filter:blur(3px);pointer-events:none;opacity:.5}body:before{width:220px;height:220px;right:-70px;bottom:8%;background:#c4b5fd}body:after{width:160px;height:160px;left:-55px;bottom:18%;background:#99f6e4}
.card{width:min(1240px,97vw);padding:24px;background:rgba(255,255,255,.78);border:1px solid rgba(255,255,255,.9);border-radius:32px;box-shadow:0 24px 70px rgba(30,41,59,.14),0 3px 12px rgba(79,70,229,.06);backdrop-filter:blur(18px)}
.layout{grid-template-columns:minmax(0,1.55fr) minmax(290px,.82fr);gap:24px}.main{padding:4px 4px 0}.side{padding:16px;background:rgba(248,250,252,.8);border:1px solid rgba(203,213,225,.8);border-radius:24px;box-shadow:inset 0 1px 0 #fff}
.head{position:relative;min-height:118px;padding:18px 22px;border-radius:24px;overflow:hidden;background:linear-gradient(120deg,#eef2ff 0%,#f5f3ff 48%,#ecfeff 100%);border:1px solid #e0e7ff;box-shadow:0 12px 28px rgba(79,70,229,.08)}.head:after{content:'自動化工作台';position:absolute;right:20px;top:18px;padding:6px 10px;border-radius:999px;background:#ffffffa6;color:#6366f1;font-size:11px;font-weight:800;letter-spacing:.5px}.bear{width:102px;height:92px;padding:8px;border-radius:22px;background:#ffffffb8;box-shadow:0 8px 20px rgba(79,70,229,.1)}.bear img{max-width:88px;max-height:82px}.eyebrow{font-size:12px;letter-spacing:1.5px;color:#6366f1}.title{font-size:30px;line-height:1.15;color:var(--ink);letter-spacing:-.5px}
.item{margin:18px 0 12px;padding:17px 19px;background:#fff;border:1px solid #e5e7eb;border-radius:20px;box-shadow:0 8px 20px rgba(15,23,42,.05)}.item small{font-size:12px;color:#8b5cf6;font-weight:700}.item strong{font-size:20px;color:#1e293b}.product-thumb{width:62px;height:62px;border-radius:16px;border:2px solid #e0e7ff}
.message{display:inline-flex;align-items:center;min-height:34px;margin:5px 0 10px;padding:6px 12px;border-radius:999px;background:#eef2ff;color:#4338ca;font-size:14px}.message.warning{display:flex;border-radius:14px;background:#fff1f2}
.bar{height:13px;padding:2px;background:#e2e8f0;border:1px solid #dbe4f0}.fill{background:linear-gradient(90deg,#6366f1,#8b5cf6 52%,#06b6d4);box-shadow:0 0 12px #818cf866}.row{align-items:center;margin:10px 2px 16px;font-size:12px}.row span{padding:4px 8px;border-radius:8px;background:#f8fafc}.row #phase{color:#4f46e5;font-weight:700;background:#eef2ff}.row #eta{background:#ecfeff;color:#0f766e}
.steps{grid-template-columns:repeat(4,1fr);gap:10px;margin-top:18px}.step{padding:10px 5px;border:1px solid #e5e7eb;border-radius:16px;background:#fff;font-size:12px;box-shadow:0 4px 12px rgba(15,23,42,.035)}.dot{width:42px;height:42px;margin-bottom:6px;background:#f1f5f9}.dot img{width:27px;height:27px}.step.active{color:#4338ca;border-color:#c7d2fe;background:#eef2ff}.step.active .dot{background:#c7d2fe;animation:pulse 1.2s infinite}.step.done{color:#0f766e;border-color:#99f6e4;background:#f0fdfa}.step.done .dot{background:#ccfbf1}
.actions{gap:8px;margin-top:19px}.btn{padding:11px 15px;border-radius:12px;background:linear-gradient(135deg,#4f46e5,#6366f1);box-shadow:0 6px 14px rgba(79,70,229,.18);transition:transform .18s,box-shadow .18s,filter .18s}.btn:hover:not(:disabled){transform:translateY(-2px);filter:saturate(1.08);box-shadow:0 10px 20px rgba(79,70,229,.22)}.btn.secondary{background:linear-gradient(135deg,#0891b2,#06b6d4)}.btn.light{background:#475569;box-shadow:0 5px 12px rgba(71,85,105,.15)}.btn.stop{background:linear-gradient(135deg,#e11d48,#f43f5e)}.notice{min-height:24px;margin-top:10px;font-size:13px;color:#4f46e5}
.side h2{padding:8px 10px;margin:-2px 0 11px;font-size:16px;color:#4338ca}.lists{gap:10px}.list{padding:12px;background:#fff;border:1px solid #e8edf5;border-radius:17px;box-shadow:0 5px 14px rgba(15,23,42,.035)}.list h3{display:flex;align-items:center;gap:6px;margin-bottom:8px;color:#334155;font-size:13px}.list ul{max-height:132px}.list li{padding:5px 0;font-size:12px}.file-thumb{width:31px;height:31px;border-radius:9px;border-color:#dbe4f0}.manual-preview-btn{background:#eef2ff;color:#4338ca;border:1px solid #c7d2fe}.manual-preview-btn:hover{background:#e0e7ff}.delete-product-btn{background:#fff1f2}.dropzone{width:100%;height:116px;margin:10px 0 0;border:2px dashed #a5b4fc;border-radius:16px;background:linear-gradient(135deg,#f8faff,#f5f3ff);padding:14px;transition:.2s}.dropzone:hover,.dropzone.dragover{border-color:#6366f1;background:#eef2ff;transform:translateY(-1px);box-shadow:0 8px 18px rgba(99,102,241,.12)}.dropzone img{width:70px;height:44px;margin:0 auto 3px}.dropzone strong{font-size:13px;color:#4338ca}.dropzone span{font-size:10px}.upload-guide{font-size:11px;line-height:1.45;color:#64748b}.download-note{padding:7px 9px;border-radius:10px;background:#f8fafc;font-size:10px}.download-actions{grid-template-columns:1fr 1fr;gap:7px}.download-actions .btn{font-size:11px;padding:9px 6px}.issues{max-height:170px}.issue{border-left-width:3px;border-radius:10px}.foot{margin-top:15px;font-size:11px}
.completion-card{border:1px solid #ddd6fe;border-radius:28px;background:linear-gradient(145deg,#fff,#f5f3ff);box-shadow:0 24px 80px #312e8140}.summary-stat{background:#eef2ff;border:1px solid #e0e7ff}.summary-stat strong{color:#4f46e5}.completion-close{background:linear-gradient(135deg,#4f46e5,#7c3aed);box-shadow:0 7px 16px #6366f144}
@media(max-width:800px){body{padding:12px 8px}.card{padding:14px;border-radius:24px}.head{padding:14px;min-height:102px}.head:after{display:none}.bear{width:78px;height:76px}.bear img{max-width:70px;max-height:66px}.title{font-size:23px}.steps{gap:5px}.step{font-size:10px;padding:7px 2px}.dot{width:34px;height:34px}.dot img{width:22px;height:22px}.row{flex-wrap:wrap}.download-actions{grid-template-columns:1fr}}

.environment-result{margin-top:10px;padding:10px;border-radius:14px;background:#f8fafc;border:1px solid #e2e8f0}.environment-empty{font-size:11px;line-height:1.45;color:#94a3b8}.environment-summary{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px;font-size:11px;font-weight:800}.environment-summary.ok{color:#047857}.environment-summary.missing{color:#be123c}.environment-time{font-size:10px;font-weight:500;color:#94a3b8}.environment-item{display:flex;align-items:flex-start;gap:7px;padding:7px 0;border-top:1px solid #e5e7eb;font-size:11px;line-height:1.35}.environment-item:first-of-type{border-top:0}.environment-icon{width:18px;height:18px;display:grid;place-items:center;flex:0 0 auto;border-radius:50%;font-size:10px;font-weight:900}.environment-item.ok .environment-icon{background:#d1fae5;color:#047857}.environment-item.missing .environment-icon{background:#ffe4e6;color:#be123c}.environment-item.warning .environment-icon{background:#fef3c7;color:#b45309}.environment-copy{min-width:0;flex:1}.environment-label{display:block;font-weight:800;color:#334155}.environment-detail{display:block;color:#64748b;word-break:break-word}.environment-missing-note{margin-top:7px;padding:7px 8px;border-radius:9px;background:#fff1f2;color:#be123c;font-size:10px;line-height:1.4}

.bug-feedback{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:14px;padding:11px 13px;border:1px solid #fecdd3;border-radius:15px;background:linear-gradient(135deg,#fff7ed,#fff1f2)}.bug-feedback-copy{display:flex;align-items:center;gap:9px;min-width:0}.bug-feedback-icon{display:grid;place-items:center;width:30px;height:30px;border-radius:10px;background:#ffe4e6;font-size:17px;flex:0 0 auto}.bug-feedback-copy strong{display:block;font-size:12px;color:#9f1239}.bug-feedback-copy small{display:block;margin-top:2px;font-size:10px;color:#be123c}.bug-feedback-link{padding:7px 10px;border-radius:10px;background:#fff;color:#be123c;border:1px solid #fda4af;font-size:11px;font-weight:800;text-decoration:none;white-space:nowrap;transition:.18s}.bug-feedback-link:hover{background:#ffe4e6;transform:translateY(-1px)}.bug-feedback-link span{font-size:13px}@media(max-width:560px){.bug-feedback{align-items:flex-start;flex-direction:column}.bug-feedback-link{width:100%;text-align:center}}

/* Editorial / Awwwards-inspired redesign */
:root{--paper:#f4ead8;--paper-light:#fbf7ef;--ink:#171717;--ink-soft:#4b4b47;--orange:#f2b45b;--orange-deep:#d88b2b;--hair:#252525}
html{background:#f4ead8}body{padding:0;display:block;min-height:100vh;background:#f4ead8;color:var(--ink);font-family:"Arial","Microsoft JhengHei",sans-serif;letter-spacing:.01em}
body:before,body:after{display:none}.card{position:relative;width:min(1240px,calc(100vw - 70px));min-height:100vh;margin:0 auto;padding:0 46px 42px;background:var(--paper);border:0;border-radius:0;box-shadow:none;backdrop-filter:none}.card:before{content:'';position:absolute;z-index:0;left:0;top:0;width:14px;height:126px;background:var(--orange)}.editorial-bar{position:relative;z-index:1;display:flex;align-items:center;gap:25px;min-height:126px;margin:0 -46px 0;padding:0 42px 0 58px;background:#faead0;border-bottom:1px solid #e8d4b5}.brand-mark{font-size:37px;font-weight:900;letter-spacing:-3px}.brand-name{font-size:11px;font-weight:800;letter-spacing:1.6px;color:#6b6255}.editorial-nav{display:flex;align-items:center;gap:22px;margin-left:auto;font-size:12px;font-weight:700;color:#5f574d}.editorial-nav span{cursor:default}.live-mark{display:flex;align-items:center;gap:6px;padding-left:19px;border-left:1px solid #cdbb9e;font-size:10px;font-weight:800;letter-spacing:1px;color:#746a5b}.live-mark i{display:block;width:7px;height:7px;border-radius:50%;background:#28a269;box-shadow:0 0 0 3px #28a26922}
.layout{position:relative;z-index:1;grid-template-columns:minmax(0,1.65fr) minmax(290px,.75fr);gap:46px;padding-top:45px}.main{padding:0;min-width:0}.side{padding:0 0 0 30px;background:transparent;border:0;border-left:1px solid #b8aa95;border-radius:0;box-shadow:none}
.head{position:relative;display:flex;align-items:flex-end;min-height:250px;margin:0 0 29px;padding:0 0 27px;background:transparent;border:0;border-bottom:2px solid var(--hair);border-radius:0;box-shadow:none;overflow:visible}.head:after{content:'STATUS / 001';top:auto;right:0;bottom:10px;padding:0;background:none;color:#8b7b64;font-size:9px;letter-spacing:1.4px}.bear{position:absolute;right:2%;bottom:19px;width:180px;height:180px;padding:0;border-radius:0;background:transparent;box-shadow:none;display:grid;place-items:end}.bear img{max-width:180px;max-height:180px;filter:drop-shadow(0 14px 0 rgba(35,27,18,.08))}.head>div:last-child{position:relative;z-index:1;max-width:78%}.eyebrow{font-size:11px;letter-spacing:2.2px;color:#78664d;font-weight:800}.title{margin:12px 0 0;font-family:"Arial Black","Arial",sans-serif;font-size:clamp(43px,6.1vw,83px);line-height:.91;letter-spacing:-4px;color:var(--ink);text-transform:uppercase}
.item{margin:0 0 15px;padding:16px 0;background:transparent;border:0;border-bottom:1px solid #b8aa95;border-radius:0;box-shadow:none}.item small{font-size:10px;letter-spacing:1px;text-transform:uppercase;color:#89775f}.item strong{margin-top:7px;font-family:"Arial Black","Arial",sans-serif;font-size:23px;line-height:1.05;color:var(--ink)}.product-thumb{width:58px;height:58px;border-radius:0;border:1px solid var(--ink);background:#f8f2e8}
.message{display:block;min-height:22px;margin:19px 0 13px;padding:0;border-radius:0;background:none;color:#615849;font-size:13px;font-weight:700}.message:before{content:'↳ ';color:var(--orange-deep)}.message.warning{display:block;padding:10px 12px;border:1px solid #b74337;border-radius:0;background:#fae3d9;color:#992f27}.bar{height:7px;padding:0;background:#d2c5b2;border:0;border-radius:0;overflow:hidden}.fill{background:var(--ink);border-radius:0;box-shadow:none}.row{align-items:center;margin:11px 0 25px;color:#736958;font-size:10px;letter-spacing:.35px}.row span{padding:0;background:transparent;border-radius:0}.row #phase{color:var(--ink);font-weight:900;background:transparent;text-transform:uppercase}.row #eta{color:#736958;background:transparent}
.steps{grid-template-columns:repeat(4,1fr);gap:0;margin-top:0;border-top:1px solid var(--hair);border-bottom:1px solid #b8aa95}.step{position:relative;padding:14px 8px 13px;border:0;border-right:1px solid #b8aa95;border-radius:0;background:transparent;box-shadow:none;text-align:left;font-size:10px;letter-spacing:.4px;text-transform:uppercase}.step:last-child{border-right:0}.dot{width:27px;height:27px;margin:0 0 10px;border-radius:0;background:#e1d4c0;font-size:14px}.dot img{width:18px;height:18px;filter:grayscale(1)}.step.active,.step.done{color:var(--ink);border-color:#b8aa95;background:#efe2cc}.step.active .dot{background:var(--orange);animation:pulse 1.2s infinite}.step.done .dot{background:#b7d4b8}.step.active:after{content:'NOW';position:absolute;top:14px;right:8px;font-size:8px;color:#8d5c1d;letter-spacing:1px}
.actions{gap:7px;margin-top:23px}.btn{padding:11px 14px;border:1px solid var(--ink);border-radius:0;background:var(--ink);box-shadow:none;font-size:11px;letter-spacing:.2px;transition:background .18s,color .18s,transform .18s}.btn:hover:not(:disabled){transform:translateY(-2px);background:var(--orange);color:var(--ink);box-shadow:none;filter:none}.btn.secondary{background:transparent;color:var(--ink)}.btn.secondary:hover:not(:disabled){background:var(--ink);color:#fff}.btn.light{background:#e2d6c4;color:var(--ink);border-color:#b8aa95}.btn.stop{background:#b74337;border-color:#b74337;color:#fff}.notice{min-height:20px;margin-top:11px;color:#716452;font-size:11px}.issues{margin-top:9px;max-height:170px}.issue{border-left:3px solid #b74337;border-radius:0;background:#fae3d9;color:#8e3027}
.side h2{padding:0 0 14px;margin:0 0 18px;border-bottom:2px solid var(--hair);color:var(--ink);font-family:"Arial Black","Arial",sans-serif;font-size:18px;letter-spacing:-.3px}.lists{gap:0}.list{padding:0 0 18px;margin:0 0 18px;background:transparent;border:0;border-bottom:1px solid #b8aa95;border-radius:0;box-shadow:none}.list h3{margin:0 0 9px;color:#5f574d;font-size:10px;letter-spacing:1.5px;text-transform:uppercase}.list ul{max-height:128px}.list li{padding:5px 0;color:#4e4a43;font-size:11px;border-bottom:1px dotted #d0c3b2}.file-thumb{width:28px;height:28px;border:1px solid #9f927f;border-radius:0}.manual-preview-btn{border:1px solid #b8aa95;border-radius:0;padding:4px 6px;background:transparent;color:var(--ink);font-size:9px}.manual-preview-btn:hover{background:var(--ink);color:#fff}.delete-product-btn{border-radius:0;background:transparent;color:#b74337}.dropzone{width:100%;height:106px;margin:10px 0 0;border:1px dashed #6e6559;border-radius:0;background:transparent;padding:12px;box-shadow:none}.dropzone:hover,.dropzone.dragover{border-color:var(--orange-deep);background:#faead0;transform:none;box-shadow:none}.dropzone img{width:60px;height:37px;margin:0 auto 2px;filter:grayscale(.35)}.dropzone strong{font-size:11px;color:var(--ink);letter-spacing:.5px}.dropzone span{font-size:9px;color:#746957}.upload-guide{font-size:10px;line-height:1.5;color:#786b59}.download-note{padding:7px 8px;border-radius:0;background:#ecdfca;font-size:9px;color:#716452}.download-actions{grid-template-columns:1fr 1fr;gap:6px}.download-actions .btn{font-size:9px;padding:9px 5px}.environment-result{border-radius:0;background:transparent;border:1px solid #b8aa95}.environment-summary{font-size:10px}.environment-item{font-size:10px}.bug-feedback{border:1px solid #b8aa95;border-radius:0;background:transparent}.bug-feedback-icon{border-radius:0;background:#fae3d9}.bug-feedback-link{border-radius:0;border:1px solid var(--ink);background:transparent;color:var(--ink);font-size:9px}.bug-feedback-link:hover{background:var(--ink);color:#fff}.foot{margin-top:13px;font-size:9px;letter-spacing:.3px;color:#8e806e;text-align:left}
.completion-modal{background:#171717aa}.completion-card{border:1px solid var(--ink);border-radius:0;background:var(--paper-light);box-shadow:12px 12px 0 var(--orange)}.summary-stat{border-radius:0;background:#ecdfca;border:0}.summary-stat strong{color:var(--ink)}.completion-close{border-radius:0;background:var(--ink);box-shadow:none}.reference-link a{color:#8d5c1d}.download-actions .btn:hover:not(:disabled){background:var(--orange)}
@media(max-width:900px){.card{width:100%;padding:0 24px 32px}.editorial-bar{margin:0 -24px;padding:0 28px 0 39px}.brand-name,.editorial-nav{display:none}.layout{grid-template-columns:1fr;gap:30px;padding-top:30px}.side{padding:25px 0 0;border-left:0;border-top:1px solid #b8aa95}.head{min-height:210px}.bear{right:0;width:145px;height:145px}.bear img{max-width:145px;max-height:145px}}
@media(max-width:560px){.card{padding:0 15px 25px}.card:before{width:9px;height:94px}.editorial-bar{min-height:94px;margin:0 -15px;padding:0 22px 0 31px}.brand-mark{font-size:31px}.live-mark{margin-left:auto;padding-left:10px;font-size:8px}.head{min-height:188px;padding-bottom:20px}.head>div:last-child{max-width:100%}.title{font-size:44px;letter-spacing:-2px}.bear{right:-6px;bottom:15px;width:105px;height:105px}.bear img{max-width:105px;max-height:105px;opacity:.78}.steps{grid-template-columns:repeat(2,1fr)}.step:nth-child(2){border-right:0}.step:nth-child(-n+2){border-bottom:1px solid #b8aa95}.actions .btn{flex:1 1 calc(50% - 7px)}}

/* Contrast pass: make operational information unmistakable */
.item{position:relative;margin:0 0 17px;padding:17px 18px;background:#fffaf1;border:1px solid #9d8b72;border-left:7px solid var(--orange-deep);border-bottom:2px solid var(--hair);box-shadow:5px 5px 0 #e4d4ba}.item small{color:#72501e;font-size:11px}.item strong{font-size:25px}.message{display:block;min-height:0;margin:17px 0 12px;padding:9px 12px;border:1px solid #aa8d62;border-left:5px solid var(--orange-deep);background:#fffaf1;color:#29251f;font-size:14px}.message:before{font-weight:900}.message.warning{border-width:1px 1px 1px 6px;background:#f8d9cf;color:#822c24;font-weight:800}.bar{height:11px;background:#cbb99d;border:1px solid #7e6e59}.fill{background:linear-gradient(90deg,#c87920,#f2b45b);box-shadow:0 0 0 1px #9a5d18 inset}.row{margin:10px 0 22px;color:#5e5345;font-size:11px;font-weight:700}.row #phase{padding:5px 9px;background:var(--ink);color:#fff}.row #eta{padding:5px 9px;background:var(--orange);color:var(--ink);font-weight:900}.steps{border-top:2px solid var(--hair);border-bottom:2px solid var(--hair)}.step{font-weight:700;color:#6b5d4c}.step.active{background:#f2b45b;color:#171717}.step.active .dot{background:#171717}.step.active .dot img{filter:brightness(0) invert(1)}.step.done{background:#d8e5d1;color:#1f4a32}.step.done .dot{background:#47815c}.step.done .dot img{filter:brightness(0) invert(1)}
.actions .btn:first-child{background:var(--orange-deep);color:#fff;border-color:#9c5c17;font-size:12px;font-weight:900}.actions .btn:first-child:hover:not(:disabled){background:#f7bd63;color:#171717}.actions .btn.secondary{border-width:2px;font-weight:900}.btn.stop{font-weight:900}.notice{padding:6px 8px;border-left:3px solid #8d7655;background:#efe2cd;color:#322b22;font-weight:700}.side{border-left:2px solid #7e6e59}.side h2{font-size:20px;color:#171717;border-bottom:3px solid var(--hair)}.list{padding:12px;margin:0 0 12px;background:#fbf5e9;border:1px solid #b8a58a;border-bottom:2px solid #7e6e59}.list h3{font-weight:900;color:#27231d}.list li{color:#29251f;border-bottom-color:#c7b99f}.list.completed h3{color:#28613f}.list.processing{border:2px solid var(--orange-deep);background:#fffaf1;box-shadow:4px 4px 0 #e4d4ba}.list.processing h3{color:#8d5c1d}.list.processing li{font-weight:700}.list.processing li:before{color:#c87920}.list.completed li:before{color:#28613f}.list .empty{color:#80715e}.dropzone{height:108px;border:2px dashed var(--orange-deep);background:#fffaf1}.dropzone strong{font-weight:900}.download-note{background:#e9dcc6;border:1px solid #b8a58a;color:#4c4030}.download-actions .btn{font-weight:900}.environment-result{border:2px solid #a68d68;background:#fffaf1}.environment-summary.ok{color:#12663f}.environment-summary.missing{font-weight:900}.bug-feedback{border:1px solid #a68d68;background:#fffaf1}.error-badge{font-size:17px}.file-name.has-error{font-weight:900}.completion-card{border:2px solid var(--hair)}
@media(max-width:560px){.item{padding:14px 12px}.item strong{font-size:21px}.side{border-left:0}.actions .btn:first-child{flex-basis:100%}}

/* Typography pass: optimize Traditional Chinese readability */
body{font-family:"Microsoft JhengHei UI","Microsoft JhengHei","Noto Sans TC","Segoe UI",Arial,sans-serif;font-size:14px;line-height:1.55;-webkit-font-smoothing:antialiased}.editorial-bar{font-size:13px}.brand-name{font-size:12px;color:#40382f}.editorial-nav{font-size:13px;color:#302c26}.live-mark{font-size:11px;color:#40382f}.eyebrow{font-size:13px;color:#5e451f;letter-spacing:1.5px}.title{font-family:"Microsoft JhengHei UI","Microsoft JhengHei","Segoe UI",Arial,sans-serif;font-weight:900;letter-spacing:-2px;line-height:1.03}.head:after{font-size:10px;color:#5f513f}.item small{font-size:12px}.item strong{font-family:"Microsoft JhengHei UI","Microsoft JhengHei","Segoe UI",Arial,sans-serif;font-size:25px;line-height:1.25}.message{font-size:15px;line-height:1.55}.row{font-size:12px;line-height:1.5}.steps .step{font-size:12px;line-height:1.45;letter-spacing:0;text-transform:none}.step.active:after{font-size:9px}.btn{font-size:12px;line-height:1.35}.notice{font-size:13px;line-height:1.5}.side h2{font-family:"Microsoft JhengHei UI","Microsoft JhengHei","Segoe UI",Arial,sans-serif;font-size:20px;line-height:1.3}.list h3{font-size:12px;letter-spacing:.5px;text-transform:none;line-height:1.45}.list li{font-size:13px;line-height:1.5;color:#171717}.upload-guide{font-size:12px;line-height:1.6;color:#40382f}.dropzone strong{font-size:13px}.dropzone span{font-size:11px}.download-note{font-size:11px;line-height:1.55;color:#302c26}.download-actions .btn{font-size:12px}.environment-summary{font-size:12px}.environment-item{font-size:12px;line-height:1.5}.environment-label{font-size:12px;color:#171717}.environment-detail{font-size:11px;color:#4c4030}.bug-feedback-copy strong{font-size:13px}.bug-feedback-copy small{font-size:11px}.bug-feedback-link{font-size:11px}.foot{font-size:10px;color:#5f513f}

.open-folder-btn{flex:0 0 auto;border:1px solid #8d7655;border-radius:0;padding:3px 6px;background:#f4e5cb;color:#171717;font-size:13px;line-height:1;cursor:pointer;transition:.16s}.open-folder-btn:hover{background:#f2b45b;border-color:#9c5c17;transform:translateY(-1px)}.open-folder-btn:disabled{opacity:.5;cursor:wait}

.open-root-btn{margin-left:auto;border:1px solid #8d7655;border-radius:0;padding:4px 7px;background:#f4e5cb;color:#171717;font-family:inherit;font-size:10px;font-weight:800;line-height:1.2;cursor:pointer;white-space:nowrap;transition:.16s}.open-root-btn:hover{background:#f2b45b;border-color:#9c5c17;transform:translateY(-1px)}.open-root-btn:disabled{opacity:.5;cursor:wait}.list h3{display:flex;align-items:center;gap:7px}

/* Mascot placement: keep the chestnut on the left of the hero title */
.head{padding-left:190px}.head>div:last-child{max-width:100%}.bear{left:0;right:auto;bottom:19px}.head:after{right:0}@media(max-width:900px){.head{padding-left:155px}.bear{left:0;right:auto}}@media(max-width:560px){.head{padding-left:106px}.bear{left:0;right:auto;bottom:15px}}

/* Show a useful batch of issue records at once */
.issues{max-height:520px;overflow-y:auto;padding-right:5px}.issue{margin-top:10px;padding:10px 12px}.issue strong{font-size:13px}.issue small{font-size:11px}.solution-guide{margin:10px 0 14px;padding:14px 16px;border:1px solid #c7a56b;background:#fffaf1;color:#3d3428}.solution-guide h4{margin:0 0 8px;color:#171717;font-size:16px;font-weight:900}.solution-guide p{margin:0 0 8px;font-size:12px;line-height:1.55}.solution-guide ol{margin:6px 0 0 20px;padding:0}.solution-guide li{padding:3px 0 3px 3px;font-size:12px;line-height:1.55}.solution-guide li>strong{display:block;color:#30271c;font-size:13px}.solution-guide ul{margin:4px 0 0 18px;padding:0}.solution-guide ul li{padding:2px 0}.issues::-webkit-scrollbar{width:9px}.issues::-webkit-scrollbar-thumb{background:#b8a58a;border-radius:0}.issues::-webkit-scrollbar-track{background:#ecdfca}

/* Keep the bottom cards compact instead of stretching to the taller panel */
.utility-dock{align-items:start}.utility-card{align-self:start;height:fit-content;min-height:0}.utility-card.bug-feedback{align-self:start;height:fit-content;min-height:0;align-items:center}

.message:empty{display:none}

/* Keep the live file lists stable while status.json refreshes frequently. */
.step.active .dot,.list.processing{animation:none!important}
</style></head><body><main class="card"><div class="editorial-bar"><div class="brand-mark">W.</div><div class="brand-name">CAROUSELL / AUTOMATION</div><nav class="editorial-nav"><span>工作台</span><span>商品流程</span><span>環境工具</span></nav><div class="live-mark"><i></i> LOCAL LIVE</div></div><div class="layout"><section class="main"><div class="head"><div class="bear"><img src="/assets/ui/mascot.png?v=chestnut" alt="Aetheris"></div><div><div class="eyebrow">CAROUSELL 自動上架</div><div class="title">Aetheris 正在幫你處理</div></div></div>
<section class="item"><img id="productThumb" class="product-thumb" alt="商品縮圖"><div><small id="count">準備中</small><strong id="product">等待開始...</strong></div></section><div class="message" id="message">正在準備圖片...</div><div class="reference-link" id="referenceLink"><a id="referenceAnchor" target="_blank" rel="noopener">🔎 開啟 Google 圖片參考</a></div><div style="margin-top:14px" class="bar"><div id="fill" class="fill"></div></div><div class="row"><span id="phase">準備中</span><span id="eta">全部流程預計：計算中</span><span id="percent">0%</span></div>
<div class="steps"><div class="step" data-phase="prepare"><div class="dot"><img src="/assets/ui/prepare.png" alt=""></div>整理圖片</div><div class="step" data-phase="check"><div class="dot"><img src="/assets/ui/check.png" alt=""></div>檢查重複</div><div class="step" data-phase="autofill"><div class="dot"><img src="/assets/ui/autofill.png" alt=""></div>自動填寫</div><div class="step" data-phase="publish"><div class="dot"><img src="/assets/ui/publish.png" alt=""></div>發布商品</div></div>
<div class="actions"><button class="btn secondary" data-action="open_chrome">🌟 打開新 Chrome</button><button class="btn" data-action="attach_publish">🚀 接管 Chrome 發布</button><button class="btn light" data-action="prepare">🧹 整理圖片</button><button class="btn stop" data-action="stop">⏹ 停止</button><button class="btn skip" id="skipCurrent" data-action="skip_current">⏭ 跳過這件，處理下一件</button></div><div class="notice" id="notice"></div><div id="issues" class="issues"></div><section class="solution-guide" id="solutionGuide" hidden><h4>💡 解決方法</h4><p>如果你想成功重新上架這件商品，建議嘗試以下做法：</p><ol><li><strong>更換全新拍攝的實物圖片（最有效）</strong><ul><li>不要再使用原本那張白底圖，也不要單純把原圖裁剪或調色，系統的圖像識別通常能認出來。</li><li>拿實物重新拍幾張不同角度、不同背景的照片上傳。</li></ul></li><li><strong>修改標題與商品描述</strong><ul><li>避免使用與之前完全一模一樣的字眼，稍微調整標題結構並重寫描述內容。</li></ul></li><li><strong>等待冷卻時間或聯絡客服恢復原帖</strong><ul><li>如果之前是誤刪原帖，可以聯絡 Carousell 幫助中心客服，要求恢復（Restore）先前刪除的帖文。</li><li>若不急著上架，通常等待 1 至 2 星期後，再配合新照片重新發布即可。</li></ul></li></ol></section><div class="bug-feedback"><div class="bug-feedback-copy"><span class="bug-feedback-icon">🐞</span><div><strong>遇到問題？回報 Bug</strong></div></div><a class="bug-feedback-link" href="https://mail.google.com/mail/?view=cm&amp;fs=1&amp;to=Aetherishk%40gmail.com&amp;su=Carousell%20%E5%B0%8F%E5%8A%A9%E6%89%8B%20Bug%20%E5%9B%9E%E5%A0%B1&amp;body=%E8%AB%8B%E5%9C%A8%E9%80%99%E8%A3%A1%E6%8F%8F%E8%BF%B0%E5%95%8F%E9%A1%8C%EF%BC%9A" target="_blank" rel="noopener">Aetherishk@gmail.com <span>↗</span></a></div><div class="foot" id="updated">等待狀態更新...</div></section>
<aside class="side"><h2>📁 檔案進度</h2><div class="lists"><div class="list completed"><h3>✅ 已處理 <button class="open-root-btn" data-action="open_root:completed" title="開啟已完成檔案資料夾">📂 開啟資料夾</button></h3><ul id="completed"></ul></div><div class="list processing"><h3>⏳ 正在處理</h3><ul id="processing"></ul></div><div class="list"><h3>📦 未處理 <button class="open-root-btn" data-action="open_root:unprocessed" title="開啟待發布資料夾">📂 開啟資料夾</button></h3><p class="upload-guide">➕ 可一次拖入大量圖片，程序會在本機比較商品主體及不同角度，自動建立商品群組。</p><ul id="unprocessed"></ul><label class="dropzone" id="dropzone"><input id="fileInput" type="file" accept="image/*" multiple><div><img src="/assets/ui/dropzone.png" alt=""><strong>自動分組商品</strong><span>一次拖入大量圖片</span></div></label></div></div><div class="list" style="margin-top:12px"><h3>🧰 手動下載環境</h3><div class="download-note">需要版本：Python 3.13+、Pillow 10.0+、Playwright 1.45+</div><ul><li>🐍 <a href="https://www.python.org/downloads/release/python-3130/" target="_blank">Python 3.13（官方下載）</a></li><li>🌐 <a href="https://www.google.com/chrome/" target="_blank">Google Chrome 最新穩定版</a></li><li>🖼️ <a href="https://pypi.org/project/Pillow/10.0.0/" target="_blank">Pillow 10.0（Python 套件）</a></li><li>🎭 <a href="https://pypi.org/project/playwright/1.45.0/" target="_blank">Playwright 1.45（Python 套件）</a></li><li>📘 <a href="https://playwright.dev/python/docs/intro" target="_blank">Chromium 元件安裝說明</a></li></ul><div class="download-actions"><button class="btn light" data-action="check">🩺 檢查環境</button><button class="btn light" data-action="setup">🧰 一鍵安裝環境</button></div><div id="environmentResult" class="environment-result" aria-live="polite"><div class="environment-empty">按「檢查環境」查看目前電腦是否缺少必要元件。</div></div></div></aside></div></main>
<div class="completion-modal" id="completionModal"><div class="completion-card"><div class="celebrate">🎉</div><h2>這次作業完成了！</h2><p>以下是本次處理結果</p><div class="summary-grid"><div class="summary-stat"><strong id="summarySuccess">0</strong><span>已完成</span></div><div class="summary-stat"><strong id="summaryDuplicates">0</strong><span>跳過重複</span></div><div class="summary-stat"><strong id="summarySkipped">0</strong><span>手動跳過</span></div><div class="summary-stat"><strong id="summaryFailed">0</strong><span>需要留意</span></div></div><button class="completion-close" id="closeCompletion">知道了</button></div></div><div class="upload-modal" id="uploadModal"><div class="upload-card"><button class="upload-close" id="closeUpload" aria-label="關閉">×</button><div class="upload-celebrate">📥</div><h2>已新增商品</h2><p id="uploadSummary">以下商品已放入未處理</p><div class="upload-products" id="uploadProducts"></div><button class="completion-close" id="closeUploadBottom">知道了</button></div></div><script>
const labels={starting:'準備中',prepare:'整理圖片',check:'檢查帳戶刊登',autofill:'Carousell 自動填寫',manual_review:'等待你補填',publish:'發布商品',preview:'預覽已開啟（未發布）',done:'已完成',duplicate:'已跳過重複商品',skip:'已跳到下一件',error:'需要處理'};let totalEstimateSeconds=null,etaStamp='',completionKey='',etaCompleted=false;function showCompletion(summary,stamp){if(!summary||!summary.total)return;const key=(stamp||'')+JSON.stringify(summary);if(key===completionKey)return;completionKey=key;document.querySelector('#summarySuccess').textContent=summary.success||0;document.querySelector('#summaryDuplicates').textContent=summary.duplicates||0;document.querySelector('#summarySkipped').textContent=summary.skipped||0;document.querySelector('#summaryFailed').textContent=summary.failed||0;document.querySelector('#completionModal').classList.add('show')}document.querySelector('#closeCompletion').addEventListener('click',()=>document.querySelector('#completionModal').classList.remove('show'));function renderEta(){const el=document.querySelector('#eta');if(!el)return;if(totalEstimateSeconds===null){el.textContent=etaCompleted?'本次已完成':'全部流程預計：計算中';return}const h=Math.floor(totalEstimateSeconds/3600),m=Math.floor((totalEstimateSeconds%3600)/60),sec=totalEstimateSeconds%60;el.textContent=(etaCompleted?'本次總耗時：':'全部流程預計：')+(h?`${h}小時 `:'')+(m?`${m}分鐘 `:'')+`${sec}秒`;}setInterval(renderEta,1000);function renderEnvironment(report){const el=document.querySelector('#environmentResult');if(!el)return;if(!report||!Array.isArray(report.items)){el.innerHTML='<div class="environment-empty">按「檢查環境」查看目前電腦是否缺少必要元件。</div>';return}const missing=Number(report.missing_count)||0;const summary=document.createElement('div');summary.className='environment-summary '+(missing?'missing':'ok');summary.innerHTML='<span>'+(missing?'⚠️ 發現 '+missing+' 項缺失或版本不符':'✅ 環境檢查完成，全部可用')+'</span><span class="environment-time">'+(report.checked_at||'')+'</span>';el.innerHTML='';el.appendChild(summary);report.items.forEach(item=>{const row=document.createElement('div');row.className='environment-item '+(item.status||'missing');const icon=document.createElement('span');icon.className='environment-icon';icon.textContent=item.status==='ok'?'✓':(item.status==='warning'?'!':'×');const copy=document.createElement('div');copy.className='environment-copy';const label=document.createElement('span');label.className='environment-label';label.textContent=item.label;const detail=document.createElement('span');detail.className='environment-detail';detail.textContent=item.detail||item.required||'';copy.append(label,detail);row.append(icon,copy);el.appendChild(row)});if(missing){const note=document.createElement('div');note.className='environment-missing-note';note.textContent='請先按「一鍵安裝環境」，或使用上方手動下載網址補齊缺失項目。';el.appendChild(note)}}

async function refresh(){try{const r=await fetch('/status.json?'+Date.now());const s=await r.json();document.querySelector('#product').textContent=s.title||'目前沒有商品';const productThumb=document.querySelector('#productThumb');if(productThumb&&s.title&&s.title!=='Carousell 小助手'&&s.title!=='全部商品'){productThumb.src='/thumbnail?bucket=processing&name='+encodeURIComponent(s.title);productThumb.classList.add('show');productThumb.onerror=()=>productThumb.classList.remove('show')}else if(productThumb){productThumb.classList.remove('show')}document.querySelector('#count').textContent=s.total?`第 ${s.current||0} / ${s.total} 件商品`:'';document.querySelector('#message').textContent=s.message||'';document.querySelector('#phase').textContent=labels[s.phase]||s.phase||'';const referenceLink=document.querySelector('#referenceLink'),referenceAnchor=document.querySelector('#referenceAnchor');if(referenceLink&&referenceAnchor){if(s.phase==='manual_review'&&s.manual_review_url){referenceAnchor.href=s.manual_review_url;referenceLink.classList.add('show')}else{referenceLink.classList.remove('show')}}let p=Math.max(0,Math.min(100,Number(s.percent)||0));document.querySelector('#percent').textContent=p+'%';document.querySelector('#fill').style.width=p+'%';const skipButton=document.querySelector('#skipCurrent');if(skipButton){skipButton.style.display=s.phase==='manual_review'?'inline-block':'none';skipButton.disabled=false;}document.querySelector('#updated').textContent='最後更新：'+(s.updated||'');if((s.updated||'')!==etaStamp){etaStamp=s.updated||'';}if(s.environment)renderEnvironment(s.environment);etaCompleted=s.phase==='done'||s.phase==='preview';totalEstimateSeconds=Number.isFinite(Number(s.total_estimate_seconds))?Number(s.total_estimate_seconds):null;renderEta();if(s.phase==='done')showCompletion(s.completion_summary,s.updated);document.querySelectorAll('.step').forEach(x=>{let order=['prepare','check','autofill','publish'],at=order.indexOf(x.dataset.phase),now=order.indexOf(s.phase);x.classList.toggle('done',at>=0&&now>at);x.classList.toggle('active',x.dataset.phase===s.phase)});if(s.phase==='done'||s.phase==='duplicate'||s.phase==='skip'){document.querySelector('#fill').style.background='#34d399'}if(s.phase==='error'||s.phase==='manual_review'){document.querySelector('#fill').style.background=s.phase==='manual_review'?'#f59e0b':'#fb7185'}}catch(e){document.querySelector('#message').textContent='正在重新連線到本機狀態...'}}setInterval(refresh,500);refresh();
</script><script>
const listRenderKeys={};function renderList(id,items){const el=document.querySelector('#'+id);if(!el)return;const key=JSON.stringify(items||[]);if(listRenderKeys[id]===key)return;listRenderKeys[id]=key;el.innerHTML='';if(!items||!items.length){el.innerHTML='<li class="empty">'+(id==='unprocessed'?'目前沒有商品，請先放入照片':'目前沒有檔案')+'</li>';return}items.forEach(item=>{const value=typeof item==='string'?{name:item}:item;const li=document.createElement('li');if(id==='unprocessed'&&value.name){const remove=document.createElement('button');remove.type='button';remove.className='delete-product-btn';remove.dataset.action='delete_product:'+value.name;remove.textContent='刪除';remove.title='移到已刪除檔案';remove.addEventListener('click',()=>runAction(remove.dataset.action));li.appendChild(remove)}if(value.thumb){const img=document.createElement('img');img.className='file-thumb';img.alt='';img.loading='lazy';img.src=value.thumb;img.onerror=()=>img.remove();li.appendChild(img)}const name=document.createElement('span');name.className='file-name'+(value.error?' has-error':'');name.textContent=value.name||'';li.appendChild(name);if(value.error){const badge=document.createElement('span');badge.className='error-badge';badge.title=value.error;badge.textContent='error';li.appendChild(badge)}if(id==='unprocessed'&&value.name){const preview=document.createElement('button');preview.type='button';preview.className='manual-preview-btn';preview.dataset.action='manual_preview:'+value.name;preview.textContent='手動填寫';preview.addEventListener('click',()=>runAction(preview.dataset.action));li.appendChild(preview)}el.appendChild(li)})}
function renderIssues(items){const el=document.querySelector('#issues'),guide=document.querySelector('#solutionGuide');if(!el)return;el.innerHTML='';if(!items||!items.length){if(guide)guide.hidden=true;return}if(guide)guide.hidden=false;const heading=document.createElement('div');heading.innerHTML='<img src="/assets/ui/warning.png" alt="" style="width:20px;height:20px;vertical-align:middle;margin-right:5px">問題紀錄（程序會繼續）';heading.style='font-weight:700;color:#be123c;margin-bottom:4px';el.appendChild(heading);items.slice().reverse().forEach(issue=>{const row=document.createElement('div');row.className='issue';const title=document.createElement('strong');title.textContent=issue.title||'商品';const msg=document.createElement('div');msg.textContent=issue.message||'';const time=document.createElement('small');time.textContent=issue.time||'';row.append(title,msg,time);el.appendChild(row)})}
function applyFileState(s){const f=s?.files||{};renderList('completed',f.completed);renderList('processing',f.processing);renderList('unprocessed',f.unprocessed);const summary=s?.completion_summary;const cleanCompletion=s?.phase==='done'&&summary&&Number(summary.failed||0)===0;renderIssues(cleanCompletion?[]:s?.issues)}
async function refreshFiles(){try{const r=await fetch('/status.json?files='+Date.now());applyFileState(await r.json())}catch(e){}}
async function runAction(action){if(action==='delete_all_listings'&&!window.confirm('這會刪除 Carousell 帳戶內所有已刊登商品，操作不可逆。確定要繼續嗎？'))return;if(action==='toggle_all_buy_buttons'&&!window.confirm('這會逐一切換所有已刊登商品的購買按鈕。確定要繼續嗎？'))return;const buttons=[...document.querySelectorAll('[data-action]')];buttons.forEach(b=>b.disabled=true);const notice=document.querySelector('#notice');notice.textContent='正在啟動操作...';try{const r=await fetch('/action',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action='+encodeURIComponent(action)});const x=await r.json();notice.textContent=x.message||'';if(!x.ok&&x.message&&(/沒有照片|沒有找到可用的圖片|先把照片放入/.test(x.message))&&typeof showNoPhoto==='function')showNoPhoto(x.message);if(x.environment)renderEnvironment(x.environment)}catch(e){notice.textContent='無法連接本機控制服務。'}setTimeout(()=>buttons.forEach(b=>b.disabled=false),1200)}
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>runAction(b.dataset.action)));
const dropzone=document.querySelector('#dropzone'),fileInput=document.querySelector('#fileInput');
['dragenter','dragover'].forEach(type=>dropzone.addEventListener(type,e=>{e.preventDefault();dropzone.classList.add('dragover')}));
['dragleave','drop'].forEach(type=>dropzone.addEventListener(type,e=>{e.preventDefault();dropzone.classList.remove('dragover')}));
dropzone.addEventListener('drop',e=>uploadImages(e.dataTransfer.files));fileInput.addEventListener('change',e=>uploadImages(e.target.files));
async function uploadImages(files){
  if(!window.AetherisGrouping){document.querySelector('#notice').textContent='圖片分組元件未能載入，請重新開啟工具。';return;}
  return window.AetherisGrouping.upload(files);
}
</script></body></html>"""


def dashboard_html() -> str:
    """Place support and environment tools in a separated bottom dock."""
    html = STATUS_HTML
    bug_start = html.index('<div class="bug-feedback">')
    bug_end = html.index('<div class="foot" id="updated">', bug_start)
    bug = html[bug_start:bug_end].replace('<div class="bug-feedback">', '<div class="utility-card bug-feedback">', 1)
    html = html[:bug_start] + html[bug_end:]
    env_start = html.index('<div class="list" style="margin-top:12px"><h3>🧰 手動下載環境</h3>')
    env_end = html.index('</div></aside></div></main>', env_start)
    environment = html[env_start:env_end].replace('<div class="list" style="margin-top:12px">', '<div class="utility-card environment-panel">', 1)
    html = html[:env_start] + html[env_end:]
    drop_start = html.index('<label class="dropzone" id="dropzone">')
    drop_end = html.index('</label>', drop_start) + len('</label>')
    dropzone = html[drop_start:drop_end]
    html = html[:drop_start] + html[drop_end:]
    unprocessed_marker = '<div class="list"><h3>📦 未處理'
    html = html.replace(unprocessed_marker, '<div class="upload-zone-panel">' + dropzone + '</div>' + unprocessed_marker, 1)
    dock = '<section class="utility-dock" aria-label="輔助工具">' + bug + environment + '</section>'
    html = html.replace('</aside></div></main>', '</aside></div>' + dock + '</main>', 1)
    utility_css = '.utility-dock{position:relative;z-index:1;display:grid;grid-template-columns:minmax(260px,.78fr) minmax(0,1.22fr);gap:30px;margin-top:76px;padding-top:28px;border-top:2px solid var(--hair)}.utility-card{min-width:0;padding:18px 20px;border:1px solid #9d8b72;background:#fbf5e9;box-shadow:5px 5px 0 #e4d4ba}.utility-card.bug-feedback{margin-top:0;display:flex;align-items:center;justify-content:space-between;gap:16px;border-radius:0;background:#fffaf1}.utility-card.environment-panel{margin-top:0}.environment-panel>h3{display:flex;align-items:center;gap:8px;margin:0 0 12px;color:#171717;font-size:16px;font-weight:900}.environment-panel>ul{max-height:180px;margin:0 0 12px;padding:0;list-style:none;overflow:auto}.environment-panel>ul li{padding:6px 0;border-bottom:1px dotted #c7b99f;font-size:13px;line-height:1.5}.environment-panel .download-note{margin-bottom:10px}.environment-panel .environment-result{margin-top:12px}.utility-dock .bug-feedback-copy strong{font-size:14px}.utility-dock .bug-feedback-copy small{font-size:12px}.utility-dock .bug-feedback-link{font-size:12px;padding:9px 12px}.utility-dock .bug-feedback-icon{width:34px;height:34px}.utility-dock .download-actions{margin-top:8px}@media(max-width:900px){.utility-dock{grid-template-columns:1fr;gap:22px;margin-top:52px}}@media(max-width:560px){.utility-dock{margin-top:40px;padding-top:20px}.utility-card{padding:14px}.utility-card.bug-feedback{align-items:flex-start;flex-direction:column}.utility-dock .bug-feedback-link{width:100%;text-align:center}.environment-panel>ul{max-height:150px}}'
    upload_css = '.upload-modal{position:fixed;inset:0;z-index:30;display:none;align-items:center;justify-content:center;padding:18px;background:#171717aa;backdrop-filter:blur(5px)}.upload-modal.show{display:flex}.upload-card{position:relative;width:min(700px,94vw);max-height:88vh;overflow:auto;padding:30px 32px;border:2px solid var(--hair);background:var(--paper-light);box-shadow:12px 12px 0 var(--orange);text-align:center}.upload-close{position:absolute;top:10px;right:13px;border:0;background:transparent;color:var(--ink);font-size:28px;line-height:1;cursor:pointer}.upload-celebrate{font-size:40px}.upload-card h2{margin:5px 0;color:var(--ink);font-size:25px}.upload-card p{margin:0 0 17px;color:var(--ink-soft);font-size:13px}.upload-products{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:15px 0 20px;text-align:left}.upload-product{padding:10px;border:1px solid #b8a58a;background:#fbf5e9}.upload-product img{display:block;width:100%;height:130px;object-fit:cover;margin-bottom:8px;border:1px solid #c7b99f;background:#fff}.upload-product strong{display:block;color:var(--ink);font-size:13px;line-height:1.35;word-break:break-word}.upload-empty{padding:18px;color:#786b59;font-size:13px}@media(max-width:560px){.upload-card{padding:24px 17px 20px}.upload-products{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.upload-product{padding:7px}.upload-product img{height:95px}.upload-product strong{font-size:11px}}'
    duplicate_css = '.duplicate-clean-btn{border-color:#b74337;background:#fae3d9;color:#822c24}.duplicate-clean-btn:hover{background:#f8c9bb;border-color:#822c24}'
    no_photo_css = '.no-photo-modal{position:fixed;inset:0;z-index:40;display:none;align-items:center;justify-content:center;padding:18px;background:#171717aa;backdrop-filter:blur(5px)}.no-photo-modal.show{display:flex}.no-photo-card{width:min(440px,92vw);padding:30px 32px;border:2px solid var(--hair);background:var(--paper-light);box-shadow:12px 12px 0 var(--orange);text-align:center}.no-photo-icon{font-size:48px}.no-photo-card h2{margin:8px 0;color:var(--ink);font-size:24px}.no-photo-card p{margin:0 0 20px;color:var(--ink-soft);font-size:14px;line-height:1.7}.no-photo-close{border:1px solid var(--ink);padding:10px 28px;background:var(--ink);color:#fff;font-weight:800;cursor:pointer}'
    carousell_css = ':root{--paper:#ffffff;--paper-light:#ffffff;--ink:#111111;--ink-soft:#555555;--orange:#e3342f;--orange-deep:#d92727;--hair:#111111}html{background:#f5f5f5}body{background:#f5f5f5;color:#111}.card{background:#fff}.card:before{background:#e3342f}.editorial-bar{background:#fff;border-bottom-color:#e5e5e5}.brand-name,.editorial-nav,.live-mark{color:#555}.live-mark{border-left-color:#d9d9d9}.head{border-bottom-color:#111}.item{background:#fff;border-color:#d9d9d9;border-left-color:#e3342f;box-shadow:5px 5px 0 #eeeeee}.item small{color:#d92727}.message{border-left-color:#e3342f;background:#fafafa;color:#333}.message:before{color:#e3342f}.bar{background:#e5e5e5}.fill{background:#e3342f}.row{color:#666}.row #phase{color:#111}.steps{border-top-color:#111;border-bottom-color:#d9d9d9}.step{border-right-color:#d9d9d9;color:#777}.step.active,.step.done{background:#fff1f1;color:#111;border-color:#e3342f}.dot{background:#eeeeee}.step.active .dot{background:#e3342f}.step.done .dot{background:#ffd6d6}.actions .btn{border-color:#111;background:#111;color:#fff}.actions .btn:first-child,.btn:not(.secondary):not(.light):not(.stop){background:#e3342f;border-color:#e3342f}.btn:hover:not(:disabled){background:#111;color:#fff}.btn.secondary{background:#fff;color:#111}.btn.secondary:hover:not(:disabled){background:#111;color:#fff}.btn.light{background:#f1f1f1;color:#111;border-color:#cfcfcf}.btn.stop{background:#b91c1c;border-color:#b91c1c}.side{border-left-color:#d9d9d9}.side h2{color:#111;border-bottom-color:#111}.list{background:#fff;border-color:#e1e1e1}.list h3{color:#333}.list li{color:#444;border-bottom-color:#ededed}.list.completed h3{color:#188038}.dropzone{border-color:#e3342f;background:#fff7f7}.dropzone:hover,.dropzone.dragover{border-color:#b91c1c;background:#ffecec}.dropzone strong{color:#d92727}.upload-guide{color:#666}.download-note{background:#f5f5f5;color:#555}.environment-result{border-color:#d9d9d9}.bug-feedback,.utility-card{border-color:#d9d9d9;background:#fff;box-shadow:5px 5px 0 #eeeeee}.bug-feedback-icon{background:#ffe2e2}.bug-feedback-link{border-color:#e3342f;color:#d92727}.bug-feedback-link:hover{background:#e3342f;color:#fff}.completion-card,.upload-card,.no-photo-card{border-color:#111;background:#fff;box-shadow:12px 12px 0 #e3342f}.completion-close,.no-photo-close{background:#111}.upload-product{border-color:#d9d9d9;background:#fafafa}.tutorial-card{border-color:#111;background:#fff;box-shadow:9px 9px 0 #e3342f}.tutorial-kicker{color:#d92727}.tutorial-next{background:#e3342f}.tutorial-next:hover{background:#111;color:#fff}.duplicate-clean-btn{border-color:#d92727;background:#ffe2e2;color:#b91c1c}.duplicate-clean-btn:hover{background:#e3342f;color:#fff}'
    refined_carousell_css = ':root{--carousell-red:#f04444;--carousell-dark:#202124;--carousell-line:#e8e8e8}body{padding:16px;background:#f6f6f6;color:var(--carousell-dark)}.card{width:min(1280px,calc(100vw - 32px));min-height:calc(100vh - 32px);padding:0 32px 34px;border-radius:16px;background:#fff;box-shadow:0 8px 28px rgba(0,0,0,.08)}.card:before{width:6px;height:72px;background:var(--carousell-red)}.editorial-bar{min-height:72px;margin:0 -32px;padding:0 30px;border-bottom:1px solid var(--carousell-line);border-radius:16px 16px 0 0}.brand-mark{font-size:30px;letter-spacing:-2px;color:var(--carousell-red)}.brand-name{font-size:10px;letter-spacing:1.3px;color:#666}.editorial-nav{gap:20px;color:#555}.live-mark{color:#666}.layout{grid-template-columns:minmax(0,1.45fr) minmax(300px,.8fr);gap:30px;padding-top:30px}.head{align-items:center;min-height:172px;margin-bottom:22px;padding:0 0 22px;border-bottom:1px solid var(--carousell-line)}.head>div:last-child{max-width:none}.bear{position:relative;right:auto;bottom:auto;order:0;width:92px;height:92px;margin:0 22px 0 4px;padding:0;background:#fff1f1;border-radius:18px;display:grid;place-items:center}.bear img{max-width:82px;max-height:82px;filter:none}.eyebrow{color:var(--carousell-red);font-size:11px;letter-spacing:1.3px}.title{margin-top:7px;color:var(--carousell-dark);font-size:42px;line-height:1.08;letter-spacing:-.5px}.item{margin-bottom:15px;padding:15px 16px;border:1px solid var(--carousell-line);border-left:4px solid var(--carousell-red);border-bottom:1px solid var(--carousell-line);border-radius:10px;box-shadow:none}.item strong{font-size:20px;color:#202124}.message{margin:12px 0;padding:10px 12px;border:1px solid var(--carousell-line);border-left:4px solid var(--carousell-red);border-radius:8px;background:#fafafa;color:#444}.bar{height:8px;border-radius:8px;background:#ededed}.fill{border-radius:8px;background:var(--carousell-red)}.row{margin:9px 0 20px;color:#777}.steps{border:1px solid var(--carousell-line);border-radius:10px;overflow:hidden}.step{padding:12px 12px 11px;border-right:1px solid var(--carousell-line);font-size:11px;text-transform:none}.dot{width:30px;height:30px;margin-bottom:8px;border-radius:8px}.step.active,.step.done{background:#fff7f7;border-color:#ffd1d1}.step.active .dot{background:var(--carousell-red)}.actions{gap:8px;margin-top:20px}.actions .btn,.btn{padding:10px 13px;border-radius:8px;font-size:12px}.actions .btn:first-child,.btn:not(.secondary):not(.light):not(.stop){background:var(--carousell-red);border-color:var(--carousell-red)}.btn:hover:not(:disabled){transform:translateY(-1px);background:#d93636}.btn.secondary{border-color:#d8d8d8}.btn.light{background:#f5f5f5;border-color:#dedede}.btn.stop{background:#b4232b;border-color:#b4232b}.side{padding-left:24px;border-left:1px solid var(--carousell-line)}.side h2{margin-bottom:15px;padding-bottom:11px;border-bottom:1px solid #222;font-family:inherit;font-size:17px}.list{padding:14px;margin:0 0 12px;border:1px solid var(--carousell-line);border-radius:10px;background:#fff;box-shadow:none}.list h3{margin-bottom:8px;font-size:12px;color:#333}.list li{padding:7px 0;border-bottom:1px solid #f0f0f0;color:#444}.dropzone{height:112px;margin-top:10px;border:2px dashed #f08080;border-radius:10px;background:#fff8f8}.dropzone:hover,.dropzone.dragover{border-color:var(--carousell-red);background:#fff0f0}.dropzone strong{color:#c92e35}.utility-dock{margin-top:44px;padding-top:22px;gap:20px;border-top:1px solid var(--carousell-line)}.utility-card{padding:16px 18px;border:1px solid var(--carousell-line);border-radius:10px;background:#fff;box-shadow:none}.completion-card,.upload-card,.no-photo-card{border:1px solid #222;border-radius:14px;box-shadow:0 18px 60px rgba(0,0,0,.2)}.completion-close,.no-photo-close{border-radius:8px;background:var(--carousell-red)}.tutorial-card{border:1px solid #222;border-radius:12px;box-shadow:0 18px 50px rgba(0,0,0,.2)}@media(max-width:800px){body{padding:0}.card{width:100%;min-height:100vh;border-radius:0;padding:0 18px 28px}.editorial-bar{margin:0 -18px;padding:0 18px;border-radius:0}.layout{padding-top:22px}.head{min-height:145px}.title{font-size:32px}.bear{width:70px;height:70px;margin-right:14px}.bear img{max-width:62px;max-height:62px}.side{padding:0;border-left:0}.utility-dock{margin-top:34px}}'
    contrast_css = '.row #phase{display:inline-block!important;min-width:100px;padding:8px 12px!important;border-radius:7px!important;background:#202124!important;color:#fff!important;text-transform:none!important}.row #eta{display:inline-block!important;padding:8px 12px!important;border-radius:7px!important;background:#fff1f1!important;color:#b4232b!important}.row #percent{padding:8px 0!important;background:transparent!important;color:#333!important}.notice{padding:9px 12px!important;border-left:4px solid var(--carousell-red)!important;background:#fff!important;color:#444!important;border-radius:0 7px 7px 0!important}.message.warning{background:#fff1f1!important;color:#a51d2a!important}.issue{background:#fff1f1!important;color:#8f1d2c!important}.environment-missing-note{background:#fff1f1!important;color:#a51d2a!important}.upload-zone-panel>.dropzone{width:calc(100% - 8px)!important;height:calc(100% - 8px)!important;margin:4px auto!important}'
    test_tools_css = '.test-tools{flex-basis:100%;margin-top:9px;padding:12px 13px;border:1px dashed #c94b45;background:#fff8f6}.test-tools-title{font-size:11px;font-weight:900;letter-spacing:1px;color:#a51d2a}.test-tools-note{margin-top:3px;font-size:11px;color:#6b6259}.test-tools-buttons{display:flex;flex-wrap:wrap;gap:7px;margin-top:9px}.test-tools-buttons .account-action{background:#fff1f1!important;border-color:#c94b45!important;color:#8f1d2c!important}.test-tools-buttons .account-action:hover:not(:disabled){background:#e3342f!important;color:#fff!important}@media(max-width:560px){.test-tools-buttons .account-action{flex:1 1 100%}}'
    processing_tint_css = '.side{background:linear-gradient(to bottom,#fff 0%,#fff 93%,#fff7f7 100%)!important}.list.processing{background:#fff7f7!important;box-shadow:4px 4px 0 #f2d0d0!important}'
    sidebar_order_css = '.lists{display:flex;flex-direction:column}.lists>.list:not(.completed):not(.processing){order:1}.lists>.list.processing{order:2}.lists>.list.completed{order:3}.upload-zone-panel{order:0;display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1/1;margin:0 0 18px;padding:0;border:1px solid #b8a58a;background:#fbf5e9;box-shadow:4px 4px 0 #e4d4ba}.upload-zone-panel .dropzone{margin:0;width:100%;height:100%;aspect-ratio:1/1}'
    tutorial_css = '.tutorial-launch{margin-left:auto;border:1px solid #171717;border-radius:0;padding:8px 12px;background:#f2b45b;color:#171717;font-family:inherit;font-size:12px;font-weight:900;cursor:pointer}.tutorial-launch:hover{background:#171717;color:#fff}.tutorial-layer{position:fixed;inset:0;z-index:100;display:none;pointer-events:none}.tutorial-layer.show{display:block}.tutorial-mask{position:fixed;background:rgba(18,18,18,.72);pointer-events:auto}.tutorial-mask-top{left:0;right:0;top:0}.tutorial-mask-left{left:0}.tutorial-mask-right{right:0}.tutorial-mask-bottom{left:0;right:0;bottom:0}.tutorial-card{position:fixed;z-index:101;left:50%;bottom:24px;width:min(440px,calc(100vw - 28px));padding:20px 22px;border:2px solid #171717;background:#fbf5e9;box-shadow:9px 9px 0 #f2b45b;transform:translateX(-50%);pointer-events:auto}.tutorial-kicker{font-size:11px;font-weight:900;letter-spacing:1.5px;color:#8d5c1d;text-transform:uppercase}.tutorial-card h2{margin:6px 0 8px;color:#171717;font-size:22px}.tutorial-card p{margin:0;color:#4c4030;font-size:13px;line-height:1.6}.tutorial-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:18px}.tutorial-footer span{color:#786b59;font-size:11px}.tutorial-prev,.tutorial-next{border:1px solid #171717;border-radius:0;padding:8px 12px;font-family:inherit;font-size:12px;font-weight:800;cursor:pointer}.tutorial-prev{margin-right:6px;background:transparent;color:#171717}.tutorial-next{background:#171717;color:#fff}.tutorial-prev:hover{background:#e4d4ba}.tutorial-next:hover{background:#f2b45b;color:#171717}@media(max-width:560px){.tutorial-launch{padding:7px 8px;font-size:10px}.tutorial-card{bottom:14px;padding:16px}.tutorial-card h2{font-size:19px}}'
    tutorial_position_css = '.tutorial-card{left:32px;transform:none}@media(max-width:560px){.tutorial-card{left:14px;transform:none;width:calc(100vw - 28px)}}'
    i18n_css = '.language-toggle{margin-left:10px;border:1px solid #d8d8d8;border-radius:999px;padding:6px 10px;background:#fff;color:#333;font-family:inherit;font-size:11px;font-weight:800;cursor:pointer}.language-toggle:hover{border-color:#f04444;color:#d92727}.language-toggle:focus-visible{outline:2px solid #f04444;outline-offset:2px}'
    html = html.replace('</style></head>', utility_css + upload_css + duplicate_css + no_photo_css + sidebar_order_css + tutorial_css + tutorial_position_css + carousell_css + refined_carousell_css + contrast_css + test_tools_css + processing_tint_css + i18n_css + '</style></head>', 1)
    tutorial_js = "<script>const tutorialSteps=[{selector:'[data-action=\"setup\"]',title:'先下載並安裝環境',text:'第一次使用先按這裡一鍵下載並安裝需要的 Python 套件與瀏覽器元件，完成後再進行其他操作。'},{selector:'[data-action=\"check\"]',title:'確認環境完整',text:'安裝完成後按這裡檢查 Python、Pillow、Playwright、Chromium 和 Chrome 是否都可以使用。'},{selector:'#dropzone',title:'加入商品圖片',text:'把商品圖片拖到這個方形區域，程序會自動分組，不需要先手動建立資料夾。'},{selector:'.duplicate-clean-btn',title:'先檢查賬戶重複',text:'按這裡檢查 Carousell 的「我的刊登商品」，整組任意一張照片已刊登，就略過整組並移到已完成檔案。'},{selector:'[data-action=\"open_chrome\"]',title:'打開新的 Chrome',text:'先開啟專用 Chrome 視窗並登入 Carousell。'},{selector:'[data-action=\"attach_publish\"]',title:'開始接管發布',text:'登入完成後按這裡，程序會逐件處理未處理商品。'},{selector:'.steps',title:'查看目前進度',text:'這裡會顯示整理圖片、檢查重複、自動填寫和發布商品的進度。'},{selector:'#completed',title:'查看已處理商品',text:'成功發布或判定重複的商品會移到已處理清單。'}];let tutorialIndex=0;function closeTutorial(){document.querySelector('#tutorialLayer').classList.remove('show');try{localStorage.setItem('carousell_tutorial_seen','1')}catch(e){}}function renderTutorial(){const step=tutorialSteps[tutorialIndex],target=document.querySelector(step.selector),layer=document.querySelector('#tutorialLayer');if(!target){if(tutorialIndex<tutorialSteps.length-1){tutorialIndex+=1;renderTutorial();}return}layer.classList.add('show');target.scrollIntoView({behavior:'smooth',block:'center',inline:'nearest'});setTimeout(()=>{const r=target.getBoundingClientRect(),pad=8,top=Math.max(0,r.top-pad),bottom=Math.min(innerHeight,r.bottom+pad),left=Math.max(0,r.left-pad),right=Math.min(innerWidth,r.right+pad),height=Math.max(0,bottom-top);Object.assign(document.querySelector('#tutorialMaskTop').style,{left:'0',top:'0',width:'100%',height:top+'px'});Object.assign(document.querySelector('#tutorialMaskLeft').style,{left:'0',top:top+'px',width:left+'px',height:height+'px'});Object.assign(document.querySelector('#tutorialMaskRight').style,{left:right+'px',top:top+'px',width:Math.max(0,innerWidth-right)+'px',height:height+'px'});Object.assign(document.querySelector('#tutorialMaskBottom').style,{left:'0',top:bottom+'px',width:'100%',height:Math.max(0,innerHeight-bottom)+'px'});document.querySelector('#tutorialTitle').textContent=step.title;document.querySelector('#tutorialText').textContent=step.text;document.querySelector('#tutorialCount').textContent=(tutorialIndex+1)+' / '+tutorialSteps.length;document.querySelector('#tutorialPrev').disabled=tutorialIndex===0;document.querySelector('#tutorialNext').textContent=tutorialIndex===tutorialSteps.length-1?'完成':'下一步'},220)}function startTutorial(){tutorialIndex=0;renderTutorial()}document.querySelector('#tutorialStart').addEventListener('click',startTutorial);document.querySelector('#tutorialPrev').addEventListener('click',()=>{if(tutorialIndex>0){tutorialIndex-=1;renderTutorial()}});document.querySelector('#tutorialNext').addEventListener('click',()=>{if(tutorialIndex<tutorialSteps.length-1){tutorialIndex+=1;renderTutorial()}else{closeTutorial()}});try{if(localStorage.getItem('carousell_tutorial_seen')!=='1')setTimeout(startTutorial,700)}catch(e){}</script>"
    html = html.replace('<script>\nconst labels=', tutorial_js + '<script>\nconst labels=', 1)
    frontend_grouping_js = '<script src="/assets/ui/i18n.js?v=74" data-aetheris-i18n="74" defer></script><link rel="stylesheet" href="/assets/grouping/editor.css?v=72"><script src="/assets/grouping/editor.js?v=72"></script><script src="/assets/grouping/ui.js?v=72"></script>'
    upload_js = "<script>function showUploadAdded(folders){const names=[...new Set((folders||[]).filter(Boolean))];if(!names.length)return;const modal=document.querySelector('#uploadModal'),grid=document.querySelector('#uploadProducts'),summary=document.querySelector('#uploadSummary');grid.innerHTML='';summary.dataset.count=String(names.length);summary.textContent=pageLang==='en'?'Added '+names.length+' products. Here is one original image for each product':'已新增 '+names.length+' 件商品，以下是每件商品的一張原始圖片';names.forEach(name=>{const card=document.createElement('div');card.className='upload-product';const img=document.createElement('img');img.loading='lazy';img.alt='';img.src='/thumbnail?bucket=unprocessed&name='+encodeURIComponent(name);img.onerror=()=>{img.style.display='none'};const label=document.createElement('strong');label.textContent=name;card.append(img,label);grid.appendChild(card)});modal.classList.add('show')}function closeUpload(){document.querySelector('#uploadModal').classList.remove('show')}document.querySelector('#closeUpload').addEventListener('click',closeUpload);document.querySelector('#closeUploadBottom').addEventListener('click',closeUpload);</script>"
    i18n_js = r"""<script>
const langMap={"工作台":"Workspace","商品流程":"Listings","環境工具":"Tools","✨ 新手教學":"✨ Tutorial","CAROUSELL 自動上架":"CAROUSELL AUTOMATION","小助手正在幫你處理":"Assistant is processing","Carousell 小助手":"Carousell Assistant","檔案進度":"File progress","📁 檔案進度":"📁 File progress","✅ 已處理":"✅ Completed","⏳ 正在處理":"⏳ Processing","📦 未處理":"📦 Pending","📂 開啟資料夾":"📂 Open folder","自動分組商品":"Auto-group photos","一次拖入大量圖片":"Drop multiple photos","➕ 可一次拖入大量圖片，程序會在本機比較商品主體及不同角度，自動建立商品群組。":"➕ Drop many photos. The local model compares product details and camera angles to create groups.","🧰 手動下載環境":"🧰 Manual environment","🩺 檢查環境":"🩺 Check environment","🧰 一鍵安裝環境":"🧰 Install environment","🌟 打開新 Chrome":"🌟 Open Chrome","🚀 接管 Chrome 發布":"🚀 Take over Chrome & publish","🧹 整理圖片":"🧹 Prepare images","🧹 檢查賬戶重複":"🧹 Check account duplicates","⏹ 停止":"⏹ Stop","🧽 清理背景程序":"🧽 Clean background processes","整理圖片":"Prepare images","檢查重複":"Duplicate check","自動填寫":"Autofill","發布商品":"Publish","問題紀錄（程序會繼續）":"Issues (process continues)","💡 解決方法":"💡 How to fix","遇到問題？回報 Bug":"Report a bug","需要版本：Python 3.13+、Pillow 10.0+、Playwright 1.45+":"Required: Python 3.13+, Pillow 10.0+, Playwright 1.45+","Python 3.13（官方下載）":"Python 3.13 (official download)","Google Chrome 最新穩定版":"Google Chrome latest stable","Pillow 10.0（Python 套件）":"Pillow 10.0 (Python package)","Playwright 1.45（Python 套件）":"Playwright 1.45 (Python package)","Chromium 元件安裝說明":"Chromium installation guide","按「檢查環境」查看目前電腦是否缺少必要元件。":"Click Check environment to see whether required components are missing.","🔎 開啟 Google 圖片參考":"🔎 Open Google image reference","解決方法":"How to fix","知道了":"Got it","上一步":"Back","下一步":"Next","完成":"Done","這次作業完成了！":"This run is complete!","以下是本次處理結果":"This run summary","已完成":"Completed","本次已完成":"Completed","跳過重複":"Duplicates skipped","手動跳過":"Skipped manually","需要留意":"Needs attention","已新增商品":"Products added","以下商品已放入未處理":"These products were added to Pending","目前沒有檔案":"No files","目前沒有商品，請先放入照片":"No products. Add photos first.","請把照片放在「自動分組商品」":"Put photos in Auto-group photos","手動填寫":"Manual entry","刪除":"Delete","LOCAL LIVE":"LOCAL LIVE"};
const brandLangMap={"Aetheris 正在幫你處理":"Aetheris is processing","Aetheris":"Aetheris"};
const reverseLangMap=Object.fromEntries(Object.entries(langMap).map(([a,b])=>[b,a]));let pageLang=localStorage.getItem('carousell_lang')||'zh';
let translating=false;function translatePage(){if(translating)return;translating=true;try{const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode()){if(node.parentElement?.closest('script,style'))continue;const raw=node.nodeValue,key=raw.trim();if(!key)continue;const translated=pageLang==='en'?(langMap[key]||key):(reverseLangMap[key]||key);if(translated!==key)node.nodeValue=raw.replace(key,translated)}const toggle=document.querySelector('#languageToggle'),toggleText=pageLang==='en'?'中文':'EN';if(toggle&&toggle.textContent!==toggleText)toggle.textContent=toggleText;const wantedLang=pageLang==='en'?'en':'zh-Hant';if(document.documentElement.lang!==wantedLang)document.documentElement.lang=wantedLang;const count=document.querySelector('#count');if(count){let next=count.textContent;if(pageLang==='en')next=next.replace(/^第\s*(\d+)\s*\/\s*(\d+)\s*件商品$/,'Item $1 of $2');else if(/^Item\s+\d+\s+of\s+\d+$/.test(next)){const m=next.match(/Item\s+(\d+)\s+of\s+(\d+)/);next=`第 ${m[1]} / ${m[2]} 件商品`;}if(next!==count.textContent)count.textContent=next}}finally{translating=false}}
function setLanguage(next){pageLang=next;localStorage.setItem('carousell_lang',pageLang);translatePage()}document.addEventListener('DOMContentLoaded',()=>{document.querySelector('#languageToggle')?.addEventListener('click',()=>setLanguage(pageLang==='en'?'zh':'en'));translatePage()});new MutationObserver(()=>{if(pageLang==='en')translatePage()}).observe(document.body,{subtree:true,childList:true,characterData:true});
</script>"""
    runtime_i18n_js = r"""<script>
Object.assign(langMap,brandLangMap,{"刪除全部已刊登":"Delete all listings","開啟未開啟的購買按鈕":"Enable closed Buy buttons","關閉所有已開啟的購買按鈕":"Disable open Buy buttons","帳戶商品操作":"Account listing action"});Object.assign(reverseLangMap,Object.fromEntries(Object.entries(brandLangMap).map(([a,b])=>[b,a])));Object.assign(reverseLangMap,{"Delete all listings":"刪除全部已刊登","Enable closed Buy buttons":"開啟未開啟的購買按鈕","Disable open Buy buttons":"關閉所有已開啟的購買按鈕","Account listing action":"帳戶商品操作"});
const runtimeZhEn={
  '測試功能':'Test functions',
  '以下操作會逐件處理 Carousell 帳戶商品，請先確認登入的是正確帳戶。':'These actions process Carousell account listings one by one. Make sure the correct account is signed in first.',
  '手動填寫':'Manual entry',
  '環境檢查完成，全部可用':'Environment check complete. Everything is available.',
  '環境檢查完成，全部必要元件可用。':'Environment check complete. All required components are available.',
  '按「檢查環境」查看目前電腦是否缺少必要元件。':'Click "Check environment" to see whether required components are missing.',
  '請先按「一鍵安裝環境」，或使用上方手動下載網址補齊缺失項目。':'Click "Install environment" first, or use the manual download links above to install the missing items.',
  '設定檔 config.json':'config.json',
  '設定檔已讀取':'Configuration loaded',
  '設定檔是空的或無法使用':'The configuration file is empty or unavailable',
  '需要可讀取的 config.json':'A readable config.json is required',
  '需要 Python 3.13 或以上':'Python 3.13 or later is required',
  '需要 Pillow 10.0 或以上':'Pillow 10.0 or later is required',
  '需要 Playwright 1.45+ 與 Chromium':'Playwright 1.45+ and Chromium are required',
  '需要電腦已安裝普通 Google Chrome':'A regular Google Chrome installation is required',
  '找不到 chrome.exe':'chrome.exe was not found',
  '新手教學':'Tutorial',
  '完成':'Done',
  '下一步':'Next',
  '上一步':'Back',
  '先下載並安裝環境':'Install the environment first',
  '第一次使用先按這裡一鍵下載並安裝需要的 Python 套件與瀏覽器元件，完成後再進行其他操作。':'On your first use, click here to install the required Python packages and browser components, then continue with the other actions.',
  '確認環境完整':'Check your environment',
  '安裝完成後按這裡檢查 Python、Pillow、Playwright、Chromium 和 Chrome 是否都可以使用。':'After installation, click here to check that Python, Pillow, Playwright, Chromium, and Chrome are available.',
  '加入商品圖片':'Add product photos',
  '把商品圖片拖到這個方形區域，程序會自動分組，不需要先手動建立資料夾。':'Drop product photos into this square area. The tool groups them automatically, so you do not need to create folders first.',
  '先檢查賬戶重複':'Check for duplicates first',
  '按這裡檢查 Carousell 的「我的刊登商品」，整組任意一張照片已刊登，就略過整組並移到已完成檔案。':'Check every photo against My Listings. One matching photo skips the whole group and moves it to Completed files.',
  '打開新的 Chrome':'Open a new Chrome',
  '先開啟專用 Chrome 視窗並登入 Carousell。':'Open the dedicated Chrome window and sign in to Carousell first.',
  '開始接管發布':'Start taking over and publishing',
  '登入完成後按這裡，程序會逐件處理未處理商品。':'After signing in, click here to process the pending products one by one.',
  '查看目前進度':'View progress',
  '這裡會顯示整理圖片、檢查重複、自動填寫和發布商品的進度。':'This area shows progress for preparing images, checking duplicates, autofill, and publishing.',
  '查看已處理商品':'View completed products',
  '成功發布或判定重複的商品會移到已處理清單。':'Successfully published or duplicate products are moved to the Completed list.',
  '已開始處理。':'Processing started.',
  '正在準備圖片...':'Preparing images...',
  '正在啟動操作...':'Starting operation...',
  '無法連接本機控制服務。':'Unable to connect to the local control service.',
  '正在重新連線到本機狀態...':'Reconnecting to the local status service...',
  '已打開新的可接管 Chrome，尚未開始發布。':'New controllable Chrome opened. Publishing has not started.',
  '已從狀態頁啟動操作，正在準備...':'Operation started from the dashboard. Preparing...',
  '正在上傳和整理商品圖片...':'Uploading and organizing product images...',
  '圖片已放入待發布。':'Images added to Pending.',
  '圖片放入失敗，請重新嘗試。':'Could not add the images. Please try again.',
  '表單已完成，正在按下「立即刊登」...':'The form is complete. Clicking "Publish now"...',
  '正在確認購買設定，準備發布...':'Checking purchase settings and preparing to publish...',
  '正在開啟購買按鈕':'Opening Buy buttons',
  '正在關閉購買按鈕':'Disabling Buy buttons',
  '發現同款商品，已跳過並整理檔案。':'Duplicate found. Skipped and organized the files.',
  '發布前發現同款商品，已跳過並整理檔案。':'Duplicate found before publishing. Skipped and organized the files.',
  '已跳過目前商品，正在處理下一件。':'Skipped this product. Processing the next one.',
  '已確認成功刊登，準備在同一分頁處理下一件。':'Listing confirmed successfully. Preparing the next product in the same tab.',
  '商品已刊登並移到已完成檔案。':'Product listed and moved to Completed.',
  '目前商品處理完成。':'The current product is complete.',
  '正在等候表單完成後發布…':'Waiting for the form to finish before publishing...',
  '已按下「立即刊登」，等待完成頁面…':'Clicked "Publish now"; waiting for the completion page...',
  '正在放入':'Adding',
  '張圖片...':' images...',
  '最後更新：':'Last updated: ',
  '全部流程預計：':'Estimated total: ',
  '本次總耗時：':'Total time: ',
  '本次已完成':'Completed',
  '計算中':'Calculating',
  '全部商品':'All products',
  '預覽已開啟（未發布）':'Preview opened (not published)',
  '預覽頁已開啟，未發布；可直接在 Chrome 檢查。':'Preview opened; not published. You can check it directly in Chrome.',
  '已將「':'Moved "',
  '」移到已刪除檔案。':'" to Deleted files.',
  '已處理':'Completed',
  '刪除全部已刊登':'Delete all listings',
  '開啟未開啟的購買按鈕':'Enable closed Buy buttons',
  '關閉所有已開啟的購買按鈕':'Disable open Buy buttons',
  '帳戶商品操作':'Account listing action'
};
const runtimeEnZh=Object.fromEntries(Object.entries(runtimeZhEn).map(([a,b])=>[b,a]));
// Keep the original status string so switching language never translates
// a user-supplied product name or alternates between two rendered values.
const duplicateRuntimeOriginal=new Map();
function duplicateRuntimeText(text){
  if(pageLang!=='en')return duplicateRuntimeOriginal.get(text)||text;
  let out=text;
  const exact={
    '正在讀取帳戶全部刊登及商品相簿，不只檢查封面…':'Reading all account listings and product galleries, including non-cover photos...',
    '檢查賬戶刊登商品':'Checking account listings',
    '帳戶圖片重複檢查未完成；已略過確認重複的整組，其餘保留，這次未開始發布。':'Account photo check incomplete. Confirmed duplicate groups were skipped; remaining groups are kept. Publishing has not started.'
  };
  if(exact[text])out=exact[text];
  let m=text.match(/^正在載入帳戶全部刊登，已找到 (\d+) 件…$/);if(m)out=`Loading all account listings; ${m[1]} found...`;
  m=text.match(/^正在檢查帳戶商品相簿 (\d+)\/(\d+)，已讀取 (\d+) 張照片…$/);if(m)out=`Checking account gallery ${m[1]}/${m[2]}; ${m[3]} photos read...`;
  m=text.match(/^逐張比對原圖 (\d+)\/(\d+) 組；帳戶 (\d+) 件／(\d+) 張照片…$/);if(m)out=`Comparing every original photo: group ${m[1]}/${m[2]}; account: ${m[3]} listings / ${m[4]} photos...`;
  m=text.match(/^已檢查 帳戶 (\d+) 件商品／(\d+) 張照片，未處理 (\d+) 組；全部原始照片沒有找到帳戶已刊登的相同圖片。$/);if(m)out=`Checked ${m[1]} account listings / ${m[2]} photos against ${m[3]} pending groups. No matching original photos found.`;
  m=text.match(/^已檢查 帳戶 (\d+) 件商品／(\d+) 張照片，未處理 (\d+) 組；任意一張相同就略過整組，已移到已完成檔案 (\d+) 組：(.+)$/);if(m)out=`Checked ${m[1]} account listings / ${m[2]} photos against ${m[3]} pending groups. One matching photo skips the whole group. Moved ${m[4]} groups to Completed: ${m[5]}`;
  m=text.match(/^檢查未完成（帳戶 (\d+) 件商品／(\d+) 張照片，未處理 (\d+) 組）。已確認重複 (\d+) 組；其餘保留且不會發布。(.*)$/);if(m)out=`Check incomplete (${m[1]} account listings / ${m[2]} photos; ${m[3]} groups fully checked). ${m[4]} confirmed duplicate groups skipped; remaining groups are kept and will not be published. ${m[5]}`;
  if(out!==text)duplicateRuntimeOriginal.set(out,text);
  return out;
}
function runtimeText(value){
  let text=String(value||'');
  if(!text)return text;
  const duplicateText=duplicateRuntimeText(text);if(duplicateText!==text)return duplicateText;
   if(pageLang==='en'){
     let moved=text.match(/^已將「(.+)」移到已刪除檔案。$/);if(moved)return `Moved "${moved[1]}" to Deleted files.`;
     let deleted=text.match(/^已處理\s*(\d+)\s*件已刊登商品，成功刪除\s*(\d+)\s*件。$/);if(deleted)return `Processed ${deleted[1]} listings; deleted ${deleted[2]}.`;
     let toggled=text.match(/^已處理\s*(\d+)\s*件商品，成功(開啟|關閉)購買按鈕\s*(\d+)\s*件。$/);if(toggled)return `Processed ${toggled[1]} products; successfully ${toggled[2]==='開啟'?'enabled':'disabled'} Buy on ${toggled[3]}.`;
     let progress=text.match(/^正在(開啟|關閉)購買按鈕（(\d+)\/(\d+)）\.\.\.$/);if(progress)return `${progress[1]==='開啟'?'Opening':'Disabling'} Buy buttons (${progress[2]}/${progress[3]})...`;
    if(/^第\s*(\d+)\s*\/\s*(\d+)\s*件商品$/.test(text)){const m=text.match(/^第\s*(\d+)\s*\/\s*(\d+)\s*件商品$/);return `Item ${m[1]} of ${m[2]}`;}
    let m=text.match(/^已按下「立即刊登」，等待完成頁面…\s*(\d+)\/(\d+)\s*秒$/);if(m)return `Clicked "Publish now"; waiting for the completion page... ${m[1]}/${m[2]} sec`;
    m=text.match(/^正在等候表單完成後發布…\s*(\d+)\/(\d+)\s*秒$/);if(m)return `Waiting for the form to finish before publishing... ${m[1]}/${m[2]} sec`;
    m=text.match(/^正在放入\s*(\d+)\s*張圖片…?$/);if(m)return `Adding ${m[1]} images...`;
    m=text.match(/^已新增\s*(\d+)\s*件商品，以下是每件商品的一張原始圖片$/);if(m)return `Added ${m[1]} products. Here is one original image for each product`;
    m=text.match(/^全部流程預計：(?:(\d+)小時\s*)?(?:(\d+)分鐘\s*)?(\d+)秒$/);if(m)return `Estimated total: ${m[1]?m[1]+'h ':''}${m[2]?m[2]+'m ':''}${m[3]}s`;
    m=text.match(/^本次總耗時：(?:(\d+)小時\s*)?(?:(\d+)分鐘\s*)?(\d+)秒$/);if(m)return `Total time: ${m[1]?m[1]+'h ':''}${m[2]?m[2]+'m ':''}${m[3]}s`;
    m=text.match(/^發現\s*(\d+)\s*項缺失或版本不符$/);if(m)return `${m[1]} missing or incompatible items found`;
    m=text.match(/^環境檢查完成：有\s*(\d+)\s*項缺失或版本不符。$/);if(m)return `Environment check complete: ${m[1]} missing or incompatible items found.`;
    m=text.match(/^目前版本：Python\s+(.+)$/);if(m)return `Current version: Python ${m[1]}`;
    m=text.match(/^目前版本：Pillow\s+(.+)$/);if(m)return `Current version: Pillow ${m[1]}`;
    m=text.match(/^Playwright\s+(.+)，Chromium 已安裝$/);if(m)return `Playwright ${m[1]}, Chromium installed`;
    m=text.match(/^Playwright\s+(.+)版本過舊$/);if(m)return `Playwright ${m[1]} is outdated`;
    m=text.match(/^Playwright\s+(.+)，找不到 Chromium 元件$/);if(m)return `Playwright ${m[1]}, Chromium component not found`;
    m=text.match(/^已找到：(.+)$/);if(m)return `Found: ${m[1]}`;
    m=text.match(/^讀取失敗：(.+)$/);if(m)return `Read failed: ${m[1]}`;
    m=text.match(/^未安裝（(.+)）$/);if(m)return `Not installed (${m[1]})`;
    m=text.match(/^未完整安裝：(.+)$/);if(m)return `Incomplete installation: ${m[1]}`;
    if(runtimeZhEn[text])return runtimeZhEn[text];
    return text.replace(/^最後更新：/,'Last updated: ').replace(/^全部流程預計：/,'Estimated total: ').replace(/^本次總耗時：/,'Total time: ');
  }
   let movedBack=text.match(/^Moved "(.+)" to Deleted files\.$/);if(movedBack)return `已將「${movedBack[1]}」移到已刪除檔案。`;
   let deletedBack=text.match(/^Processed\s*(\d+)\s*listings; deleted\s*(\d+)\.$/);if(deletedBack)return `已處理 ${deletedBack[1]} 件已刊登商品，成功刪除 ${deletedBack[2]} 件。`;
   let toggledBack=text.match(/^Processed\s*(\d+)\s*products; successfully (enabled|disabled) Buy on\s*(\d+)\.$/);if(toggledBack)return `已處理 ${toggledBack[1]} 件商品，成功${toggledBack[2]==='enabled'?'開啟':'關閉'}購買按鈕 ${toggledBack[3]} 件。`;
   let progressBack=text.match(/^(Opening|Disabling) Buy buttons \((\d+)\/(\d+)\)\.\.\.$/);if(progressBack)return `正在${progressBack[1]==='Opening'?'開啟':'關閉'}購買按鈕（${progressBack[2]}/${progressBack[3]}）...`;
   if(/^Item\s+(\d+)\s+of\s+(\d+)$/.test(text)){const m=text.match(/^Item\s+(\d+)\s+of\s+(\d+)$/);return `第 ${m[1]} / ${m[2]} 件商品`;}
  let m=text.match(/^Clicked "Publish now"; waiting for the completion page\.\.\.\s*(\d+)\/(\d+)\s*sec$/);if(m)return `已按下「立即刊登」，等待完成頁面… ${m[1]}/${m[2]} 秒`;
  m=text.match(/^Waiting for the form to finish before publishing\.\.\.\s*(\d+)\/(\d+)\s*sec$/);if(m)return `正在等候表單完成後發布… ${m[1]}/${m[2]} 秒`;
  m=text.match(/^Adding\s+(\d+)\s+images\.\.\.$/);if(m)return `正在放入 ${m[1]} 張圖片...`;
  m=text.match(/^Added\s+(\d+)\s+products\. Here is one original image for each product$/);if(m)return `已新增 ${m[1]} 件商品，以下是每件商品的一張原始圖片`;
  m=text.match(/^Estimated total:\s*(?:(\d+)h\s*)?(?:(\d+)m\s*)?(\d+)s$/);if(m)return `全部流程預計：${m[1]?m[1]+'小時 ':''}${m[2]?m[2]+'分鐘 ':''}${m[3]}秒`;
  m=text.match(/^Total time:\s*(?:(\d+)h\s*)?(?:(\d+)m\s*)?(\d+)s$/);if(m)return `本次總耗時：${m[1]?m[1]+'小時 ':''}${m[2]?m[2]+'分鐘 ':''}${m[3]}秒`;
  m=text.match(/^(\d+) missing or incompatible items found$/);if(m)return `發現 ${m[1]} 項缺失或版本不符`;
  m=text.match(/^Environment check complete:\s*(\d+) missing or incompatible items found\.$/);if(m)return `環境檢查完成：有 ${m[1]} 項缺失或版本不符。`;
  m=text.match(/^Current version: Python\s+(.+)$/);if(m)return `目前版本：Python ${m[1]}`;
  m=text.match(/^Current version: Pillow\s+(.+)$/);if(m)return `目前版本：Pillow ${m[1]}`;
  m=text.match(/^Playwright\s+(.+), Chromium installed$/);if(m)return `Playwright ${m[1]}，Chromium 已安裝`;
  m=text.match(/^Playwright\s+(.+) is outdated$/);if(m)return `Playwright ${m[1]}版本過舊`;
  m=text.match(/^Playwright\s+(.+), Chromium component not found$/);if(m)return `Playwright ${m[1]}，找不到 Chromium 元件`;
  m=text.match(/^Found:\s*(.+)$/);if(m)return `已找到：${m[1]}`;
  m=text.match(/^Read failed:\s*(.+)$/);if(m)return `讀取失敗：${m[1]}`;
  m=text.match(/^Not installed \((.+)\)$/);if(m)return `未安裝（${m[1]}）`;
  m=text.match(/^Incomplete installation:\s*(.+)$/);if(m)return `未完整安裝：${m[1]}`;
  if(runtimeEnZh[text])return runtimeEnZh[text];
  return text.replace(/^Last updated:\s*/,'最後更新：').replace(/^Estimated total:\s*/,'全部流程預計：').replace(/^Total time:\s*/,'本次總耗時：');
}
function translateRuntime(){
  if(typeof pageLang==='undefined')return;
  ['message','notice','updated','eta','count','product','phase','tutorialKicker','tutorialTitle','tutorialText','tutorialPrev','tutorialNext'].forEach(id=>{const el=document.querySelector('#'+id);if(el&&el.textContent){const next=runtimeText(el.textContent);if(next!==el.textContent)el.textContent=next;}});
  const summary=document.querySelector('#uploadSummary');
  if(summary&&summary.dataset.count&&!summary.dataset.grouping){const n=summary.dataset.count;summary.textContent=pageLang==='en'?`Added ${n} products. Here is one original image for each product`:`已新增 ${n} 件商品，以下是每件商品的一張原始圖片`;}
  const environment=document.querySelector('#environmentResult');
  if(environment){const walker=document.createTreeWalker(environment,NodeFilter.SHOW_TEXT);let node;while(node=walker.nextNode()){const raw=node.nodeValue,trimmed=raw.trim();if(!trimmed)continue;const next=runtimeText(trimmed);if(next!==trimmed)node.nodeValue=raw.replace(trimmed,next);}}
}
 function watchRuntime(id){const el=document.querySelector('#'+id);if(el)new MutationObserver(translateRuntime).observe(el,{childList:true,characterData:true,subtree:true});}
  setInterval(translateRuntime,1000);document.addEventListener('DOMContentLoaded',()=>{translateRuntime();['message','notice','updated','eta','count','product','phase','tutorialKicker','tutorialTitle','tutorialText','tutorialPrev','tutorialNext','environmentResult'].forEach(watchRuntime)});
</script>"""
    no_photo_js = "<script>function showNoPhoto(message){const modal=document.querySelector('#noPhotoModal'),text=document.querySelector('#noPhotoText');if(text&&message)text.textContent=pageLang==='en'?'No photos found. Put product photos in the Auto-group photos area first.':message;modal.classList.add('show');document.querySelector('#closeNoPhoto').focus()}function closeNoPhoto(){document.querySelector('#noPhotoModal').classList.remove('show')}document.querySelector('#closeNoPhoto').addEventListener('click',closeNoPhoto);document.querySelector('#noPhotoModal').addEventListener('click',e=>{if(e.target.id==='noPhotoModal')closeNoPhoto()});</script>"
    html = html.replace('<script>\nconst labels=', i18n_js + runtime_i18n_js + no_photo_js + frontend_grouping_js + upload_js + '<script>\nconst labels=', 1)
    html = html.replace("function renderEnvironment(report){const el=document.querySelector('#environmentResult');if(!el)return;if(!report||", "function renderEnvironment(report){const el=document.querySelector('#environmentResult');if(!el)return;const environmentKey=JSON.stringify(report||null);if(window.__environmentRenderKey===environmentKey)return;window.__environmentRenderKey=environmentKey;if(!report||", 1)
    html = html.replace('setInterval(refresh,500)', 'setInterval(refresh,1000)', 1)
    html = html.replace(
        "async function refresh(){try{",
        "async function refresh(){if(window.__statusRefreshInFlight)return;window.__statusRefreshInFlight=true;try{",
        1,
    )
    html = html.replace(
        "}}setInterval(refresh,1000);refresh();",
        "}finally{window.__statusRefreshInFlight=false}}setInterval(refresh,1000);refresh();",
        1,
    )
    html = html.replace('if(s.environment)renderEnvironment(s.environment);', 'if(s.environment)renderEnvironment(s.environment);if(window.applyFileState)window.applyFileState(s);', 1)
    html = html.replace("document.querySelector('#product').textContent=s.title||'目前沒有商品';", "document.querySelector('#product').textContent=typeof runtimeText==='function'?runtimeText(s.title||'目前沒有商品'):s.title||'目前沒有商品';", 1)
    html = html.replace("document.querySelector('#message').textContent=s.message||'';", "document.querySelector('#message').textContent=typeof runtimeText==='function'?runtimeText(s.message||''):s.message||'';", 1)
    html = html.replace("productThumb.src='/thumbnail?bucket=processing&name='+encodeURIComponent(s.title);productThumb.classList.add('show');", "const thumbUrl='/thumbnail?bucket=processing&name='+encodeURIComponent(s.title);if(productThumb.getAttribute('src')!==thumbUrl)productThumb.src=thumbUrl;productThumb.classList.add('show');", 1)
    html = html.replace("document.querySelector('#phase').textContent=labels[s.phase]||s.phase||'';", "document.querySelector('#phase').textContent=typeof runtimeText==='function'?runtimeText(labels[s.phase]||s.phase||''):labels[s.phase]||s.phase||'';", 1)
    html = html.replace("document.querySelector('#updated').textContent='最後更新：'+(s.updated||'');", "document.querySelector('#updated').textContent=typeof runtimeText==='function'?runtimeText('最後更新：'+(s.updated||'')):'最後更新：'+(s.updated||'');", 1)
    html = html.replace("el.textContent=etaCompleted?'本次已完成':'全部流程預計：計算中';", "el.textContent=typeof runtimeText==='function'?runtimeText(etaCompleted?'本次已完成':'全部流程預計：計算中'):(etaCompleted?'本次已完成':'全部流程預計：計算中');", 1)
    html = html.replace("el.textContent=(etaCompleted?'本次總耗時：':'全部流程預計：')+(h?`${h}小時 `:'')+(m?`${m}分鐘 `:'')+`${sec}秒`;", "const etaText=(etaCompleted?'本次總耗時：':'全部流程預計：')+(h?`${h}小時 `:'')+(m?`${m}分鐘 `:'')+`${sec}秒`;el.textContent=typeof runtimeText==='function'?runtimeText(etaText):etaText;", 1)
    html = html.replace("x.message||'圖片已放入待發布。';refreshFiles()", "x.message||'圖片已放入待發布。';if(x.ok&&Array.isArray(x.folders))showUploadAdded(x.folders);refreshFiles()", 1)
    html = html.replace('<span>一次拖入大量圖片</span>', '', 1)
    html = html.replace("if(productThumb&&s.title&&s.title!=='Carousell 小助手'&&s.title!=='全部商品')", "if(productThumb&&s.title&&s.title!=='Carousell 小助手'&&s.title!=='全部商品'&&s.title!=='商品'&&s.title!=='帳戶商品操作'&&s.title!=='檢查完成'&&s.title!=='檢查賬戶刊登商品')", 1)
    html = html.replace('data-action="open_root:unprocessed" title="開啟待發布資料夾">📂 開啟資料夾</button>', '<button class="open-root-btn duplicate-clean-btn" data-action="delete_duplicates" title="比對帳戶全部商品相簿，任意一張相同就略過整組並移到已完成檔案">🧹 檢查賬戶重複</button><button class="open-root-btn" data-action="open_root:unprocessed" title="開啟待發布資料夾">📂 開啟資料夾</button>', 1)
    html = html.replace('<div class="live-mark">', '<button class="tutorial-launch" id="tutorialStart" type="button">✨ 新手教學</button><button class="language-toggle" id="languageToggle" type="button">EN</button><div class="live-mark">', 1)
    html = html.replace(
        '<button class="btn stop" data-action="stop">⏹ 停止</button>',
        '<button class="btn stop" data-action="stop">⏹ 停止</button><button class="btn light" data-action="cleanup_background" title="只關閉 Carousell 小助手背景程序，保留目前狀態頁與其他應用程式">🧽 清理背景程序</button>',
        1,
    )
    html = html.replace(
        '<button class="btn skip" id="skipCurrent" data-action="skip_current">⏭ 跳過這件，處理下一件</button>',
        '<button class="btn skip" id="skipCurrent" data-action="skip_current">⏭ 跳過這件，處理下一件</button><div class="test-tools" aria-label="測試功能"><div class="test-tools-title">測試功能</div><div class="test-tools-note">以下操作會逐件處理 Carousell 帳戶商品，請先確認登入的是正確帳戶。</div><div class="test-tools-buttons"><button class="btn light account-action" data-action="delete_all_listings" title="刪除 Carousell 帳戶內所有已刊登商品">刪除全部已刊登</button><button class="btn light account-action" data-action="enable_all_buy_buttons" title="只開啟目前關閉的購買按鈕">開啟未開啟的購買按鈕</button><button class="btn light account-action" data-action="disable_all_buy_buttons" title="關閉所有目前開啟的購買按鈕">關閉所有已開啟的購買按鈕</button></div></div>',
        1,
    )
    action_start = html.index("async function runAction(action){")
    action_end = html.index("\ndocument.querySelectorAll('[data-action]')", action_start)
    action_handler = """let actionLocks={};let activeWorkerActionKeys=new Set();const asyncActionKeys=new Set(['attach_publish','prepare','setup','manual_preview','delete_duplicates','delete_all_listings','enable_all_buy_buttons','disable_all_buy_buttons']);function actionKey(action){return String(action||'').split(':',1)[0]}function setActionButtons(key,disabled){document.querySelectorAll('[data-action]').forEach(button=>{if(actionKey(button.dataset.action)===key)button.disabled=disabled})}function releaseActionLock(key){if(!key)return;delete actionLocks[key];activeWorkerActionKeys.delete(key);setActionButtons(key,false)}async function runAction(action){const key=actionKey(action);if(actionLocks[key]&&action!=='stop')return;if(action==='delete_all_listings'&&!window.confirm('這會刪除 Carousell 帳戶內所有已刊登商品，操作不可逆。確定要繼續嗎？'))return;if((action==='enable_all_buy_buttons'||action==='disable_all_buy_buttons')&&!window.confirm(action==='enable_all_buy_buttons'?'這會開啟所有目前關閉的購買按鈕，已開啟的商品會略過。確定要繼續嗎？':'這會關閉所有目前開啟的購買按鈕，已關閉的商品會略過。確定要繼續嗎？'))return;const asyncAction=asyncActionKeys.has(key);actionLocks[key]=true;if(asyncAction)activeWorkerActionKeys.add(key);setActionButtons(key,true);const notice=document.querySelector('#notice');notice.textContent='正在啟動操作...';let succeeded=false;try{const r=await fetch('/action',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action='+encodeURIComponent(action)});const x=await r.json();notice.textContent=x.message||'';succeeded=Boolean(x.ok);if(!x.ok&&x.message&&(/沒有照片|沒有找到可用的圖片|先把照片放入/.test(x.message))&&typeof showNoPhoto==='function')showNoPhoto(x.message);if(x.environment)renderEnvironment(x.environment)}catch(e){notice.textContent='無法連接本機控制服務。'}finally{if(!asyncAction||!succeeded)releaseActionLock(key);refresh()}}"""
    html = html[:action_start] + action_handler + html[action_end:]
    html = html.replace("setInterval(refreshFiles,700);refreshFiles();", "", 1)
    html = html.replace(
        "if(s.phase==='done')showCompletion(s.completion_summary,s.updated);",
        "if(s.phase==='done')showCompletion(s.completion_summary,s.updated);const workerBusy=Boolean(s.worker_running)||['starting','prepare','check','autofill','manual_review','publish','account_action'].includes(s.phase);if(!workerBusy&&activeWorkerActionKeys.size){[...activeWorkerActionKeys].forEach(releaseActionLock)}document.querySelectorAll('[data-action]').forEach(b=>{const key=actionKey(b.dataset.action);if(key==='stop')b.disabled=!workerBusy;else if(key==='skip_current')b.disabled=s.phase!=='manual_review';else b.disabled=Boolean(actionLocks[key])});",
        1,
    )
    tutorial_markup = '<div class="tutorial-layer" id="tutorialLayer" aria-live="polite"><div class="tutorial-mask tutorial-mask-top" id="tutorialMaskTop"></div><div class="tutorial-mask tutorial-mask-left" id="tutorialMaskLeft"></div><div class="tutorial-mask tutorial-mask-right" id="tutorialMaskRight"></div><div class="tutorial-mask tutorial-mask-bottom" id="tutorialMaskBottom"></div><div class="tutorial-card" id="tutorialCard"><div class="tutorial-kicker" id="tutorialKicker">新手教學</div><h2 id="tutorialTitle"></h2><p id="tutorialText"></p><div class="tutorial-footer"><span id="tutorialCount"></span><div><button class="tutorial-prev" id="tutorialPrev" type="button">上一步</button><button class="tutorial-next" id="tutorialNext" type="button">下一步</button></div></div></div></div>'
    no_photo_markup = f'<div class="no-photo-modal" id="noPhotoModal" role="dialog" aria-modal="true"><div class="no-photo-card"><div class="no-photo-icon">🖼️</div><h2 id="noPhotoTitle">請把照片放在「自動分組商品」</h2><p id="noPhotoText">目前沒有可處理的照片。請把商品圖片拖到右側的「自動分組商品」區域，程序會自動分組後再開始。<br><small>可讀取格式：{IMAGE_FORMAT_LABEL}</small></p><button class="no-photo-close" id="closeNoPhoto" type="button">知道了</button></div></div>'
    html = html.replace('</main>', no_photo_markup + tutorial_markup + '</main>', 1)
    html = html.replace("const labels={", "const labels={account_action:'帳戶商品操作',", 1)
    # Use one shadowed cutout instead of four touching rectangles. This keeps
    # the tutorial dimming continuous without white or dark seam lines.
    html = html.replace(
        ".tutorial-card{left:32px;transform:none}@media(max-width:560px){.tutorial-card{left:14px;transform:none;width:calc(100vw - 28px)}}",
        ".tutorial-card{left:32px;transform:none}@media(max-width:560px){.tutorial-card{left:14px;transform:none;width:calc(100vw - 28px)}}.tutorial-mask-left,.tutorial-mask-right,.tutorial-mask-bottom{display:none!important}.tutorial-mask-top{background:transparent!important;box-shadow:0 0 0 100vmax rgba(18,18,18,.72);pointer-events:none!important}",
        1,
    )
    html = html.replace(
        "const r=target.getBoundingClientRect(),pad=8,top=Math.max(0,r.top-pad),bottom=Math.min(innerHeight,r.bottom+pad),left=Math.max(0,r.left-pad),right=Math.min(innerWidth,r.right+pad),height=Math.max(0,bottom-top);Object.assign(document.querySelector('#tutorialMaskTop').style,{left:'0',top:'0',width:'100%',height:top+'px'});Object.assign(document.querySelector('#tutorialMaskLeft').style,{left:'0',top:top+'px',width:left+'px',height:height+'px'});Object.assign(document.querySelector('#tutorialMaskRight').style,{left:right+'px',top:top+'px',width:Math.max(0,innerWidth-right)+'px',height:height+'px'});Object.assign(document.querySelector('#tutorialMaskBottom').style,{left:'0',top:bottom+'px',width:'100%',height:Math.max(0,innerHeight-bottom)+'px'});",
        "const r=target.getBoundingClientRect(),pad=8,top=Math.max(0,r.top-pad),bottom=Math.min(innerHeight,r.bottom+pad),left=Math.max(0,r.left-pad),right=Math.min(innerWidth,r.right+pad),height=Math.max(0,bottom-top);Object.assign(document.querySelector('#tutorialMaskTop').style,{left:left+'px',top:top+'px',width:(right-left)+'px',height:height+'px',background:'transparent',boxShadow:'0 0 0 100vmax rgba(18,18,18,.72)',pointerEvents:'none'});",
        1,
    )
    # Remove decorative emoji prefixes from the dashboard while keeping the
    # product images and functional controls intact.
    for icon in (
        "📄 ", "⏳ ", "✅ ", "🔎 ", "🌟 ", "🚀 ", "🧹 ", "⏹ ", "⏭ ",
        "💡 ", "🐞", "↗", "📁 ", "📂 ", "📦 ", "➕ ", "✨ ", "🧰 ",
        "🐍 ", "🌐 ", "🖼️ ", "🖼️", "🎭 ", "📘 ", "🩺 ", "⚠️ ", "⚠", "🎉",
        "📥", "🗑", "🧽 ",
    ):
        html = html.replace(icon, "")
    html = html.replace("Carousell 小助手", "Aetheris").replace("小助手", "Aetheris")
    html = html.replace("const s=await r.json();", "let s=await r.json();if(window.AetherisGrouping)s=window.AetherisGrouping.decorateStatus(s);", 1)
    html = html.replace("async function runAction(action){const key=", "async function runAction(action){if(action==='stop')window.AetherisGrouping?.cancel();else window.AetherisGrouping?.clear();const key=", 1)
    html = html.replace("if(key==='stop')b.disabled=!workerBusy;", "if(key==='stop')b.disabled=!workerBusy&&!window.AetherisGrouping?.state.active;", 1)
    html = html.replace("if(s.phase==='done')showCompletion", "if(s.phase==='grouping'){const e=document.querySelector('#eta');if(e)e.textContent='';}if(s.phase==='done')showCompletion", 1)
    html = html.replace('</head>', '<style>.grouped-product .group-thumbnails{display:flex;flex-wrap:wrap;gap:5px}.grouped-product .group-thumbnails img{width:68px;height:68px;object-fit:contain;background:#fafafa;border-radius:8px}.group-photo-count{display:block;font-size:13px;color:#545454;margin-top:6px}.grouped-product strong{overflow-wrap:anywhere}#dropzone[aria-busy="true"]{cursor:progress}</style></head>', 1)
    html = html.replace("const labels={", "const labels={grouping:'自動分組商品',", 1)
    html = html.replace('<ul id="unprocessed"></ul>', '<div style="text-align:right;margin:6px 0"><button type="button" class="open-root-btn" id="editPendingGroups">調整分組</button></div><ul id="unprocessed"></ul>', 1)
    html = html.replace('"工作台":"Workspace",', '"調整分組":"Adjust groups","工作台":"Workspace",', 1)
    return html


def dashboard_thumbnail_url(bucket: str, name: str) -> str:
    return f"/thumbnail?bucket={quote(bucket)}&name={quote(name)}"


def dashboard_file_lists(current: dict) -> dict:
    error_products = load_error_products()

    def folders(root: Path, bucket: str) -> list[dict[str, str]]:
        if not root.exists():
            return []
        result = []
        for folder in sorted(root.iterdir()):
            if folder.is_dir() and not folder.name.startswith("_"):
                marker = error_products.get(folder.name)
                missing_images = bucket == "unprocessed" and not image_files(folder)
                result.append({
                    "name": folder.name,
                    "thumb": dashboard_thumbnail_url(bucket, folder.name),
                    "error": (
                            f"請先把照片放入此商品資料夾（支援 {IMAGE_FORMAT_LABEL}）"
                        if missing_images
                        else marker.get("message", "曾出現問題") if marker else ""
                    ),
                })
        return result

    processing = []
    title = str(current.get("title", ""))
    if title and title not in ("Aetheris", "Carousell 小助手", "全部商品") and current.get("phase") not in ("done", "duplicate", "skip"):
        marker = error_products.get(title)
        processing = [{
            "name": title,
            "thumb": dashboard_thumbnail_url("processing", title),
            "error": marker.get("message", "曾出現問題") if marker else "",
        }]
    return {
        "completed": folders(COMPLETED, "completed"),
        "unprocessed": folders(INBOX, "unprocessed"),
        "processing": processing,
    }


def thumbnail_source(bucket: str, name: str) -> Path | None:
    """Resolve a named product to its first original image for the dashboard."""
    if not name or Path(name).name != name:
        return None
    roots = {
        "completed": [COMPLETED],
        "unprocessed": [INBOX],
        "processing": [INBOX, COMPLETED, PROCESSED],
    }.get(bucket, [])
    for root in roots:
        folder = (root / name).resolve()
        try:
            if not folder.is_relative_to(root.resolve()) or not folder.is_dir():
                continue
        except AttributeError:
            if not str(folder).startswith(str(root.resolve())) or not folder.is_dir():
                continue
        images = image_files(folder)
        if images:
            return images[0]
    if bucket == "processing":
        # Carousell's generated title can differ from the source folder name.
        for root in roots:
            if not root.exists():
                continue
            for folder in root.iterdir():
                if not folder.is_dir() or folder.name.startswith("_"):
                    continue
                draft_file = folder / "draft.json"
                try:
                    draft = json.loads(draft_file.read_text(encoding="utf-8"))
                except (OSError, ValueError, json.JSONDecodeError):
                    continue
                if str(draft.get("title", "")).strip() == name:
                    images = image_files(folder)
                    if images:
                        return images[0]
    return None


def start_status_dashboard(total: int):
    state = StatusState(total)
    controller = StatusController()
    grouping = GroupingStore(ROOT, INBOX, IMAGE_EXTS)
    original_start = controller.start

    def start_with_folder_lock(action):
        with grouping.lock:
            return original_start(action)

    controller.start = start_with_folder_lock

    class Handler(BaseHTTPRequestHandler):
        def handle(self):
            try:
                super().handle()
            except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
                # The user may close/rerender a thumbnail or leave the page.
                # A completed save is safely retryable using its request ID.
                pass

        def send_json(self, value: dict, status: int = 200):
            payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path.startswith(("/assets/ui/", "/assets/grouping/", "/assets/vendor/", "/assets/models/")):
                relative = path.lstrip("/").replace("/", os.sep)
                asset_path = (ROOT / relative).resolve()
                root_path = ROOT.resolve()
                try:
                    allowed = asset_path.is_relative_to((root_path / "assets").resolve())
                except AttributeError:
                    allowed = os.path.commonpath([str(asset_path), str(root_path / "assets")]) == str(root_path / "assets")
                if not allowed or not asset_path.is_file():
                    self.send_error(404)
                    return
                payload = asset_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/javascript" if asset_path.suffix == ".js" else "application/wasm" if asset_path.suffix == ".wasm" else mimetypes.guess_type(str(asset_path))[0] or "application/octet-stream")
                self.send_header("Cache-Control", "no-cache" if asset_path.suffix == ".js" else "public, max-age=86400")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            if path == "/grouping/photo":
                try:
                    query = parse_qs(urlsplit(self.path).query)
                    source = grouping.photo_path(query.get("folder", [""])[0], query.get("file", [""])[0])
                    with Image.open(source) as original:
                        image = ImageOps.exif_transpose(original).convert("RGB")
                        image.thumbnail((180, 180), Image.Resampling.LANCZOS)
                        output = BytesIO()
                        image.save(output, format="JPEG", quality=88)
                    payload = output.getvalue()
                    self.send_response(200)
                    self.send_header("Content-Type", "image/jpeg")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                except (GroupingError, OSError, ValueError, Image.DecompressionBombError):
                    self.send_error(404)
                return
            if path == "/thumbnail":
                query = parse_qs(urlsplit(self.path).query)
                bucket = query.get("bucket", [""])[0]
                name = query.get("name", [""])[0]
                source = thumbnail_source(bucket, name)
                if source is None:
                    self.send_error(404)
                    return
                try:
                    with Image.open(source) as original:
                        image = ImageOps.exif_transpose(original)
                        if image.mode in ("RGBA", "LA"):
                            background = Image.new("RGB", image.size, "white")
                            background.paste(image, mask=image.getchannel("A"))
                            image = background
                        else:
                            image = image.convert("RGB")
                        image.thumbnail((96, 96), Image.Resampling.LANCZOS)
                        output = BytesIO()
                        image.save(output, format="JPEG", quality=84, optimize=True)
                        payload = output.getvalue()
                except (OSError, ValueError, RuntimeError):
                    self.send_error(404)
                    return
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return
            if path == "/status.json":
                try:
                    current = json.loads(STATUS_STATE_FILE.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    current = state.snapshot()
                if current.get("phase") == "done" and current.get("allow_completion") and not current.get("completion_summary"):
                    try:
                        report = json.loads((ROOT / "last_run.json").read_text(encoding="utf-8"))
                        current["completion_summary"] = {
                            "total": int(current.get("total") or len(report.get("success", [])) + len(report.get("duplicates", [])) + len(report.get("skipped", [])) + len(report.get("failed", []))),
                            "success": len(report.get("success", [])),
                            "duplicates": len(report.get("duplicates", [])),
                            "skipped": len(report.get("skipped", [])),
                            "failed": len(report.get("failed", [])),
                        }
                    except (OSError, ValueError, json.JSONDecodeError):
                        pass
                current["worker_running"] = controller.process is not None and controller.process.poll() is None
                current["dashboard_version"] = DASHBOARD_VERSION
                current["files"] = dashboard_file_lists(current)
                self.send_json(current)
                return
            payload = dashboard_html().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def do_POST(self):
            path = self.path.split("?", 1)[0]
            if path in {"/grouping/inspect", "/grouping/save"}:
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 2 * 1024 * 1024:
                        raise GroupingError("分組資料過大或無效。")
                    payload = json.loads(self.rfile.read(length).decode("utf-8"))
                    if not isinstance(payload, dict):
                        raise GroupingError("分組資料無效。")
                    if path == "/grouping/inspect":
                        result = grouping.inspect(payload.get("folders"))
                    else:
                        result = grouping.save(payload, busy=lambda: controller.process is not None and controller.process.poll() is None)
                    self.send_json(result)
                except GroupingError as exc:
                    self.send_json({"ok": False, "message": str(exc)}, exc.status)
                except (OSError, ValueError, UnicodeDecodeError) as exc:
                    self.send_json({"ok": False, "message": f"無法調整分組：{exc}"}, 400)
                return
            if path == "/decode-image":
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 95 * 1024 * 1024:
                        self.send_error(413)
                        return
                    with Image.open(BytesIO(self.rfile.read(length))) as original:
                        image = ImageOps.exif_transpose(original).convert("RGB")
                        image.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
                        output = BytesIO()
                        image.save(output, format="PNG")
                        payload = output.getvalue()
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.send_header("Cache-Control", "no-store")
                    self.send_header("Content-Length", str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                except (OSError, ValueError, Image.DecompressionBombError):
                    self.send_error(400, "Cannot decode this image")
                return
            if path == "/upload":
                grouping.lock.acquire()
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 100 * 1024 * 1024:
                        self.send_json({"ok": False, "message": "圖片總大小不能超過 100 MB。"}, 413)
                        return
                    content_type = self.headers.get("Content-Type", "")
                    match = re.search(r"boundary=(?:\"([^\"]+)\"|([^;]+))", content_type, flags=re.I)
                    if not match:
                        self.send_json({"ok": False, "message": "無法讀取圖片上傳資料。"}, 400)
                        return
                    boundary = (match.group(1) or match.group(2)).strip().encode("utf-8")
                    raw = self.rfile.read(length)
                    uploaded = []
                    requested_group_id = ""
                    request_id = ""
                    INBOX.mkdir(parents=True, exist_ok=True)
                    for part in raw.split(b"--" + boundary):
                        if b"Content-Disposition:" not in part:
                            continue
                        header, data = part.split(b"\r\n\r\n", 1) if b"\r\n\r\n" in part else (b"", b"")
                        if data.endswith(b"\r\n"):
                            data = data[:-2]
                        if re.search(br'name="request_id"', header, flags=re.I):
                            request_id = data.decode("utf-8", errors="replace").strip()
                            continue
                        group_match = re.search(br'name="group_id"', header, flags=re.I)
                        if group_match:
                            requested_group_id = data.decode("utf-8", errors="replace").strip()
                            continue
                        if b"filename=" not in part:
                            continue
                        name_match = re.search(br'filename="([^"]*)"', header, flags=re.I)
                        if not name_match:
                            continue
                        filename = name_match.group(1).decode("utf-8", errors="replace")
                        filename = Path(filename.replace("\\", "/")).name.strip()
                        if not filename or Path(filename).suffix.lower() not in IMAGE_EXTS:
                            continue
                        filename = safe_name(filename)
                        if not data:
                            continue
                        with Image.open(BytesIO(data)) as check_image:
                            check_image.verify()
                        uploaded.append((filename, data))
                    if not uploaded:
                        self.send_json({"ok": False, "message": "沒有找到可用的圖片檔案。"}, 400)
                        return
                    receipt_path = None
                    if re.fullmatch(r"[a-f0-9]{16}-\d{1,4}", request_id):
                        receipt_path = ROOT / ".upload_receipts" / (request_id + ".json")
                        if receipt_path.is_file():
                            self.send_json(json.loads(receipt_path.read_text(encoding="utf-8")))
                            return
                    # The browser-side embedding pipeline may send an explicit
                    # group.  Keep that group intact; otherwise use the
                    # Pillow fallback for older/offline browsers.
                    grouped = {safe_name(requested_group_id): uploaded} if requested_group_id else group_uploaded_images(uploaded)
                    folders = []
                    saved = []
                    for group_key, files in grouped.items():
                        batch_folder = new_batch_product_folder(f"商品_{group_key}")
                        folders.append(batch_folder.name)
                        for filename, data in files:
                            target = batch_folder / filename
                            stem, suffix = target.stem, target.suffix
                            counter = 2
                            while target.exists():
                                target = batch_folder / f"{stem} ({counter}){suffix}"
                                counter += 1
                            target.write_bytes(data)
                            saved.append(f"{batch_folder.name}/{target.name}")
                    visual_groups = sum(1 for key in grouped if key.startswith("視覺組"))
                    group_note = f"，其中 {visual_groups} 組按商品視覺特徵分組" if visual_groups else ""
                    result = {"ok": True, "message": f"已自動分成 {len(folders)} 件商品，共 {len(saved)} 張圖片{group_note}。", "saved": saved, "folders": folders}
                    if receipt_path is not None:
                        receipt_path.parent.mkdir(exist_ok=True)
                        receipt_path.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
                    self.send_json(result)
                except (OSError, ValueError, Image.DecompressionBombError) as exc:
                    self.send_json({"ok": False, "message": f"圖片放入失敗：{exc}"}, 500)
                finally:
                    grouping.lock.release()
                return
            if path != "/action":
                self.send_error(404)
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                body = self.rfile.read(length).decode("utf-8")
                action = parse_qs(body).get("action", [""])[0]
            except (ValueError, IndexError, UnicodeDecodeError):
                action = ""
            environment_result = None
            if action in {"delete_duplicates", "delete_all_listings", "enable_all_buy_buttons", "disable_all_buy_buttons"}:
                state.update(
                    phase="starting",
                    title="帳戶商品操作",
                    message="正在啟動帳戶商品操作...",
                    current=0,
                    percent=0,
                    warning=False,
                    completion_summary=None,
                    allow_completion=False,
                )
                ok, message = controller.start(action)
                if not ok:
                    state.update(phase="error", warning=True, message=message)
            elif action.startswith("open_root:"):
                bucket = action.split(":", 1)[1]
                try:
                    opened = open_dashboard_root(bucket)
                    ok, message = True, f"已開啟大資料夾：{opened.name}"
                except (OSError, ValueError) as exc:
                    ok, message = False, f"無法開啟大資料夾：{exc}"
            elif action.startswith("open_folder:"):
                parts = action.split(":", 2)
                if len(parts) != 3:
                    ok, message = False, "無效的資料夾操作。"
                else:
                    try:
                        opened = open_dashboard_folder(parts[1], parts[2])
                        ok, message = True, f"已開啟資料夾：{opened.name}"
                    except (OSError, ValueError, FileNotFoundError) as exc:
                        ok, message = False, f"無法開啟資料夾：{exc}"
            elif action.startswith("delete_product:"):
                product = action.split(":", 1)[1]
                try:
                    current = json.loads(STATUS_STATE_FILE.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    current = state.snapshot()
                active_phases = {"starting", "prepare", "check", "autofill", "manual_review", "publish"}
                running = controller.process is not None and controller.process.poll() is None
                if running and current.get("title") == product and current.get("phase") in active_phases:
                    ok, message = False, "這件商品正在處理中，不能在處理途中刪除。"
                else:
                    try:
                        clear_product_error(INBOX / product)
                        destination = move_to_deleted(product)
                        ok, message = True, f"已將「{product}」移到已刪除檔案。"
                        print(f"已將商品移到已刪除檔案：{destination}")
                    except (OSError, ValueError) as exc:
                        ok, message = False, f"刪除商品失敗：{exc}"
            elif action.startswith("manual_preview:"):
                product = action.split(":", 1)[1]
                ok, message = controller.start_preview(product)
                if ok:
                    state.update(phase="starting", title=product, message=f"正在開啟「{product}」的預覽頁...", current=1, total=1, completion_summary=None, allow_completion=False)
            elif action == "skip_current":
                try:
                    current = json.loads(STATUS_STATE_FILE.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    current = state.snapshot()
                running = controller.process is not None and controller.process.poll() is None
                if not running:
                    ok, message = False, "目前沒有正在處理的商品。"
                elif current.get("phase") != "manual_review":
                    ok, message = False, "目前沒有需要手動補填的商品。"
                else:
                    try:
                        request_control("skip_current")
                        ok, message = True, "已通知程序跳過目前商品，準備處理下一件。"
                    except OSError as exc:
                        ok, message = False, f"無法傳送跳過指令：{exc}"
            elif action == "stop":
                ok = controller.stop()
                message = "已要求停止目前工作。" if ok else "目前沒有正在執行的工作。"
                if ok:
                    state.update(phase="error", message="已停止目前工作。")
            elif action == "cleanup_background":
                ok, message = cleanup_background_processes(controller)
                state.update(
                    phase="error" if not ok else "done",
                    message=message,
                    current=0,
                    total=0,
                    percent=100 if ok else 0,
                    eta_seconds=None,
                    total_estimate_seconds=None,
                    completion_summary=None,
                    allow_completion=False,
                )
            elif action == "check":
                environment_result = collect_environment_report()
                missing = int(environment_result.get("missing_count") or 0)
                ok = True
                message = "環境檢查完成，全部必要元件可用。" if not missing else f"環境檢查完成：有 {missing} 項缺失或版本不符。"
                state.update(
                    phase="done",
                    current=0,
                    percent=100,
                    warning=bool(missing),
                    message=message,
                    environment=environment_result,
                    eta_seconds=None,
                    total_estimate_seconds=None,
                    completion_summary=None,
                    allow_completion=False,
                )
            else:
                ok, message = controller.start(action)
                if ok:
                    if action == "open_chrome":
                        state.update(phase="done", message="已打開新的可接管 Chrome，尚未開始發布。", current=0, percent=0, warning=False, completion_summary=None, allow_completion=False)
                        message = "已打開新的可接管 Chrome，尚未開始發布。"
                    else:
                        state.update(phase="starting", message="已從狀態頁啟動操作，正在準備...", current=0, completion_summary=None, allow_completion=False)
                        process = controller.process
                        if process is not None:
                            def report_early_exit(child):
                                try:
                                    child.wait(timeout=8)
                                except subprocess.TimeoutExpired:
                                    return
                                try:
                                    current_state = json.loads(STATUS_STATE_FILE.read_text(encoding="utf-8"))
                                except (OSError, json.JSONDecodeError):
                                    current_state = {}
                                if current_state.get("phase") == "starting":
                                    state.update(
                                        phase="error",
                                        warning=True,
                                        message=f"工作程序已退出（代碼 {child.returncode}），請重新檢查環境，並確認已完成一鍵安裝。",
                                        completion_summary=None,
                                        allow_completion=False,
                                    )
                            threading.Thread(target=report_early_exit, args=(process,), daemon=True).start()
            response = {"ok": ok, "message": message}
            if environment_result is not None:
                response["environment"] = environment_result
            self.send_json(response)

        def log_message(self, *args):
            return

    # Reuse this installation's previous local address when it is free, so
    # updating/restarting the tool does not strand the user's existing tab.
    previous_port = 0
    try:
        previous = urlsplit(STATUS_URL_FILE.read_text(encoding="utf-8").strip())
        if previous.hostname == "127.0.0.1" and previous.port:
            previous_port = previous.port
    except (OSError, ValueError):
        pass
    try:
        server = ThreadingHTTPServer(("127.0.0.1", previous_port), Handler)
    except OSError:
        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    try:
        STATUS_URL_FILE.write_text(url, encoding="utf-8")
    except OSError:
        pass
    return server, state, url


def _status_url_is_alive(url: str) -> bool:
    try:
        payload = json.loads(urlopen(url.rstrip("/") + "/status.json", timeout=0.5).read().decode("utf-8"))
        return payload.get("dashboard_version") == DASHBOARD_VERSION and "files" in payload
    except (OSError, ValueError, json.JSONDecodeError):
        return False


def _process_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except (OSError, ProcessLookupError):
        return False
    return True


def _read_status_server_lock() -> tuple[int, str] | None:
    try:
        lines = STATUS_SERVER_LOCK.read_text(encoding="utf-8").splitlines()
        if lines:
            return int(lines[0]), lines[1].strip() if len(lines) >= 2 else ""
    except (OSError, ValueError):
        pass
    return None


def _remove_status_server_lock_if_owned() -> None:
    try:
        lock = _read_status_server_lock()
        if lock and lock[0] == os.getpid():
            STATUS_SERVER_LOCK.unlink()
    except OSError:
        pass


def cleanup_background_processes(controller: StatusController | None = None) -> tuple[bool, str]:
    """Stop only Python processes explicitly running this app, preserving the dashboard server."""
    if os.name != "nt":
        return False, "一鍵清理目前只支援 Windows。"

    lock = _read_status_server_lock()
    dashboard_pid = lock[0] if lock and _process_is_alive(lock[0]) else os.getpid()
    query = (
        "$keep = " + str(int(dashboard_pid)) + "; "
        "Get-CimInstance Win32_Process | "
        "Where-Object { $_.ProcessId -ne $keep -and "
        "$_.Name -match '^python(w)?\\.exe$' -and "
        "$_.CommandLine -match '(?i)carousell_publish\\.py' } | "
        "ForEach-Object { $_.ProcessId }"
    )
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", query],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"無法列出本程序背景工作：{exc}"
    if result.returncode != 0:
        detail = result.stderr.strip().splitlines()
        return False, "無法列出本程序背景工作。" + (f" {detail[-1]}" if detail else "")

    pids = sorted({int(line.strip()) for line in result.stdout.splitlines() if line.strip().isdigit()})
    if not pids:
        return True, "沒有其他 Aetheris 背景程序需要清理。"

    stopped: list[int] = []
    for pid in pids:
        try:
            result = subprocess.run(
                ["taskkill.exe", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                text=True,
                timeout=8,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if result.returncode == 0:
                stopped.append(pid)
        except (OSError, subprocess.SubprocessError):
            continue

    if controller is not None:
        controller.process = None
    try:
        worker_pid = int(WORKER_PID_FILE.read_text(encoding="ascii").strip())
        if worker_pid in stopped:
            WORKER_PID_FILE.unlink(missing_ok=True)
    except (OSError, ValueError):
        pass

    if not stopped:
        return False, "找到本程序背景程序，但未能停止；請檢查 Windows 權限。"
    return True, f"已清理 {len(stopped)} 個本程序背景工作；目前狀態頁仍保持開啟。"


def connect_or_start_status_dashboard(total: int):
    """Reuse a dashboard started by 啟動工具.bat, or start one on demand."""
    try:
        existing_url = STATUS_URL_FILE.read_text(encoding="utf-8").strip()
        if existing_url and _status_url_is_alive(existing_url):
            return None, StatusState(total), existing_url, True
    except OSError:
        pass
    server, state, url = start_status_dashboard(total)
    return server, state, url, False


def run_status_server() -> None:
    # Use an exclusive lock so repeatedly opening 啟動工具.bat cannot create
    # several competing servers that all write the same status file.
    lock_fd = None
    while True:
        try:
            lock_fd = os.open(str(STATUS_SERVER_LOCK), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(lock_fd, f"{os.getpid()}\n".encode("ascii"))
            os.close(lock_fd)
            lock_fd = None
            break
        except FileExistsError:
            lock = _read_status_server_lock()
            if lock and _process_is_alive(lock[0]) and lock[1] and _status_url_is_alive(lock[1]):
                open_status_dashboard(lock[1])
                return
            if lock and _process_is_alive(lock[0]) and not lock[1]:
                # Another launcher is still creating its listening socket.
                time.sleep(0.2)
                continue
            try:
                STATUS_SERVER_LOCK.unlink()
            except OSError:
                return
        except OSError:
            return
    try:
        existing_url = STATUS_URL_FILE.read_text(encoding="utf-8").strip()
        if existing_url and _status_url_is_alive(existing_url):
            # A worker may have started a temporary dashboard before this
            # launcher acquired the lock.  Reuse it and release our lock.
            _remove_status_server_lock_if_owned()
            open_status_dashboard(existing_url)
            return
    except OSError:
        pass
    server, _state, url = start_status_dashboard(0)
    try:
        STATUS_SERVER_LOCK.write_text(f"{os.getpid()}\n{url}\n", encoding="utf-8")
    except OSError:
        pass
    print(f"即時狀態頁面：{url}")
    open_status_dashboard(url)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        try:
            STATUS_URL_FILE.unlink()
        except OSError:
            pass
        _remove_status_server_lock_if_owned()


def find_chrome_executable() -> Path | None:
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for executable in candidates:
        if not executable.is_file():
            continue
        return executable
    return None


def open_status_dashboard(url: str) -> bool:
    """Open the dashboard in a separate ordinary Chrome window."""
    executable = find_chrome_executable()
    if executable is not None:
        try:
            subprocess.Popen(
                [str(executable), "--new-window", url],
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
            return True
        except OSError:
            pass
    try:
        return bool(webbrowser.open(url, new=1))
    except Exception:
        return False


def open_new_chrome_only() -> int:
    """Open an ordinary Chrome window ready for the attach workflow."""
    executable = find_chrome_executable()
    if executable is None:
        print("找不到 Google Chrome。", file=sys.stderr)
        return 1
    attach_profile = ROOT / "chrome_attach_profile"
    attach_profile.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.Popen(
            [
                str(executable),
                "--remote-debugging-port=9222",
                "--new-window",
                "--window-size=1280,900",
                f"--user-data-dir={attach_profile}",
                "https://www.carousell.com.hk/sell",
            ],
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
    except OSError as exc:
        print(f"無法開啟新 Chrome：{exc}", file=sys.stderr)
        return 1
    print("已開啟新的可接管 Chrome，尚未開始發布。")
    return 0


@dataclass
class Draft:
    title: str
    price: str
    condition: str
    category: str
    location: str
    delivery: str
    description: str
    brand: str
    attributes: dict[str, str]
    images: list[str]
    source_folder: str
    research_attempted: bool = False


def load_config() -> dict:
    path = ROOT / "config.json"
    if not path.exists():
        example = ROOT / "config.example.json"
        if not example.exists():
            raise SystemExit(f"找不到 config.json 和 {example.name}，請重新下載完整部署包。")
        try:
            shutil.copy2(example, path)
        except OSError as exc:
            raise SystemExit(f"無法建立 config.json：{exc}") from exc
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"config.json 格式錯誤：第 {exc.lineno} 行。") from exc
    max_images = int(config.get("max_images", 10))
    max_side = int(config.get("max_image_side", 2048))
    if max_images < 1 or max_images > 20:
        raise SystemExit("config.json 的 max_images 必須介乎 1 至 20。")
    if max_side < 640 or max_side > 5000:
        raise SystemExit("config.json 的 max_image_side 必須介乎 640 至 5000。")
    return config


def image_files(folder: Path) -> list[Path]:
    return sorted(
        p for p in folder.iterdir()
        if p.is_file()
        and p.suffix.lower() in IMAGE_EXTS
        and not p.name.lower().startswith("carousell_")
    )


def safe_name(value: str) -> str:
    return re.sub(r"[<>:\"/\\|?*]", "_", value).strip() or "未命名商品"


def new_batch_product_folder(prefix: str = "批量商品") -> Path:
    """Create a unique inbox folder for one drag-and-drop batch."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = INBOX / safe_name(f"{prefix}_{stamp}")
    folder = base
    counter = 2
    while folder.exists():
        folder = INBOX / f"{base.name}_{counter}"
        counter += 1
    folder.mkdir(parents=True, exist_ok=False)
    return folder


def automatic_upload_group_key(filename: str) -> str | None:
    """Infer a product group from common photo naming patterns.

    Product exports commonly use names such as 01-01_Product_front and
    Product_02.  The shared product number/name is safer than asking the user
    to count images.  Files without a recognizable key stay in one fallback
    group instead of being split into many one-image products.
    """
    stem = Path(filename).stem.strip()
    stem = re.sub(r"\s+", "_", stem)
    numbered = re.match(r"^(\d{1,4})[-_ ]+(?:\d{1,4}[-_ ])?(.+)$", stem)
    if numbered:
        candidate = numbered.group(2)
        candidate = re.sub(
            r"(?:[_ -](?:\d{1,3}|正面|背面|側面|左面|右面|底部|細節|特寫|front|back|side|left|right|detail))+$",
            "",
            candidate,
            flags=re.IGNORECASE,
        ).strip("_ -")
        if len(candidate) >= 2:
            return safe_name(candidate)[:40]
        return f"編號{numbered.group(1)}"
    named = re.sub(
        r"(?:[_ -](?:\d{1,3}|正面|背面|側面|左面|右面|底部|細節|特寫|front|back|side|left|right|detail))+$",
        "",
        stem,
        flags=re.IGNORECASE,
    ).strip("_ -")
    if named != stem and len(named) >= 4:
        return safe_name(named)[:40]
    return None


def image_color_signature(data: bytes) -> tuple[float, ...] | None:
    """Summarize color-block proportions and their coarse spatial layout."""
    try:
        with Image.open(BytesIO(data)) as original:
            image = ImageOps.exif_transpose(original).convert("RGB").resize((24, 24), Image.Resampling.BILINEAR)
    except (OSError, ValueError):
        return None
    pixels = list(image.getdata())
    histogram = [0.0] * 64
    for red, green, blue in pixels:
        index = (red // 64) * 16 + (green // 64) * 4 + (blue // 64)
        histogram[index] += 1.0 / len(pixels)
    grid: list[float] = []
    for row in range(3):
        for column in range(3):
            samples = [
                pixels[y * 24 + x]
                for y in range(row * 8, (row + 1) * 8)
                for x in range(column * 8, (column + 1) * 8)
            ]
            count = float(len(samples))
            grid.extend(sum(pixel[channel] for pixel in samples) / (255.0 * count) for channel in range(3))
    palette_size = sum(1.0 for value in histogram if value >= 0.02) / 64.0
    return tuple(histogram + grid + [palette_size])


def image_color_distance(left: tuple[float, ...] | None, right: tuple[float, ...] | None) -> float:
    """Return a 0..1 distance where lower means similar color blocks."""
    if left is None or right is None:
        return 1.0
    histogram_distance = sum(abs(a - b) for a, b in zip(left[:64], right[:64])) / 2.0
    grid_distance = sum(abs(a - b) for a, b in zip(left[64:91], right[64:91])) / 27.0
    palette_distance = abs(left[91] - right[91])
    return histogram_distance * 0.58 + grid_distance * 0.32 + palette_distance * 0.10


def image_visual_signature(data: bytes) -> dict[str, object] | None:
    """Build a subject-focused signature that is stable across camera angles.

    Product photos normally have a plain background.  We estimate that
    background from the border, crop the foreground object, and retain color
    proportions plus a small grayscale thumbnail.  This avoids letting a
    large white background outweigh the toy itself.
    """
    try:
        with Image.open(BytesIO(data)) as original:
            image = ImageOps.exif_transpose(original).convert("RGB")
            image.thumbnail((128, 128), Image.Resampling.LANCZOS)
            width, height = image.size
            if width < 8 or height < 8:
                return None
            pixels = list(image.getdata())
    except (OSError, ValueError):
        return None

    border: list[tuple[int, int, int]] = []
    for y in range(height):
        for x in range(width):
            if x in (0, width - 1) or y in (0, height - 1):
                border.append(pixels[y * width + x])
    count = max(1, len(border))
    background = tuple(sum(pixel[channel] for pixel in border) / count for channel in range(3))
    background_luma = sum(background) / 3.0
    foreground: list[bool] = []
    for red, green, blue in pixels:
        distance = math.sqrt(sum((value - background[channel]) ** 2 for channel, value in enumerate((red, green, blue))))
        brightness = max(red, green, blue)
        saturation = (max(red, green, blue) - min(red, green, blue)) / 255.0
        # A color change or a dark edge is enough to count as object pixels.
        foreground.append(
            distance > 28.0
            or (background_luma > 225.0 and brightness < 220.0)
            or (background_luma > 225.0 and saturation > 0.18)
        )

    points = [
        (x, y)
        for y in range(height)
        for x in range(width)
        if foreground[y * width + x]
    ]
    # If the background is busy, use the complete image rather than cropping
    # an accidentally tiny region.
    if len(points) < width * height * 0.02 or len(points) > width * height * 0.94:
        left, top, right, bottom = 0, 0, width - 1, height - 1
    else:
        left = min(point[0] for point in points)
        top = min(point[1] for point in points)
        right = max(point[0] for point in points)
        bottom = max(point[1] for point in points)
        padding_x = max(2, int((right - left + 1) * 0.08))
        padding_y = max(2, int((bottom - top + 1) * 0.08))
        left = max(0, left - padding_x)
        top = max(0, top - padding_y)
        right = min(width - 1, right + padding_x)
        bottom = min(height - 1, bottom + padding_y)

    crop_width = right - left + 1
    crop_height = bottom - top + 1
    crop = image.crop((left, top, right + 1, bottom + 1))
    mask_image = Image.new("L", (width, height), 0)
    mask_image.putdata([255 if value else 0 for value in foreground])
    shape_mask = mask_image.crop((left, top, right + 1, bottom + 1)).resize((12, 12), Image.Resampling.BILINEAR)
    color_image = crop.resize((24, 24), Image.Resampling.BILINEAR)
    color_pixels = list(color_image.getdata())
    color_mask = mask_image.crop((left, top, right + 1, bottom + 1)).resize((24, 24), Image.Resampling.BILINEAR)
    mask_pixels = list(color_mask.getdata())
    object_pixels = [pixel for pixel, mask_value in zip(color_pixels, mask_pixels) if mask_value >= 96]
    if len(object_pixels) < 12:
        object_pixels = color_pixels
    color_histogram = [0.0] * 64
    for red, green, blue in object_pixels:
        index = (red // 64) * 16 + (green // 64) * 4 + (blue // 64)
        color_histogram[index] += 1.0 / len(object_pixels)
    accent_pixels = [
        pixel for pixel in object_pixels
        if max(pixel) - min(pixel) >= 24 or max(pixel) <= 205
    ]
    if len(accent_pixels) < 8:
        accent_pixels = object_pixels
    accent_histogram = [0.0] * 64
    for red, green, blue in accent_pixels:
        index = (red // 64) * 16 + (green // 64) * 4 + (blue // 64)
        accent_histogram[index] += 1.0 / len(accent_pixels)
    foreground_grid: list[float] = []
    for row in range(3):
        for column in range(3):
            samples = [
                color_pixels[y * 24 + x]
                for y in range(row * 8, (row + 1) * 8)
                for x in range(column * 8, (column + 1) * 8)
                if mask_pixels[y * 24 + x] >= 96
            ]
            if not samples:
                samples = object_pixels
            count = float(len(samples))
            foreground_grid.extend(sum(pixel[channel] for pixel in samples) / (255.0 * count) for channel in range(3))
    gray = ImageOps.grayscale(crop).resize((12, 12), Image.Resampling.BILINEAR)
    gray_values = tuple(value / 255.0 for value in gray.getdata())
    return {
        "color": tuple(color_histogram),
        "accent": tuple(accent_histogram),
        "grid": tuple(foreground_grid),
        "gray": gray_values,
        "shape": tuple(value / 255.0 for value in shape_mask.getdata()),
        "area": (crop_width * crop_height) / float(width * height),
        "aspect": crop_width / float(max(1, crop_height)),
        "global": image_color_signature(data),
    }


def visual_signature_distance(left: dict[str, object] | None, right: dict[str, object] | None) -> float:
    """Return a 0..1 distance between two subject-focused signatures."""
    if left is None or right is None:
        return 1.0
    left_color = left.get("color")
    right_color = right.get("color")
    if not isinstance(left_color, tuple) or not isinstance(right_color, tuple):
        return 1.0
    foreground_color = sum(abs(a - b) for a, b in zip(left_color, right_color)) / 2.0
    left_accent = left.get("accent")
    right_accent = right.get("accent")
    accent_distance = (
        sum(abs(a - b) for a, b in zip(left_accent, right_accent)) / 2.0
        if isinstance(left_accent, tuple) and isinstance(right_accent, tuple)
        else 1.0
    )
    left_grid = left.get("grid")
    right_grid = right.get("grid")
    grid_distance = (
        sum(abs(a - b) for a, b in zip(left_grid, right_grid)) / 27.0
        if isinstance(left_grid, tuple) and isinstance(right_grid, tuple)
        else 1.0
    )
    left_gray = left.get("gray")
    right_gray = right.get("gray")
    gray_distance = (
        sum(abs(a - b) for a, b in zip(left_gray, right_gray)) / 144.0
        if isinstance(left_gray, tuple) and isinstance(right_gray, tuple)
        else 1.0
    )
    left_shape = left.get("shape")
    right_shape = right.get("shape")
    shape_distance = (
        sum(abs(a - b) for a, b in zip(left_shape, right_shape)) / 144.0
        if isinstance(left_shape, tuple) and isinstance(right_shape, tuple)
        else 1.0
    )
    left_area = max(0.01, float(left.get("area", 1.0)))
    right_area = max(0.01, float(right.get("area", 1.0)))
    area_distance = min(1.0, abs(math.log(left_area / right_area)) / 1.7)
    left_aspect = max(0.2, float(left.get("aspect", 1.0)))
    right_aspect = max(0.2, float(right.get("aspect", 1.0)))
    aspect_distance = min(1.0, abs(math.log(left_aspect / right_aspect)) / 1.5)
    global_distance = image_color_distance(left.get("global"), right.get("global"))
    return (
        foreground_color * 0.45
        + accent_distance * 0.18
        + grid_distance * 0.20
        + gray_distance * 0.10
        + shape_distance * 0.08
        + global_distance * 0.06
        + area_distance * 0.02
        + aspect_distance * 0.01
    )


def visual_signatures_match(left: dict[str, object] | None, right: dict[str, object] | None) -> bool:
    """Use two gates so similarly colored but unrelated products stay apart."""
    if left is None or right is None:
        return False
    distance = visual_signature_distance(left, right)
    left_color = left.get("color")
    right_color = right.get("color")
    if not isinstance(left_color, tuple) or not isinstance(right_color, tuple):
        return False
    foreground_color = sum(abs(a - b) for a, b in zip(left_color, right_color)) / 2.0
    left_accent = left.get("accent")
    right_accent = right.get("accent")
    accent_distance = (
        sum(abs(a - b) for a, b in zip(left_accent, right_accent)) / 2.0
        if isinstance(left_accent, tuple) and isinstance(right_accent, tuple)
        else 1.0
    )
    left_grid = left.get("grid")
    right_grid = right.get("grid")
    grid_distance = (
        sum(abs(a - b) for a, b in zip(left_grid, right_grid)) / 27.0
        if isinstance(left_grid, tuple) and isinstance(right_grid, tuple)
        else 1.0
    )
    left_gray = left.get("gray")
    right_gray = right.get("gray")
    gray_distance = (
        sum(abs(a - b) for a, b in zip(left_gray, right_gray)) / 144.0
        if isinstance(left_gray, tuple) and isinstance(right_gray, tuple)
        else 1.0
    )
    left_shape = left.get("shape")
    right_shape = right.get("shape")
    shape_distance = (
        sum(abs(a - b) for a, b in zip(left_shape, right_shape)) / 144.0
        if isinstance(left_shape, tuple) and isinstance(right_shape, tuple)
        else 1.0
    )
    global_distance = image_color_distance(left.get("global"), right.get("global"))
    # Strong object-color agreement is enough for modest angle changes.  When
    # colors are less distinctive, require matching coarse shape/thumbnail too.
    return (foreground_color <= 0.18 and accent_distance <= 0.22 and grid_distance <= 0.25 and distance <= 0.40) or (
        foreground_color <= 0.30 and accent_distance <= 0.30 and grid_distance <= 0.30 and gray_distance <= 0.30 and distance <= 0.38
    ) or (
        # Front/back views can change the visible colors while keeping the
        # same coarse silhouette and grayscale layout.
        accent_distance <= 0.72 and gray_distance <= 0.11 and shape_distance <= 0.13 and global_distance <= 0.23
    )


def group_uploaded_images(uploaded: list[tuple[str, bytes]]) -> dict[str, list[tuple[str, bytes]]]:
    """Group uploads by filename keys and subject-aware visual components.

    Unnamed images use complete-link grouping so every pair in a product group
    must match. This prevents one bridge image from joining unrelated products.
    """
    grouped: dict[str, list[tuple[str, bytes]]] = {}
    named_groups: dict[str, list[tuple[str, bytes]]] = {}
    unnamed: list[tuple[str, bytes, dict[str, object] | None]] = []
    for filename, data in uploaded:
        filename_key = automatic_upload_group_key(filename)
        if filename_key:
            named_groups.setdefault(filename_key, []).append((filename, data))
        else:
            unnamed.append((filename, data, image_visual_signature(data)))

    grouped.update(named_groups)
    visual_counter = 0
    # Complete-link grouping prevents a chain of merely similar white toys
    # from collapsing into one huge product.  Every new photo must resemble
    # every photo already in the candidate group.
    components: list[list[int]] = []
    for index, (_filename, _data, signature) in enumerate(unnamed):
        for component in components:
            if all(visual_signatures_match(signature, unnamed[other][2]) for other in component):
                component.append(index)
                break
        else:
            components.append([index])
    for component in components:
        visual_counter += 1
        grouped[f"視覺組{visual_counter:02d}"] = [
            (unnamed[index][0], unnamed[index][1]) for index in component
        ]
    return grouped


def product_settings(folder: Path, config: dict) -> dict:
    """Merge optional per-product settings over the global config."""
    settings_path = folder / "商品資料.json"
    if not settings_path.exists():
        return dict(config)
    try:
        overrides = json.loads(settings_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"{settings_path.name} 格式錯誤：第 {exc.lineno} 行。") from exc
    if not isinstance(overrides, dict):
        raise ValueError(f"{settings_path.name} 必須是 JSON 物件。")
    merged = dict(config)
    merged.update(overrides)
    return merged


def normalize_images(folder: Path, title: str, max_images: int, max_image_side: int = 2048) -> list[Path]:
    out = PROCESSED / safe_name(title)
    out.mkdir(parents=True, exist_ok=True)
    result: list[Path] = []
    for number, source in enumerate(image_files(folder)[:max_images], 1):
        target = out / f"{number:02d}_{safe_name(title)}.png"
        try:
            with Image.open(source) as original:
                image = ImageOps.exif_transpose(original).convert("RGB")
                image.thumbnail((max_image_side, max_image_side), Image.Resampling.LANCZOS)
                # Low compression keeps the prepare button responsive; the
                # image is still lossless and Carousell re-encodes uploads.
                image.save(target, format="PNG", optimize=False, compress_level=1)
        except (OSError, ValueError) as exc:
            print(f"[提示] 略過無法讀取的圖片 {source.name}：{exc}")
            continue
        result.append(target)
    return result


def make_draft(folder: Path, config: dict) -> Draft:
    settings = product_settings(folder, config)
    fallback_title = str(config.get("default_title", "新商品")) if folder == INBOX else folder.name
    title = str(settings.get("title", fallback_title)).strip()
    images = normalize_images(
        folder,
        title,
        int(settings.get("max_images", 10)),
        int(settings.get("max_image_side", 2048)),
    )
    if not images:
        raise ValueError(f"{folder} 沒有找到圖片")
    custom_description = settings.get("description")
    description = str(custom_description if custom_description is not None else settings.get("description_template", "{title}")).format(title=title)
    attributes = settings.get("attributes", {})
    if not isinstance(attributes, dict):
        raise ValueError("商品資料.json 的 attributes 必須是 JSON 物件。")
    # These two keys are convenient shortcuts for Carousell custom category
    # fields (for example an iPad's series and storage capacity).
    attributes = {str(key): str(value) for key, value in attributes.items() if value is not None}
    for key in ("series", "storage"):
        if settings.get(key) not in (None, ""):
            attributes[key] = str(settings[key])
    draft = Draft(
        title=title,
        price=str(settings.get("price", settings.get("default_price", ""))),
        condition="Like new",
        category=str(settings.get("category", "")),
        location=str(settings.get("location", "")),
        delivery=str(settings.get("delivery", "")),
        description=description,
        brand=str(settings.get("brand", "")),
        attributes=attributes,
        images=[str(p) for p in images],
        source_folder=str(folder),
    )
    (folder / "draft.json").write_text(json.dumps(asdict(draft), ensure_ascii=False, indent=2), encoding="utf-8")
    return draft


def product_folders(selected: str | None) -> list[Path]:
    INBOX.mkdir(parents=True, exist_ok=True)
    if selected:
        folder = INBOX / selected
        if not folder.is_dir():
            raise SystemExit(f"找不到產品資料夾：{folder}")
        return [folder]
    folders = [p for p in sorted(INBOX.iterdir()) if p.is_dir() and not p.name.startswith("_")]
    repaired_folders: list[Path] = []
    # A previous version could create one-image 商品_視覺組 folders.  Gather
    # all of those legacy folders first so the improved matcher can merge
    # photos of one toy back into a single product before publishing.
    legacy_visual_folders = [folder for folder in folders if folder.name.startswith("商品_視覺組")]
    legacy_entries: list[tuple[str, bytes, Path, str]] = []
    for folder in legacy_visual_folders:
        for source in image_files(folder):
            try:
                legacy_entries.append((f"legacyphoto{len(legacy_entries):06d}.png", source.read_bytes(), folder, source.name))
            except OSError:
                continue
    legacy_grouped = group_uploaded_images([(name, data) for name, data, _folder, _original in legacy_entries]) if legacy_entries else {}
    if legacy_visual_folders and legacy_grouped and (
        len(legacy_grouped) != len(legacy_visual_folders) or any(len(items) > 1 for items in legacy_grouped.values())
    ):
        legacy_lookup = {
            name: (folder, original)
            for name, _data, folder, original in legacy_entries
        }
        for group_key, sources in legacy_grouped.items():
            target = new_batch_product_folder(f"商品_{group_key}")
            for encoded_name, _data in sources:
                source_folder, original_name = legacy_lookup[encoded_name]
                source = source_folder / original_name
                if source.exists():
                    shutil.move(str(source), str(target / original_name))
            repaired_folders.append(target)
        for folder in legacy_visual_folders:
            try:
                folder.rmdir()
            except OSError:
                pass
        folders = [folder for folder in folders if folder not in legacy_visual_folders]
        print(f"[提示] 已重新整理舊版視覺分組商品：{len(legacy_visual_folders)} 個舊資料夾 → {len(legacy_grouped)} 件商品")
    for folder in folders:
        repaired_folders.append(folder)
    folders = repaired_folders
    direct_images = image_files(INBOX)
    if not folders and direct_images:
        print("[提示] 偵測到直接放在「待發布」的圖片，會視為同一個商品。")
        return [INBOX]
    if folders and direct_images:
        # Images uploaded by an older version may still be directly under
        # 待發布. Group them so they are not ignored when other product
        # folders already exist.
        grouped = group_uploaded_images([(source.name, source.read_bytes()) for source in direct_images])
        for group_key, sources in grouped.items():
            batch_folder = new_batch_product_folder(f"商品_{group_key}")
            for filename, _data in sources:
                source = INBOX / filename
                shutil.move(str(source), str(batch_folder / filename))
            print(f"[提示] 已將 {len(sources)} 張散落圖片按檔名和色塊相似度整理成商品：{batch_folder.name}")
            folders.append(batch_folder)
    if not folders:
        raise SystemExit(f"請先把產品圖片放進 {INBOX}\\產品名稱\\")
    return folders


def order_publish_folders(folders: list[Path], prioritize_errors: bool) -> list[Path]:
    """Keep previously failed products for the end of the next publish run."""
    if not prioritize_errors:
        return folders
    error_names = set(load_error_products())
    if not error_names:
        return folders
    normal = [folder for folder in folders if folder.name not in error_names]
    failed = [folder for folder in folders if folder.name in error_names]
    if failed:
        print("[提示] 曾出錯的商品已排到本次發布最後：" + "、".join(folder.name for folder in failed))
    return normal + failed


def first_locator(page, selectors: Iterable[str]):
    for selector in selectors:
        locator = page.locator(selector).first
        try:
            if locator.count() and locator.is_visible(timeout=700):
                return locator
        except Exception:
            continue
    return None


def first_existing_locator(page, selectors: Iterable[str]):
    """Find an element even when the site keeps it visually hidden (file inputs)."""
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            if locator.count():
                return locator
        except Exception:
            continue
    return None


def wait_for_page_condition(page, condition, timeout_ms: int = 3000, poll_ms: int = 120) -> bool:
    """Poll a lightweight page condition and continue as soon as it is ready."""
    deadline = time.monotonic() + max(0.1, timeout_ms / 1000.0)
    while time.monotonic() < deadline:
        try:
            if condition():
                return True
        except Exception:
            pass
        try:
            page.wait_for_timeout(min(poll_ms, max(1, int((deadline - time.monotonic()) * 1000))))
        except Exception:
            break
    try:
        return bool(condition())
    except Exception:
        return False


def fast_page_goto(page, url: str, dom_timeout_ms: int = 5000) -> None:
    """Start processing after navigation commits, with a short DOM grace period."""
    page.goto(url, wait_until="commit", timeout=30000)
    try:
        page.wait_for_load_state("domcontentloaded", timeout=dom_timeout_ms)
    except Exception:
        # Carousell can keep analytics requests open; the form/listing controls
        # are detected separately by the caller and do not need a full load.
        pass


def first_label_locator(page, labels: Iterable[str]):
    for label in labels:
        try:
            locator = page.get_by_label(label, exact=False).first
            if locator.count() and locator.is_visible(timeout=700):
                return locator
        except Exception:
            continue
    return None


def fill_field(page, value: str, selectors: Iterable[str], label: str) -> bool:
    if not value:
        return True
    locator = first_label_locator(page, [label]) or first_locator(page, selectors)
    if locator is None:
        print(f"[提示] 找不到欄位：{label}，請在瀏覽器手動填寫。")
        return False
    try:
        locator.fill(value, timeout=5000)
        return True
    except Exception as exc:
        print(f"[提示] 無法填寫 {label}：{exc}")
        return False


def choose_field(page, value: str, selectors: Iterable[str], label: str) -> bool:
    if not value:
        return True
    locator = first_label_locator(page, [label]) or first_locator(page, selectors)
    if locator is None:
        print(f"[提示] 找不到選項：{label}，請在瀏覽器手動選擇。")
        return False
    try:
        locator.select_option(label=value, timeout=5000)
        return True
    except Exception:
        try:
            locator.click()
            page.get_by_text(value, exact=True).last.click()
            return True
        except Exception as exc:
            print(f"[提示] 無法選擇 {label}：{exc}")
            return False


def choose_category(page, value: str) -> bool:
    """Handle Carousell's custom category picker as well as a native select."""
    if not value:
        return True
    native = first_label_locator(page, ["類別"]) or first_locator(page, ["select[name*=category i]"])
    if native is not None:
        try:
            native.select_option(label=value, timeout=5000)
            return True
        except Exception:
            pass
    trigger = None
    for text in ("搜尋分類",):
        try:
            candidate = page.get_by_text(text, exact=True).last
            if candidate.count() and candidate.is_visible(timeout=700):
                trigger = candidate
                break
        except Exception:
            continue
    if trigger is None:
        print("[提示] 找不到分類選擇器，請在瀏覽器手動選擇類別。")
        return False
    try:
        trigger.click(timeout=5000)
        search = first_label_locator(page, ["搜尋分類", "分類"]) or first_locator(
            page, ["input[placeholder*=搜尋]", "input[placeholder*=分類]"]
        )
        if search:
            search.fill(value, timeout=5000)
        option = page.get_by_text(value, exact=True).last
        option.click(timeout=5000)
        return True
    except Exception as exc:
        print(f"[提示] 無法選擇類別「{value}」：{exc}")
        return False


CONDITION_LABELS = {
    "like new": "幾乎全新",
    "new": "全新",
    "good": "狀況良好",
    "lightly used": "輕度使用",
    "fair": "狀況尚可",
}


def click_text_option(page, value: str, label: str) -> bool:
    """Click a custom button/option, tolerating delayed Carousell rendering."""
    if not value:
        return True
    candidates = [value]
    if label == "商品狀況":
        candidates.insert(0, CONDITION_LABELS.get(value.strip().lower(), value))
    deadline = time.monotonic() + (15 if label == "商品狀況" else 5)
    while time.monotonic() < deadline:
        for candidate in candidates:
            locators = []
            try:
                locators.append(page.get_by_role("button", name=candidate, exact=True).last)
            except Exception:
                pass
            try:
                locators.append(page.get_by_role("option", name=candidate, exact=True).last)
            except Exception:
                pass
            try:
                locators.append(page.get_by_text(candidate, exact=True).last)
            except Exception:
                pass
            for locator in locators:
                try:
                    if locator.count() and locator.is_visible(timeout=300):
                        try:
                            locator.click(timeout=2500)
                        except Exception:
                            # Carousell sometimes renders a clickable pill as
                            # nested text inside a custom React control.
                            locator.evaluate(
                                """el => {
                                    const target = el.closest(
                                        'button,[role="button"],[role="radio"],[role="option"],label'
                                    ) || el;
                                    target.click();
                                }"""
                            )
                        page.wait_for_timeout(350)
                        return True
                except Exception:
                    continue
        try:
            page.wait_for_timeout(400)
        except Exception:
            break
    print(f"[提示] 找不到選項：{label}「{value}」，請在瀏覽器手動選擇。")
    return False


def choose_custom_attribute(page, value: str, label: str) -> bool:
    """Choose Carousell's button or dropdown attribute fields."""
    if not value:
        return True
    if label == "商品狀況":
        return click_text_option(page, value, label)
    if label == "系列":
        return click_text_option(page, value, label)
    if label == "儲存容量":
        # Storage is rendered as a custom dropdown rather than a <select>.
        trigger = first_locator(page, [
            "button:has-text('儲存容量')",
            "[role=button]:has-text('儲存容量')",
            "text=儲存容量",
        ])
        if trigger is None:
            print("[提示] 找不到選項：儲存容量，請在瀏覽器手動選擇。")
            return False
        try:
            trigger.click(timeout=5000)
            page.wait_for_timeout(250)
            # Accommodate both 64GB and 64 GB labels.
            compact = re.sub(r"\s+", "", value).lower()
            for option in page.locator("[role=option], button, [role=menuitem]").all():
                try:
                    text = re.sub(r"\s+", "", option.inner_text()).lower()
                    if text == compact and option.is_visible(timeout=300):
                        option.click(timeout=3000)
                        return True
                except Exception:
                    continue
            return click_text_option(page, value, label)
        except Exception as exc:
            print(f"[提示] 無法選擇 {label}「{value}」：{exc}")
            return False
    return click_text_option(page, value, label)


def apply_product_condition(page, condition: str = "Like new") -> bool:
    """Always choose the requested product condition before publishing."""
    if choose_custom_attribute(page, condition, "商品狀況"):
        return True
    return choose_field(page, condition, ["select[name*=condition i]"], "商品狀況")


def read_first_value(page, selectors: Iterable[str]) -> str:
    for selector in selectors:
        try:
            locator = page.locator(selector).first
            if locator.count():
                value = locator.input_value(timeout=700).strip()
                if value:
                    return value
        except Exception:
            continue
    return ""


def research_product_online(context, draft: Draft, page) -> str:
    """Open a Google Images reference tab and read its visible results."""
    title = read_first_value(page, [
        "input[name='field_title']",
        "input[name*=title i]",
        "input[placeholder*=標題]",
    ]) or draft.title
    query = " ".join(part for part in (title, Path(draft.source_folder).name) if part).strip()
    if not query:
        return ""
    search_page = None
    try:
        search_page = context.new_page()
        # Keep this tab open for the user.  It is intentionally separate from
        # the Carousell form so the user can compare images while filling the
        # missing category field.
        setattr(draft, "_reference_page", search_page)
        image_path = draft.images[0] if draft.images else ""
        search_page.goto("https://images.google.com/", wait_until="domcontentloaded", timeout=15000)
        search_page.wait_for_timeout(700)
        upload = first_existing_locator(search_page, ["input[type=file]"])
        if upload is None:
            camera = first_locator(
                search_page,
                [
                    "button[aria-label*='Search by image' i]",
                    "[role=button][aria-label*='Search by image' i]",
                    "button[aria-label*='以圖片搜尋']",
                    "[role=button][aria-label*='以圖片搜尋']",
                    "button[aria-label*='圖片搜尋']",
                ],
            )
            if camera is not None:
                camera.click(timeout=3000)
                search_page.wait_for_timeout(500)
                upload = first_existing_locator(search_page, ["input[type=file]"])
        if upload is not None and image_path:
            upload.set_input_files(image_path)
            search_page.wait_for_timeout(1800)
            setattr(draft, "_reference_url", search_page.url)
            text = search_page.locator("body").inner_text(timeout=5000)
            print(f"已用圖片開啟 Google 圖片參考頁面：{query}")
            return text

        # Google may change the Lens upload controls.  Keep the tab useful by
        # falling back to a Google Images text search based on the product.
        url = "https://www.google.com/search?tbm=isch&q=" + quote_plus(query)
        search_page.goto(url, wait_until="domcontentloaded", timeout=15000)
        search_page.wait_for_timeout(1200)
        setattr(draft, "_reference_url", url)
        text = search_page.locator("body").inner_text(timeout=5000)
        print(f"已開啟 Google 圖片參考頁面：{query}")
        return text
    except Exception as exc:
        setattr(draft, "_reference_url", getattr(search_page, "url", "") if search_page is not None else "")
        print(f"[提示] Google 圖片參考頁面未完成載入，仍保留分頁供查看：{exc}")
        return ""


def infer_researched_attributes(research_text: str, draft: Draft) -> dict[str, str]:
    """Extract only clear, common attributes from search snippets."""
    text = research_text or ""
    result: dict[str, str] = {}
    title_text = draft.title.casefold()
    storage = re.search(r"\b(16|32|64|128|256|512|1024)\s*(GB|TB)\b", draft.title, re.IGNORECASE)
    if storage is None:
        researched_sizes = re.findall(r"\b(16|32|64|128|256|512|1024)\s*(GB|TB)\b", text, re.IGNORECASE)
        unique_sizes = {(number, unit.upper()) for number, unit in researched_sizes}
        # Use a web result only when one capacity is repeated consistently;
        # search pages otherwise mix several models and capacities.
        if len(unique_sizes) == 1:
            number, unit = next(iter(unique_sizes))
            if text.casefold().count(f"{number}{unit.casefold()}") >= 2:
                storage = re.search(rf"\b{number}\s*{unit}\b", text, re.IGNORECASE)
    if storage:
        result["storage"] = f"{storage.group(1)}{storage.group(2).upper()}"
    combined = f"{draft.title} {text}".casefold()
    if "ipad" in combined:
        # Prefer the actual Carousell-generated title. Search snippets often
        # mention several iPad families and must not override that title.
        for key, label in (("pro", "Pro"), ("air", "Air"), ("mini", "Mini")):
            if re.search(rf"\bipad\s*{key}\b|\b{key}\s*ipad\b", title_text):
                result["series"] = label
                break
        result.setdefault("series", "iPad")
    return result


def research_and_fill_missing_attributes(context, page, draft: Draft, config: dict) -> None:
    """Research only when Carousell left category-specific fields empty."""
    if not bool(config.get("web_research_enabled", True)):
        return
    if draft.research_attempted:
        return
    try:
        body = page.locator("body").inner_text(timeout=2000)
    except Exception:
        body = ""
    needs_research = any(label in body for label in ("儲存容量", "系列", "型號", "品牌", "版本"))
    if not needs_research:
        return
    missing = [key for key in ("series", "storage") if not draft.attributes.get(key)]
    if not missing:
        return
    # Mark the attempt only after the category page is ready and a field is
    # genuinely missing.  This lets a slow Carousell form finish rendering
    # before the first search, while still guaranteeing one search per item.
    draft.research_attempted = True
    print(f"正在為「{draft.title}」進行一次網上資料搜尋（完成後不會重複開分頁）。")
    research_text = research_product_online(context, draft, page)
    inferred = infer_researched_attributes(research_text, draft)
    for key in missing:
        value = inferred.get(key, "")
        if not value:
            continue
        draft.attributes[key] = value
        label = "系列" if key == "series" else "儲存容量"
        choose_custom_attribute(page, value, label)
        print(f"已用網上資料補填{label}：{value}")


def custom_field_selected(page, label: str) -> bool:
    """Check whether a custom dropdown still shows its placeholder label."""
    selectors = [
        f"button:has-text('{label}')",
        f"[role=button]:has-text('{label}')",
    ]
    for selector in selectors:
        try:
            locator = page.locator(selector).last
            if not locator.count() or not locator.is_visible(timeout=500):
                continue
            text = normalized_text(locator.inner_text(timeout=500))
            if text and text != normalized_text(label):
                return True
        except Exception:
            continue
    return False


def page_has_unresolved_validation(page) -> bool:
    try:
        body = page.locator("body").inner_text(timeout=1500)
        if any(marker in body for marker in ("請填完有問題的欄位", "請填寫必填", "請填寫此欄位", "請選擇必填", "此欄位為必填")):
            return True
        return page.locator("[aria-invalid='true'], [data-invalid='true']").count() > 0
    except Exception:
        return False


def page_has_duplicate_warning(page) -> bool:
    """Detect Carousell's post-submit duplicate-listing rejection screen."""
    try:
        body = page.locator("body").inner_text(timeout=1500)
    except Exception:
        return False
    markers = (
        "與你刊登過的商品相似",
        "重複刊登會影響",
        "Repeated listings",
        "similar to items you have listed",
    )
    return any(marker.casefold() in body.casefold() for marker in markers)


def report_status_issue(status: StatusState | None, message: str) -> None:
    print(f"[問題] {message}")
    if status:
        status.add_issue(message)


def detect_carousell_autofill(page) -> tuple[tuple[tuple[str, str], ...], bool, int, bool]:
    """Capture visible form values and loading markers for autofill detection."""
    try:
        body = normalized_text(page.locator("body").inner_text(timeout=1500))
    except Exception:
        body = ""
    loading_terms = (
        "正在分析", "分析中", "辨識中", "辨識圖片", "自動填寫中",
        "正在填寫", "讀取中", "載入中", "generating", "loading",
    )
    loading = any(term in body for term in loading_terms)
    completed = any(term in body for term in ("自動填寫完成", "已完成填寫", "填寫完成"))
    values: list[tuple[str, str]] = []
    try:
        fields = page.locator(
            "input:not([type=file]):not([type=hidden]):not([type=checkbox]):not([type=radio]), "
            "textarea, select, [contenteditable='true']"
        ).evaluate_all(
            """els => els.filter(el => {
                const r = el.getBoundingClientRect();
                return r.width > 0 && r.height > 0;
            }).map((el, index) => {
                let value = el.value;
                if (el.isContentEditable) value = el.innerText;
                return {
                    key: el.name || el.id || el.placeholder || el.getAttribute('aria-label') || `${el.tagName}-${index}`,
                    value: String(value || '').trim().slice(0, 180),
                };
            })"""
        )
        values = [
            (str(field.get("key", "")), str(field.get("value", "")))
            for field in fields
            if str(field.get("value", "")).strip()
        ]
    except Exception:
        values = []
    signature = tuple(sorted(values))
    return signature, loading, len(values), completed


def wait_for_carousell_autofill(page, status: StatusState | None, config: dict) -> bool:
    """Wait for Carousell's image autofill to settle instead of sleeping 10s."""
    timeout_seconds = max(15, int(config.get("carousell_auto_fill_timeout_seconds", 60)))
    started = time.monotonic()
    initial_signature = None
    previous_signature = None
    stable_polls = 0
    saw_values = False
    saw_change = False
    while time.monotonic() - started < timeout_seconds:
        signature, loading, value_count, completed = detect_carousell_autofill(page)
        if initial_signature is None:
            initial_signature = signature
        if signature != initial_signature:
            saw_change = True
        if value_count >= 2:
            saw_values = True
        if signature == previous_signature and not loading:
            stable_polls += 1
        else:
            stable_polls = 0
        previous_signature = signature
        elapsed = int(time.monotonic() - started)
        if status:
            status.update(
                phase="autofill",
                message=f"正在偵測 Carousell 自動填寫… 已讀取 {value_count} 個欄位",
                percent=min(85, 35 + int(45 * min(elapsed / max(timeout_seconds, 1), 1))),
            )
        if not loading and stable_polls >= 2 and (completed or saw_values or saw_change) and elapsed >= 1:
            return True
        # Poll more often without reducing the configured autofill timeout.
        page.wait_for_timeout(250)
    if status:
        status.update(
            phase="autofill",
            message="自動填寫偵測逾時，正在檢查欄位並繼續處理…",
            percent=82,
        )
    return False


def ensure_auto_fields_ready(context, page, draft: Draft, config: dict, status: StatusState | None) -> str:
    """Give the user a timed manual-fill window when Carousell leaves fields blank."""
    review_seconds = max(0, int(config.get("manual_review_seconds", 120)))
    review_started = None
    reference_opened = False
    while True:
        try:
            body = page.locator("body").inner_text(timeout=2000)
        except Exception:
            body = ""
        ipad_category = "儲存容量" in body and "平板電腦" in body
        if ipad_category and not draft.attributes.get("series"):
            draft.attributes["series"] = "iPad"
            choose_custom_attribute(page, "iPad", "系列")
        if not draft.research_attempted and (ipad_category or page_has_unresolved_validation(page)):
            research_and_fill_missing_attributes(context, page, draft, config)
        if ipad_category and not custom_field_selected(page, "儲存容量"):
            if draft.attributes.get("storage"):
                choose_custom_attribute(page, draft.attributes["storage"], "儲存容量")
        storage_ready = not ipad_category or custom_field_selected(page, "儲存容量")
        validation_pending = page_has_unresolved_validation(page)
        if (not ipad_category or storage_ready) and not validation_pending:
            return "ready"

        if not reference_opened and bool(config.get("web_research_enabled", True)):
            # Known fields use the same Google Images tab opened above.  For
            # any other validation problem, open a title/image reference now.
            if not getattr(draft, "_reference_page", None):
                research_product_online(context, draft, page)
            reference_opened = True
            review_started = time.monotonic()
            if status:
                status.update(
                    phase="manual_review",
                    message="Google 圖片參考已開啟，請在 Carousell 補填空白欄位；可等待自動繼續。",
                    percent=87,
                    manual_review_seconds=review_seconds,
                    manual_review_url=getattr(draft, "_reference_url", ""),
                )
            print(f"已開啟 Google 圖片參考，保留 {review_seconds} 秒讓你補填「{draft.title}」。")

        if consume_control("skip_current"):
            message = f"{draft.title}：已按要求跳過，正在處理下一件商品。"
            report_status_issue(status, message)
            if status:
                status.update(phase="skip", message="已跳過目前商品，正在處理下一件。", percent=100, manual_review_seconds=None)
            return "skip"

        if review_started is None:
            # Research was disabled; retain the previous non-interactive
            # behavior and record the issue instead of waiting indefinitely.
            message = "Carousell 仍有空白或有問題的必填欄位。"
            report_status_issue(status, f"{draft.title}：{message}")
            return "failed"

        elapsed = int(time.monotonic() - review_started)
        remaining = max(0, review_seconds - elapsed)
        if remaining <= 0:
            message = f"{draft.title}：{review_seconds} 秒補填時間已到，已跳過並繼續下一件商品。"
            report_status_issue(status, message)
            if status:
                status.update(phase="error", message="補填時間已到，正在處理下一件。", percent=100, manual_review_seconds=None)
            return "failed"
        if status:
            status.update(
                phase="manual_review",
                message=f"請在 Carousell 補填欄位；{remaining} 秒後自動繼續。",
                percent=87,
                manual_review_seconds=remaining,
                manual_review_url=getattr(draft, "_reference_url", ""),
            )
        page.wait_for_timeout(300)
def confirm_disable_buy_dialog(page, timeout_ms: int = 2500) -> bool:
    """Click the warning button as soon as Carousell renders it."""
    # Prefer the accessible button name so unrelated body text cannot be
    # mistaken for the modal action. The CSS fallbacks cover older Carousell
    # markup that does not expose a complete accessible name.
    candidates = [
        page.get_by_role("button", name=re.compile(r"無論如何停用|Disable anyway", re.I)).first,
        page.locator("button").filter(has_text="無論如何停用").first,
        page.locator("[role=button]").filter(has_text="無論如何停用").first,
        page.locator("button:has-text('Disable anyway')").first,
    ]
    for button in candidates:
        try:
            # Playwright's wait is event-driven: it returns at the moment the
            # modal becomes visible instead of sleeping for the full timeout.
            button.wait_for(state="visible", timeout=max(1, timeout_ms))
            button.click(timeout=3000, force=True)
            page.wait_for_timeout(50)
            print("已確認「無論如何停用」。")
            return True
        except Exception:
            continue
    return False


def disable_buy_button(page) -> bool:
    """Turn off Carousell's optional Buy button when it is enabled."""
    for checkbox in page.locator("input[type=checkbox]").all():
        try:
            parent_text = checkbox.evaluate("(e) => e.parentElement.parentElement.innerText")
            if "購買" not in parent_text:
                continue
            if checkbox.is_checked():
                # Carousell re-renders this controlled checkbox, so Playwright's
                # normal uncheck can wait indefinitely. Trigger the native click
                # and then read a fresh checkbox from the page.
                checkbox.evaluate("(e) => e.click()")
                # The modal is part of turning Buy off. Consume it now so the
                # publish path can continue as soon as the setting is closed.
                confirm_disable_buy_dialog(page, timeout_ms=3500)
                fresh = None
                for candidate in page.locator("input[type=checkbox]").all():
                    try:
                        if "購買" in candidate.evaluate("(e) => e.parentElement.parentElement.innerText"):
                            fresh = candidate
                            break
                    except Exception:
                        continue
                if fresh is not None and fresh.is_checked():
                    fresh.locator("xpath=..").click(timeout=3000)
                    confirm_disable_buy_dialog(page, timeout_ms=3500)
                print("已關閉「購買」按鈕。")
            else:
                print("「購買」按鈕已是關閉狀態。")
            return True
        except Exception:
            continue
    print("[提示] 找不到「購買」按鈕開關，請在瀏覽器手動關閉。")
    return False


def normalized_text(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip().casefold()


def page_has_listing_title(page, title: str) -> bool:
    """Check visible account/listing text without matching form input values."""
    wanted = normalized_text(title)
    if not wanted:
        return False
    try:
        body = page.locator("body").inner_text(timeout=2500)
    except Exception:
        return False
    return any(normalized_text(line) == wanted for line in body.splitlines())


def image_hash(image_data: bytes) -> list[bool]:
    """Create a small perceptual hash that survives thumbnail resizing."""
    with Image.open(BytesIO(image_data)) as original:
        image = ImageOps.exif_transpose(original).convert("L")
        image = ImageOps.fit(image, (17, 16), method=Image.Resampling.LANCZOS)
        return [
            image.getpixel((x + 1, y)) > image.getpixel((x, y))
            for y in range(16)
            for x in range(16)
        ]


def image_hash_distance(left: list[bool], right: list[bool]) -> int:
    return sum(a != b for a, b in zip(left, right))


# Carousell thumbnails are resized, but unrelated product photos can still
# share broad light/dark shapes. Keep this threshold conservative so a
# similarity signal never skips a product before the user sees "立即刊登".
DUPLICATE_HASH_DISTANCE = 6


def find_pending_duplicate_folders() -> list[Path]:
    """Find high-confidence duplicate product folders in 待發布."""
    if not INBOX.exists():
        return []
    groups: dict[tuple[str, ...], list[Path]] = {}
    for folder in sorted(INBOX.iterdir(), key=lambda item: item.name.casefold()):
        if not folder.is_dir() or folder.name.startswith("_"):
            continue
        images = image_files(folder)
        if not images:
            continue
        fingerprints: list[str] = []
        for image_path in images:
            try:
                fingerprints.append(hashlib.sha256(image_path.read_bytes()).hexdigest())
            except OSError:
                fingerprints = []
                break
        if fingerprints:
            groups.setdefault(tuple(sorted(fingerprints)), []).append(folder)
    duplicates: list[Path] = []
    for folders in groups.values():
        # Keep the first folder in alphabetical order and move only extras.
        duplicates.extend(folders[1:])
    return duplicates


def draft_source_images(draft: Draft) -> list[Path]:
    """Scan ALL originals, not the normalized/truncated upload image list."""
    folder = Path(draft.source_folder)
    return image_files(folder) if folder.is_dir() else [Path(p) for p in draft.images]


def group_check_key(folder: Path) -> str:
    # Titles are not unique. Include original file revisions so a photo added
    # after preflight cannot inherit another group's clean result.
    revisions = [(p.name, p.stat().st_size, p.stat().st_mtime_ns) for p in image_files(folder)]
    return str(folder.resolve()).casefold() + ':' + hashlib.sha256(
        json.dumps(revisions, ensure_ascii=False).encode('utf-8')
    ).hexdigest()


def checked_account_match(draft: Draft, config: dict) -> dict | None:
    index = config.get("_account_photo_index")
    if not isinstance(index, AccountIndex):
        raise DuplicateScanIncomplete("帳戶重複檢查尚未完成，已保留商品，這次不會發布。")
    match = index.match(draft_source_images(draft))
    if match:
        print(f"找到相同照片：{Path(match['local_image']).name} → {match['listing_url']}；略過整組。")
        config["_last_duplicate_match"] = match
        return match
    if not index.complete:
        raise DuplicateScanIncomplete("帳戶相簿檢查未完成，不能確認沒有重複；已保留商品，這次不會發布。")
    return None


def account_has_existing_listing(context, draft: Draft, sell_url: str, exclude_page=None, reuse_page=None) -> bool:
    """Fresh account check for an uncached gate or post-publish verification.

    Only a complete negative scan returns False. Failed scans raise rather
    than silently authorizing publication. Never inspect random open listings.
    """
    check_page = reuse_page
    owns_page = check_page is None or check_page.is_closed()
    if owns_page:
        check_page = context.new_page()
    try:
        account_page = open_account_listing_page(context, sell_url, page=check_page)
        if account_page is None:
            raise DuplicateScanIncomplete("未能讀取「我的刊登商品」，請先確認登入及網站驗證。")
        index = scan_account(context, account_page, print)
        match = index.match(draft_source_images(draft))
        if match:
            print(f"帳戶已有相同照片 {Path(match['local_image']).name}：{match['listing_url']}")
            return True
        if not index.complete:
            raise DuplicateScanIncomplete("帳戶相簿檢查未完成：" + '; '.join(index.errors[:3]))
        return False
    finally:
        if owns_page:
            try:
                check_page.close()
            except Exception:
                pass


def move_to_completed(folder: Path, title: str) -> Path:
    """Move source product files out of 待發布 after a duplicate is found."""
    COMPLETED.mkdir(parents=True, exist_ok=True)
    base_name = safe_name(title or folder.name)
    destination = COMPLETED / base_name
    counter = 2
    while destination.exists():
        destination = COMPLETED / f"{base_name}_{counter}"
        counter += 1
    if folder == INBOX:
        destination.mkdir(parents=True, exist_ok=True)
        for source in image_files(INBOX):
            shutil.move(str(source), str(destination / source.name))
    else:
        shutil.move(str(folder), str(destination))
    return destination


def move_to_deleted(product_name: str) -> Path:
    """Move one pending product to the recoverable deleted-items folder."""
    if not product_name or Path(product_name).name != product_name:
        raise ValueError("無效的商品名稱")
    source = (INBOX / product_name).resolve()
    if not source.is_relative_to(INBOX.resolve()) or not source.is_dir():
        raise FileNotFoundError(f"找不到未處理商品：{product_name}")
    DELETED.mkdir(parents=True, exist_ok=True)
    destination = DELETED / source.name
    counter = 2
    while destination.exists():
        destination = DELETED / f"{source.name}_{counter}"
        counter += 1
    shutil.move(str(source), str(destination))
    return destination


def resolve_dashboard_folder(bucket: str, product_name: str) -> Path:
    """Resolve a dashboard folder from an allow-listed local root."""
    roots = {"completed": COMPLETED, "unprocessed": INBOX}
    root = roots.get(bucket)
    if root is None or not product_name or Path(product_name).name != product_name:
        raise ValueError("無效的資料夾")
    root = root.resolve()
    target = (root / product_name).resolve()
    if not target.is_relative_to(root) or not target.is_dir():
        raise FileNotFoundError(f"找不到資料夾：{product_name}")
    return target


def open_dashboard_root(bucket: str) -> Path:
    """Open one of the allow-listed parent folders used by the dashboard."""
    roots = {"completed": COMPLETED, "unprocessed": INBOX}
    root = roots.get(bucket)
    if root is None:
        raise ValueError("無效的資料夾")
    root.mkdir(parents=True, exist_ok=True)
    if os.name == "nt":
        os.startfile(str(root))
    else:
        subprocess.Popen(["xdg-open", str(root)])
    return root


def open_dashboard_folder(bucket: str, product_name: str) -> Path:
    target = resolve_dashboard_folder(bucket, product_name)
    if os.name == "nt":
        os.startfile(str(target))
    else:
        subprocess.Popen(["xdg-open", str(target)])
    return target


def publish_succeeded(page, *, duplicate_checked: bool = False) -> bool:
    """Return True only when Carousell left the form or showed a success mark."""
    # Carousell can show generic success-like text on its duplicate warning
    # page. Treat that screen as a failed publish until the user resolves it.
    if not duplicate_checked and page_has_duplicate_warning(page):
        return False
    try:
        body = page.locator("body").inner_text(timeout=3000)
    except Exception:
        body = ""
    if "請填完有問題的欄位" in body or "請填寫必填" in body:
        return False
    # Carousell can show a post-publish satisfaction survey over the sell
    # page. The survey is only rendered after the listing was accepted, even
    # though the URL may remain /sell and the usual success toast is hidden.
    survey_words = (
        "How satisfied are you with your listing experience today?",
        "Tell us how we can improve your experience",
        "告訴我們如何增強您的體驗",
        "告訴我們為什麼",
    )
    if any(word.casefold() in body.casefold() for word in survey_words):
        return True
    success_words = (
        "刊登成功", "成功刊登", "商品已上架", "已成功刊登", "上架成功", "成功上架", "發布成功", "恭喜",
        "Your listing is live", "Your item is live",
        "published", "listing published", "listing created", "successfully",
    )
    if any(word in body for word in success_words):
        return True
    if any(word in body for word in ("新增下一項商品", "再賣一件", "查看商品", "查看刊登")):
        return True
    try:
        toast_text = page.locator(
            "[role=alert], [data-testid*='toast' i], [class*='toast' i], [class*='success' i]"
        ).all_inner_texts()
        if any(
            any(word in normalized_text(text) for word in ("刊登成功", "上架成功", "發布成功", "published", "success"))
            for text in toast_text
        ):
            return True
    except Exception:
        pass
    # A URL change alone is not proof of a successful listing. Carousell can
    # redirect to login, a challenge, or another form page while publishing.
    # Only explicit success text or the account-list verification below may
    # advance to the next product.
    return False


def wait_for_publish_completion(page, status: StatusState | None, config: dict) -> bool:
    """Wait for Carousell's completed-publish page before advancing."""
    timeout_seconds = max(15, int(config.get("publish_result_timeout_seconds", 120)))
    started = time.monotonic()
    while time.monotonic() - started < timeout_seconds:
        if page_has_duplicate_warning(page):
            return False
        if publish_succeeded(page, duplicate_checked=True):
            return True
        if page_has_unresolved_validation(page):
            return False
        elapsed = int(time.monotonic() - started)
        if status:
            status.update(
                phase="publish",
                message=f"已按下「立即刊登」，等待完成頁面… {elapsed}/{timeout_seconds} 秒",
                percent=min(99, 95 + int(4 * elapsed / max(timeout_seconds, 1))),
            )
        page.wait_for_timeout(1000)
    return publish_succeeded(page)


def wait_for_publish_button_ready(page, status: StatusState | None, timeout_seconds: int = 30):
    """Wait until the completed form has a stable, enabled publish button."""
    selectors = [
        "button:has-text('立即刊登')",
        "[role=button]:has-text('立即刊登')",
        "text=立即刊登",
        "button:has-text('Publish')",
        "button:has-text('發布')",
        "[role=button]:has-text('Publish')",
        "[role=button]:has-text('發布')",
    ]
    deadline = time.monotonic() + max(5, timeout_seconds)
    stable_polls = 0
    previous_signature = None
    while time.monotonic() < deadline:
        if confirm_disable_buy_dialog(page, timeout_ms=50):
            page.wait_for_timeout(100)
        if page_has_unresolved_validation(page):
            return None
        try:
            body = normalized_text(page.locator("body").inner_text(timeout=1500))
        except Exception:
            body = ""
        loading = any(
            marker in body
            for marker in ("正在分析", "分析中", "辨識中", "自動填寫中", "正在填寫", "讀取中", "載入中", "loading")
        )
        button = first_locator(page, selectors)
        enabled = False
        if button is not None:
            try:
                enabled = button.is_enabled() and button.get_attribute("aria-disabled") != "true"
            except Exception:
                enabled = False
        signature = (button is not None, enabled, loading, body[-1200:])
        if button is not None and enabled and not loading and signature == previous_signature:
            stable_polls += 1
        else:
            stable_polls = 0
        previous_signature = signature
        elapsed = int(time.monotonic() - (deadline - max(5, timeout_seconds)))
        if status:
            status.update(
                phase="publish",
                message=f"正在等候表單完成後發布… {min(elapsed, timeout_seconds)}/{timeout_seconds} 秒",
                percent=94,
            )
        if stable_polls >= 2:
            page.wait_for_timeout(300)
            if not page_has_unresolved_validation(page):
                return button
            return None
        page.wait_for_timeout(250)
    return None


def verify_published_listing(context, draft: Draft, config: dict, page) -> bool:
    """Confirm a publish that left the form open by checking the account list."""
    sell_url = str(config.get("sell_url", "https://www.carousell.com.hk/sell"))
    for attempt in range(2):
        if account_has_existing_listing(context, draft, sell_url, exclude_page=page, reuse_page=page):
            print(f"發布後回查確認成功：{draft.title}")
            return True
        if attempt == 0:
            try:
                page.wait_for_timeout(1800)
            except Exception:
                pass
    return False


def start_shared_chrome_context(config: dict):
    """Launch one ordinary Chrome context reused by every new-Chrome item."""
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import sync_playwright

    launch_options = {
        "headless": False,
        "no_viewport": True,
        "args": ["--window-size=1280,900"],
    }
    browser_channel = str(config.get("browser_channel", "chrome")).strip().lower()
    if browser_channel:
        launch_options["channel"] = browser_channel
    playwright = sync_playwright().start()
    try:
        context = playwright.chromium.launch_persistent_context(str(BROWSER_DATA), **launch_options)
    except PlaywrightError:
        playwright.stop()
        raise
    return playwright, context


def start_attached_chrome_context(config: dict):
    """Connect to one existing Chrome context for the entire publish batch."""
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import sync_playwright

    cdp_url = str(config.get("cdp_url", "http://127.0.0.1:9222"))
    playwright = sync_playwright().start()
    try:
        browser = playwright.chromium.connect_over_cdp(cdp_url, timeout=10000)
        if not browser.contexts:
            raise RuntimeError("可接管的 Chrome 沒有可用分頁。")
        return playwright, browser.contexts[0]
    except (PlaywrightError, RuntimeError):
        playwright.stop()
        raise


def publish_in_browser(
    draft: Draft,
    config: dict,
    do_publish: bool,
    attach: bool = False,
    status: StatusState | None = None,
    shared_context=None,
    shared_playwright=None,
) -> str:
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise SystemExit("尚未安裝 Playwright，請先執行：py -m pip install -r requirements.txt")

    playwright_scope = nullcontext(shared_playwright) if shared_playwright is not None else sync_playwright()
    with playwright_scope as playwright:
        owns_context = not attach and shared_context is None
        browser = None
        page = None
        if attach:
            if shared_context is not None:
                context = shared_context
                browser = context.browser
            else:
                cdp_url = str(config.get("cdp_url", "http://127.0.0.1:9222"))
                try:
                    browser = playwright.chromium.connect_over_cdp(cdp_url, timeout=10000)
                except PlaywrightError as exc:
                    raise RuntimeError(
                        "找不到可接管的 Chrome。請先按狀態頁的「打開新 Chrome」，再按「接管 Chrome 發布」。"
                    ) from exc
                if not browser.contexts:
                    raise RuntimeError("可接管的 Chrome 沒有可用分頁。")
                context = browser.contexts[0]
            pages = context.pages
            if do_publish or config.get("_manual_preview"):
                shared_page = config.get("_shared_publish_page")
                # In takeover mode, prefer the Carousell tab the user already
                # opened. Only create a tab when there is no usable one.
                if shared_page is None or shared_page.is_closed():
                    candidates = [p for p in pages if "carousell" in p.url.lower()]
                    shared_page = next(
                        (p for p in candidates if "/sell" in p.url.lower()),
                        candidates[-1] if candidates else None,
                    )
                    if shared_page is None:
                        shared_page = context.new_page()
                    config["_shared_publish_page"] = shared_page
                page = shared_page
                page.bring_to_front()
                if status:
                    status.update(
                        phase="check" if do_publish else "prepare",
                        message="正在檢查帳戶的「我的刊登商品」..." if do_publish else "正在開啟商品預覽...",
                        title=draft.title,
                    )
                sell_url = str(config.get("sell_url", "https://www.carousell.com.hk/sell"))
                if do_publish and checked_account_match(draft, config):
                    print(f"偵測到帳戶已有相同照片的商品「{draft.title}」，跳過刊登。")
                    if status:
                        status.update(phase="duplicate", message="發現同款商品，已跳過並整理檔案。", percent=100)
                    return "duplicate"
                # Reuse one Carousell tab for the whole batch. This keeps the
                # user's workflow in one tab and avoids closing/opening tabs
                # between products.
                page.goto(sell_url, wait_until="commit", timeout=30000)
                print(f"已在同一個 Carousell 分頁處理商品：{page.url}")
            else:
                candidates = [p for p in pages if "carousell" in p.url.lower()]
                page = next(
                    (p for p in candidates if p.url.split("?", 1)[0].rstrip("/").endswith("/sell")),
                    candidates[-1] if candidates else (pages[-1] if pages else context.new_page()),
                )
            if page is None:
                raise RuntimeError("接管的 Chrome 找不到可用 Carousell 分頁，請確認已登入並開啟 Carousell。")
            page.bring_to_front()
            if "carousell" not in page.url.lower():
                raise RuntimeError("目前接管的分頁不是 Carousell，請先在該分頁開啟商品頁。")
            print(f"已接管現有 Carousell 分頁：{page.url}")
        elif shared_context is not None:
            context = shared_context
        else:
            launch_options = {
                "headless": False,
                "no_viewport": True,
                "args": ["--window-size=1280,900"],
            }
            browser_channel = str(config.get("browser_channel", "chrome")).strip().lower()
            if browser_channel:
                launch_options["channel"] = browser_channel
            try:
                context = playwright.chromium.launch_persistent_context(str(BROWSER_DATA), **launch_options)
            except PlaywrightError as exc:
                if browser_channel == "chrome":
                    raise RuntimeError("找不到普通 Google Chrome，請先安裝 Chrome，或在 config.json 將 browser_channel 設為空字串。") from exc
                raise
        try:
            if do_publish and not attach:
                if status:
                    status.update(phase="check", message="正在檢查帳戶的「我的刊登商品」...", title=draft.title)
                sell_url = str(config.get("sell_url", "https://www.carousell.com.hk/sell"))
                if checked_account_match(draft, config):
                    print(f"偵測到帳戶已有相同照片的商品「{draft.title}」，跳過刊登。")
                    if status:
                        status.update(phase="duplicate", message="發現同款商品，已跳過並整理檔案。", percent=100)
                    return "duplicate"
            if not attach:
                # Playwright may create an initial blank tab. Close it and create
                # one visible controlled page so it cannot hide behind another Chrome.
                if shared_context is None or not config.get("_shared_initialized"):
                    retained_page = config.get("_shared_publish_page")
                    for old_page in context.pages:
                        if retained_page is None or old_page is not retained_page:
                            old_page.close()
                    if shared_context is not None:
                        config["_shared_initialized"] = True
                shared_page = config.get("_shared_publish_page") if shared_context is not None else None
                if shared_page is not None and not shared_page.is_closed():
                    page = shared_page
                    page.bring_to_front()
                else:
                    page = context.new_page()
                    if shared_context is not None:
                        config["_shared_publish_page"] = page
                page.bring_to_front()
                sell_url = str(config.get("sell_url", "https://www.carousell.com.hk/sell"))
                print(f"正在開啟 Carousell：{sell_url}")
                try:
                    # 'commit' avoids waiting forever for analytics or an ad request.
                    page.goto(sell_url, wait_until="commit", timeout=30000)
                    try:
                        page.wait_for_load_state("domcontentloaded", timeout=15000)
                    except Exception:
                        print("[提示] 網頁仍在載入，但已繼續使用目前頁面。")
                except Exception as exc:
                    current_url = page.url
                    if current_url in ("", "about:blank"):
                        raise RuntimeError(f"Carousell 無法開啟：{exc}") from exc
                    print(f"[提示] 網頁載入逾時，已使用目前頁面：{current_url}")
                print(f"目前頁面：{page.url}")

            # Carousell may show a Cloudflare interstitial to automated browsers.
            # Let the user complete it in the visible browser before continuing.
            try:
                page_title = page.title(timeout=3000).lower()
                body_text = page.locator("body").inner_text(timeout=3000).lower()
            except Exception:
                page_title, body_text = "", ""
            if "just a moment" in page_title or "verify you are human" in body_text or "checking your browser" in body_text:
                print("Carousell 正在進行安全檢查，請在瀏覽器視窗完成驗證。")
                if bool(config.get("_non_interactive")):
                    raise RuntimeError("Carousell 需要安全檢查，請先在瀏覽器完成驗證後再從狀態頁重試。")
                input("完成安全檢查並看到 Carousell 頁面後，按 Enter 繼續：")
                page.bring_to_front()
            # File inputs are often intentionally hidden, so do not require
            # visibility when checking whether the product form is ready.
            file_input = first_existing_locator(page, ["input[type=file]"])
            form_marker = any(
                page.get_by_text(text, exact=True).count() > 0
                for text in ("搜尋分類", "改為手動填寫", "立即刊登", "新增下一項商品")
            )
            if file_input is None and not form_marker:
                print("請在瀏覽器中完成登入，關閉登入彈窗，並看到 Carousell 商品表單。")
                if bool(config.get("_non_interactive")):
                    raise RuntimeError("找不到已登入的 Carousell 商品表單，請先登入後再從狀態頁重試。")
                input("完成後按 Enter 繼續：")
                file_input = first_existing_locator(page, ["input[type=file]"])
                form_marker = any(
                    page.get_by_text(text, exact=True).count() > 0
                    for text in ("搜尋分類", "改為手動填寫", "立即刊登", "新增下一項商品")
                )
            if file_input is None and not form_marker:
                raise RuntimeError("仍找不到 Carousell 商品表單；請確認已登入並開啟出售頁面。")
            if file_input:
                if status:
                    status.update(phase="prepare", message="正在上傳和整理商品圖片...", title=draft.title)
                file_input.set_input_files(draft.images)

            if bool(config.get("carousell_auto_fill", True)):
                # Keep Carousell's generated listing data, then explicitly set
                # the condition because image autofill sometimes leaves it blank.
                print("已上傳圖片，正在偵測 Carousell 自動填寫是否完成。")
                autofill_ready = wait_for_carousell_autofill(page, status, config)
                if not apply_product_condition(page, draft.condition):
                    report_status_issue(status, f"{draft.title}：無法選擇商品狀況「幾乎全新」，已跳過以免空白發布。")
                    return "failed"
                print("Carousell 自動填寫偵測完成。" if autofill_ready else "Carousell 自動填寫未在安全時間內穩定，繼續檢查欄位。")
                research_and_fill_missing_attributes(context, page, draft, config)
                # Carousell often leaves category-specific required fields
                # empty (notably iPad series and storage). Keep its generated
                # title/description, but fill only these known missing values.
                auto_attributes = dict(draft.attributes)
                try:
                    current_body = page.locator("body").inner_text(timeout=2000)
                except Exception:
                    current_body = ""
                ipad_category = "儲存容量" in current_body and "平板電腦" in current_body
                if ipad_category and not auto_attributes.get("series"):
                    auto_attributes["series"] = "iPad"
                    draft.attributes["series"] = "iPad"
                if auto_attributes.get("series"):
                    choose_custom_attribute(page, auto_attributes["series"], "系列")
                if auto_attributes.get("storage"):
                    choose_custom_attribute(page, auto_attributes["storage"], "儲存容量")
                elif ipad_category:
                    print("[提示] Carousell 沒有自動填寫「儲存容量」；請在商品資料.json 填入實際容量。")
                readiness = ensure_auto_fields_ready(context, page, draft, config, status)
                if readiness == "skip":
                    return "skipped"
                if readiness != "ready":
                    return "failed"
            else:
                # Optional legacy mode for accounts that do not expose the
                # image-recognition form.
                try:
                    manual = page.get_by_text("改為手動填寫", exact=True).last
                    if manual.count() and manual.is_visible(timeout=700):
                        manual.click(timeout=3000)
                        page.wait_for_timeout(700)
                except Exception:
                    pass

                choose_category(page, draft.category)
                page.wait_for_timeout(500)
                fill_field(page, draft.title, ["input[name='field_title']", "input[name*=title i]", "input[placeholder*=title i]", "input[placeholder*=標題]"], "標題")
                fill_field(page, draft.price, ["input[name*=price i]", "input[placeholder*=price i]", "input[placeholder*=價格]"], "價格")
                fill_field(page, draft.description, ["textarea[name='field_description']", "textarea[name*=description i]", "textarea[placeholder*=description i]", "textarea[placeholder*=描述]"], "描述")
                if not apply_product_condition(page, draft.condition):
                    report_status_issue(status, f"{draft.title}：無法選擇商品狀況「幾乎全新」，已跳過以免空白發布。")
                    return "failed"
                choose_custom_attribute(page, draft.attributes.get("series", ""), "系列")
                choose_custom_attribute(page, draft.attributes.get("storage", ""), "儲存容量")
                if "平板" in draft.category and not draft.attributes.get("storage", "").strip():
                    print("[提示] 這個平板商品仍未設定「儲存容量」；請在商品資料.json 填入實物容量後才會自動刊登。")
                fill_field(page, draft.location, ["input[name*=location i]", "input[placeholder*=location i]", "input[placeholder*=地點]"], "地點")
                fill_field(page, draft.delivery, ["input[name*=delivery i]", "input[placeholder*=delivery i]", "input[placeholder*=配送]"], "配送方式")
                fill_field(page, draft.brand, ["input[name*=brand i]", "input[placeholder*=brand i]", "input[placeholder*=品牌]"], "品牌")
            if not bool(config.get("enable_buy_button", False)):
                if status:
                    status.update(phase="publish", message="正在確認購買設定，準備發布...", percent=90)
                disable_buy_button(page)

            print(f"已填入草稿：{draft.title}")
            if not do_publish:
                print("目前是預覽模式，未按發布。請檢查瀏覽器頁面。")
                if status and config.get("_manual_preview"):
                    status.update(phase="preview", message="預覽頁已完成自動填寫，未發布。可在 Chrome 內自行檢查。", percent=100)
                    return "preview"
                if not bool(config.get("_non_interactive")):
                    input("檢查完成後按 Enter 關閉瀏覽器：")
                # If the user manually clicked「立即刊登」while inspecting
                # the preview, recognize the success page and move the source
                # folder just like automatic publish mode.
                duplicate_warning = page_has_duplicate_warning(page)
                if duplicate_warning:
                    return "failed_duplicate"
                published = publish_succeeded(page)
                if not published and not page_has_unresolved_validation(page):
                    try:
                        published = verify_published_listing(context, draft, config, page)
                    except Exception as exc:
                        print(f"[提示] 發布後回查未完成：{exc}")
                if published:
                    return "published"
                return "preview"

            wait_seconds = max(0, int(config.get("publish_wait_seconds", 0)))
            if wait_seconds:
                print(f"已完成填寫，等待 {wait_seconds} 秒後再進入發布確認。")
            for remaining in range(wait_seconds, 0, -1):
                print(f"  還剩 {remaining} 秒...", end="\r", flush=True)
                page.wait_for_timeout(1000)
            if wait_seconds:
                print("\n再次確認已關閉「購買」按鈕。")
            else:
                print("完成填寫，直接進入發布流程。")
            disable_buy_button(page)
            # Publishing is intentionally automatic. Keep the legacy config
            # key readable for older installations, but never stop for a
            # final manual confirmation.
            print("已完成填寫，準備自動按下「立即刊登」。")
            # Recheck all original photos against this run's account index,
            # including earlier confirmed publications in the same batch.
            if status:
                status.update(phase="check", message="發布前再次檢查「我的刊登商品」...", percent=93)
            sell_url = str(config.get("sell_url", "https://www.carousell.com.hk/sell"))
            duplicate_before_publish = bool(checked_account_match(draft, config))
            if duplicate_before_publish:
                print(f"發布前檢查發現同款商品，跳過「{draft.title}」。")
                if status:
                    status.update(phase="duplicate", message="發布前發現同款商品，已跳過並整理檔案。", percent=100)
                return "duplicate"
            publish_button = wait_for_publish_button_ready(page, status, timeout_seconds=30)
            if publish_button is None:
                if page_has_unresolved_validation(page):
                    message = "Carousell 仍有必填或驗證問題，已保留商品並繼續處理下一件。"
                else:
                    message = "表單未在 30 秒內穩定完成，已保留商品並繼續處理下一件。"
                print(f"[提示] {message}")
                report_status_issue(status, f"{draft.title}：{message}")
                return "failed"
            while True:
                # A pending Buy confirmation can cover the publish button. Clear
                # it before trying to click, then re-check the form button.
                # The Buy warning was consumed immediately after the checkbox
                # changed. Do a non-blocking final sweep before publishing;
                # the click-retry below handles a prompt rendered at the same
                # instant as the publish action.
                if confirm_disable_buy_dialog(page, timeout_ms=50):
                    publish_button = wait_for_publish_button_ready(page, status, timeout_seconds=10)
                    if publish_button is None:
                        message = "購買按鈕確認視窗已處理，但刊登表單尚未恢復可發布狀態。"
                        report_status_issue(status, f"{draft.title}：{message}")
                        return "failed"
                if status:
                    status.update(phase="publish", message="表單已完成，正在按下「立即刊登」...", percent=95)
                try:
                    publish_button.click(timeout=6000)
                except Exception:
                    # Recover if Carousell rendered the warning between the
                    # pre-click check and Playwright's click action.
                    if not confirm_disable_buy_dialog(page, timeout_ms=3500):
                        raise
                    publish_button = wait_for_publish_button_ready(page, status, timeout_seconds=10)
                    if publish_button is None:
                        return "failed"
                    publish_button.click(timeout=6000)
                # Do not close this tab or advance to the next product until
                # Carousell shows its completed-publish page.
                published = wait_for_publish_completion(page, status, config)
                duplicate_warning = page_has_duplicate_warning(page)
                if duplicate_warning:
                    message = "Carousell 顯示此商品與已刊登商品相似，未確認發布成功；已保留在未處理並標記 error。"
                    print(f"[錯誤] {message}")
                    if status:
                        status.update(phase="error", warning=True, message=message, percent=100)
                    return "failed_duplicate"
                if not published and not duplicate_warning and not page_has_unresolved_validation(page):
                    try:
                        published = verify_published_listing(context, draft, config, page)
                    except Exception as exc:
                        print(f"[提示] 發布結果回查未完成：{exc}")
                if published:
                    print("已成功按下「立即刊登」。")
                    if status:
                        status.update(phase="done", warning=False, message="已確認成功刊登，準備在同一分頁處理下一件。", percent=100)
                    return "published"
                message = "Carousell 顯示必填或驗證問題，已保留目前分頁供檢查，並繼續下一件商品。"
                print(f"[提示] {message}")
                report_status_issue(status, f"{draft.title}：{message}")
                return "failed"
        finally:
            if owns_context:
                try:
                    context.close()
                except Exception:
                    # The user may close the visible browser or press Ctrl+C.
                    pass


def open_account_listing_page(context, sell_url: str, page=None):
    """Open the account listing page once for a batch duplicate scan."""
    check_page = page
    owns_page = False
    try:
        if check_page is None or check_page.is_closed():
            check_page = context.new_page()
            owns_page = True
        management_url = sell_url.split("/sell", 1)[0].rstrip("/") + "/manage-listings/"
        fast_page_goto(check_page, management_url)
        if "/manage-listings" not in check_page.url.lower():
            fast_page_goto(check_page, sell_url)
            account_button = check_page.locator(
                "button[aria-label^='帳戶'],button[aria-label^='账户'],button[aria-label^='Account' i]"
            ).first
            account_button.wait_for(state="visible", timeout=5000)
            account_button.click(timeout=3000)
            manage_link = check_page.get_by_text(
                re.compile(r"^(我的刊登商品|我的刊登|我的商品|My listings|Manage listings)$", re.I)
            ).last
            manage_link.click(timeout=5000)
            check_page.wait_for_url("**/manage-listings**", timeout=10000)
        if "/manage-listings" not in check_page.url.lower():
            print("[提示] 未能開啟「我的刊登商品」清單；未完成檢查的商品不會發布。")
            if owns_page:
                check_page.close()
            return None
        return check_page
    except Exception as exc:
        print(f"[提示] 發布前清單頁未完成載入：{exc}")
        if owns_page and check_page is not None:
            try:
                check_page.close()
            except Exception:
                pass
        return None


def _account_listing_links(page) -> list[tuple[str, str, bool]]:
    """Return product links and each card's Buyer Protection marker."""
    try:
        rows = page.locator("a[href]").evaluate_all(
            """els => els.map(a => {
                const card = a.closest('tr,[role="row"],article,li') || a.parentElement;
                const cardText = (card?.innerText || '').trim();
                return {
                    href: a.href,
                    text: (a.innerText || a.getAttribute('aria-label') || '').trim(),
                    buyerProtection: /buyer\\s*protection|買家保障|買家保護/i.test(cardText)
                };
            })"""
        )
    except Exception:
        return []
    result, seen = [], set()
    for row in rows or []:
        href = str(row.get("href") or "").split("#", 1)[0]
        low = href.lower()
        if "carousell" not in low or any(part in low for part in ("/sell", "/manage-listings", "/settings", "/help")):
            continue
        if not any(part in low for part in ("/p/", "/item/", "/product/", "/listing/")):
            continue
        if href in seen:
            continue
        seen.add(href)
        result.append((
            href,
            str(row.get("text") or "商品").replace("\n", " ").strip()[:120] or "商品",
            bool(row.get("buyerProtection")),
        ))
    return result


def _load_more_account_listings(page, max_clicks: int = 100) -> int:
    """Click Carousell's lazy-list button until the whole listing batch is loaded."""
    selectors = [
        "button:has-text('瀏覽更多')", "[role=button]:has-text('瀏覽更多')", "a:has-text('瀏覽更多')",
        "button:has-text('查看更多')", "[role=button]:has-text('查看更多')", "a:has-text('查看更多')",
        "button:has-text('載入更多')", "[role=button]:has-text('載入更多')", "a:has-text('載入更多')",
        "button:has-text('Load more')", "[role=button]:has-text('Load more')", "a:has-text('Load more')",
        "button:has-text('View more')", "[role=button]:has-text('View more')", "a:has-text('View more')",
    ]
    clicks = 0
    stalled = 0
    for _ in range(max_clicks):
        button = first_locator(page, selectors)
        if button is None:
            break
        try:
            disabled = button.is_disabled() or button.get_attribute("aria-disabled") == "true"
            if disabled:
                break
            before = len(_account_listing_links(page))
            button.scroll_into_view_if_needed(timeout=2000)
            button.click(timeout=5000)
            clicks += 1
            try:
                page.wait_for_function(
                    """before => {
                        const hrefs = Array.from(document.querySelectorAll('a[href]'))
                          .map(a => (a.href || '').split('#')[0].toLowerCase());
                        const products = new Set(hrefs.filter(h =>
                          h.includes('carousell') && !/\\/(sell|manage-listings|settings|help)(\\/|$)/.test(h) &&
                          /\\/(p|item|product|listing)\\//.test(h)
                        ));
                        return products.size > before;
                    }""",
                    arg=before,
                    timeout=1600,
                    polling=100,
                )
            except Exception:
                pass
            after = len(_account_listing_links(page))
            if after <= before:
                stalled += 1
                if stalled >= 2:
                    break
            else:
                stalled = 0
        except Exception:
            break
    if clicks:
        print(f"[提示] 已按「瀏覽更多」載入 {clicks} 次商品清單。")
    return clicks


def _page_has_buyer_protection(page) -> bool:
    """Detect the visible Buyer Protection marker on the individual listing page."""
    try:
        exact = page.get_by_text("Buyer Protection", exact=True)
        if exact.count() and exact.first.is_visible(timeout=700):
            return True
    except Exception:
        pass
    try:
        body = page.locator("body").inner_text(timeout=3000)
    except Exception:
        return False
    return bool(re.search(r"buyer\s*protection|買家保障|買家保護", body or "", flags=re.I))


def _collect_account_listing_links(page, max_pages: int = 50) -> list[tuple[str, str, bool]]:
    """Collect every listing after lazy-loading each page and following pagination."""
    all_links, visited = [], set()
    for _ in range(max_pages):
        signature = page.url
        _load_more_account_listings(page)
        links = _account_listing_links(page)
        for item in links:
            if item[0] not in visited:
                visited.add(item[0])
                all_links.append(item)
        next_button = first_locator(page, [
            "button[aria-label*='下一' i]", "a[aria-label*='下一' i]",
            "button:has-text('下一頁')", "button:has-text('下一页')",
            "a:has-text('下一頁')", "a:has-text('Next')",
        ])
        if next_button is None:
            break
        try:
            disabled = next_button.is_disabled() or next_button.get_attribute("aria-disabled") == "true"
            if disabled:
                break
            before_links = tuple(item[0] for item in links)
            next_button.click(timeout=3000)
            try:
                page.wait_for_function(
                    """before => location.href !== before.url || (() => {
                        const hrefs = Array.from(document.querySelectorAll('a[href]'))
                          .map(a => (a.href || '').split('#')[0]);
                        return hrefs.some(h => !before.links.includes(h));
                    })()""",
                    arg={"url": signature, "links": list(before_links)},
                    timeout=5000,
                    polling=100,
                )
            except Exception:
                pass
            if page.url == signature and not _account_listing_links(page):
                break
        except Exception:
            break
    return all_links


def _confirm_account_dialog(page) -> bool:
    button = first_locator(page, [
        "button:has-text('刪除')", "button:has-text('確認')", "button:has-text('確定')",
        "[role=button]:has-text('刪除')", "[role=button]:has-text('確認')",
    ])
    if button is None:
        return False
    try:
        button.click(timeout=3000)
        page.wait_for_timeout(250)
        return True
    except Exception:
        return False


def _delete_listing_page(page) -> bool:
    selectors = [
        "button:has-text('刪除商品')", "button:has-text('刪除')",
        "[role=button]:has-text('刪除商品')", "[role=button]:has-text('刪除')",
        "button:has-text('Delete')", "[role=button]:has-text('Delete')",
    ]
    wait_for_page_condition(page, lambda: first_locator(page, selectors) is not None, timeout_ms=5000, poll_ms=120)
    button = first_locator(page, selectors)
    if button is None:
        return False
    try:
        button.click(timeout=4000)
        page.wait_for_timeout(180)
        _confirm_account_dialog(page)
        # The listing page is reused; a short settle window is enough because
        # navigation for the next item waits for DOMContentLoaded.
        page.wait_for_timeout(250)
        return True
    except Exception:
        return False


def _buy_control_text(control) -> str:
    try:
        return str(control.evaluate(
            """e => {
                let node = e;
                for (let i = 0; i < 6 && node; i += 1, node = node.parentElement) {
                    const text = (node.innerText || '').trim();
                    // Keep the nearest local label. Including the page container
                    // would make every checkbox match when the page mentions Buy.
                    if (text && text.length <= 320) return text;
                }
                return '';
            }"""
        ) or "")
    except Exception:
        return ""


def _buy_control(page):
    """Find Carousell's purchase switch, including its custom switch variants."""
    selectors = [
        "input[type=checkbox]",
        "[role=switch]",
        "[role=checkbox]",
        "button[aria-pressed]",
        "[data-testid*='buy' i]",
        "[data-testid*='purchase' i]",
    ]
    words = ("購買", "購買按鈕", "允許購買", "下單", "buy", "purchase")
    for selector in selectors:
        try:
            controls = page.locator(selector).all()
        except Exception:
            continue
        for control in controls:
            try:
                marker = " ".join([
                    _buy_control_text(control),
                    str(control.get_attribute("aria-label") or ""),
                    str(control.get_attribute("name") or ""),
                    str(control.get_attribute("id") or ""),
                    str(control.get_attribute("data-testid") or ""),
                ]).casefold()
                if any(word.casefold() in marker for word in words):
                    return control
            except Exception:
                continue
    return None


def _buy_control_state(control):
    """Read a switch state from native and ARIA attributes."""
    try:
        data = control.evaluate(
            """e => ({
                checked: typeof e.checked === 'boolean' ? e.checked : null,
                ariaChecked: e.getAttribute('aria-checked'),
                ariaPressed: e.getAttribute('aria-pressed'),
                dataState: e.getAttribute('data-state'),
                className: String(e.className || '')
            })"""
        ) or {}
    except Exception:
        return None
    if data.get("checked") is not None:
        return bool(data["checked"])
    for key in ("ariaChecked", "ariaPressed"):
        value = str(data.get(key) or "").casefold()
        if value in {"true", "1", "on", "checked", "enabled"}:
            return True
        if value in {"false", "0", "off", "unchecked", "disabled"}:
            return False
    state = str(data.get("dataState") or "").casefold()
    if state in {"on", "checked", "active", "enabled", "true"}:
        return True
    if state in {"off", "unchecked", "inactive", "disabled", "false"}:
        return False
    classes = str(data.get("className") or "").casefold()
    if re.search(r"(^|[-_ ])(checked|active|enabled|on)([-_ ]|$)", classes):
        return True
    if re.search(r"(^|[-_ ])(unchecked|inactive|disabled|off)([-_ ]|$)", classes):
        return False
    return None


def _open_listing_edit_page(page) -> bool:
    """Open the Carousell product editor from a public listing page."""
    if "/sell/" in str(page.url).casefold() or "/edit" in str(page.url).casefold():
        return True
    edit_selectors = [
        "a[href*='/edit']", "button:has-text('編輯商品')", "button:has-text('編輯')",
        "[role=button]:has-text('編輯商品')", "[role=button]:has-text('編輯')",
        "a:has-text('編輯商品')", "a:has-text('編輯')",
        "button:has-text('Edit listing')", "button:has-text('Edit')",
        "[role=button]:has-text('Edit listing')", "[role=button]:has-text('Edit')",
        "a:has-text('Edit listing')", "a:has-text('Edit')",
    ]
    menu_selectors = [
        "button[aria-label*='更多' i]", "button[aria-label*='more' i]",
        "[role=button][aria-label*='更多' i]", "[role=button][aria-label*='more' i]",
        "button:has-text('⋯')", "button:has-text('...')",
    ]
    wait_for_page_condition(
        page,
        lambda: first_locator(page, edit_selectors) is not None,
        timeout_ms=4000,
        poll_ms=120,
    )
    for attempt in range(2):
        edit = first_locator(page, edit_selectors)
        if edit is not None:
            try:
                href = edit.get_attribute("href")
                if href and "/edit" in href.casefold():
                    fast_page_goto(page, href)
                else:
                    try:
                        edit.click(timeout=4000)
                    except Exception:
                        # Carousell's nested label can intercept pointer events.
                        edit.evaluate("e => e.click()")
                wait_for_page_condition(
                    page,
                    lambda: "/sell/" in str(page.url).casefold() or "/edit" in str(page.url).casefold(),
                    timeout_ms=5000,
                    poll_ms=100,
                )
                return "/sell/" in str(page.url).casefold() or "/edit" in str(page.url).casefold()
            except Exception:
                pass
        if attempt == 0:
            menu = first_locator(page, menu_selectors)
            if menu is not None:
                try:
                    menu.click(timeout=3000)
                    page.wait_for_timeout(150)
                except Exception:
                    pass
    try:
        href = page.locator("a[href*='/edit']").first.get_attribute("href")
        if href:
            fast_page_goto(page, href)
            wait_for_page_condition(
                page,
                lambda: "/sell/" in str(page.url).casefold() or "/edit" in str(page.url).casefold(),
                timeout_ms=5000,
                poll_ms=100,
            )
            return "/sell/" in str(page.url).casefold() or "/edit" in str(page.url).casefold()
    except Exception:
        pass
    return False


def _unlock_listing_edit_page(page) -> bool:
    """Click the secondary edit control that unlocks delivery and Buy settings."""
    if _buy_control(page) is not None:
        return True
    button = first_locator(page, [
        "button:has-text('編輯此列表')", "[role=button]:has-text('編輯此列表')",
        "button:has-text('Edit this listing')", "[role=button]:has-text('Edit this listing')",
        "button:has-text('Edit listing')", "[role=button]:has-text('Edit listing')",
    ])
    if button is None:
        return False
    try:
        try:
            button.click(timeout=4000)
        except Exception:
            button.evaluate("e => e.click()")
        return wait_for_page_condition(page, lambda: _buy_control(page) is not None, timeout_ms=4000, poll_ms=100)
    except Exception:
        return False


def _save_listing_edit(page) -> bool:
    save = first_locator(page, [
        "button:has-text('儲存')", "button:has-text('更新')", "button:has-text('完成')",
        "button:has-text('儲存商品')", "button:has-text('更新商品')",
        "button:has-text('Save')", "button:has-text('Update')", "button:has-text('Done')",
        "[role=button]:has-text('儲存')", "[role=button]:has-text('更新')",
        "[role=button]:has-text('Save')", "[role=button]:has-text('Update')",
    ])
    if save is None:
        return False
    try:
        try:
            save.click(timeout=5000)
        except Exception:
            save.evaluate("e => e.click()")
        # Keep a short persistence buffer after Carousell accepts the update.
        page.wait_for_timeout(600)
        return True
    except Exception:
        return False


def _set_buy_button(page, enabled: bool) -> dict:
    """Set and verify one listing's purchase control on its edit form."""
    control = _buy_control(page)
    if control is None:
        if not _open_listing_edit_page(page):
            return {"ok": False, "changed": False, "reason": "找不到商品編輯頁或購買按鈕"}
        if not _unlock_listing_edit_page(page):
            return {"ok": False, "changed": False, "reason": "找不到「編輯此列表」或購買按鈕"}
        control = _buy_control(page)
    if control is None:
        return {"ok": False, "changed": False, "reason": "編輯頁沒有購買按鈕"}
    current = _buy_control_state(control)
    if current is None:
        return {"ok": False, "changed": False, "reason": "無法讀取購買按鈕狀態"}
    if current == enabled:
        return {"ok": True, "changed": False, "already": True}
    try:
        control.evaluate("e => e.click()")
        wait_for_page_condition(
            page,
            lambda: (_buy_control_state(_buy_control(page)) == enabled),
            timeout_ms=2500,
            poll_ms=100,
        )
        if not enabled:
            confirm_disable_buy_dialog(page)
        fresh = _buy_control(page)
        verified = _buy_control_state(fresh) if fresh is not None else None
        if verified != enabled and fresh is not None:
            # Some Carousell forms attach React handlers to the label wrapper,
            # so a native click on the hidden input can be ignored once.
            try:
                fresh.locator("xpath=..").click(timeout=3000)
                wait_for_page_condition(
                    page,
                    lambda: (_buy_control_state(_buy_control(page)) == enabled),
                    timeout_ms=2500,
                    poll_ms=100,
                )
                if not enabled:
                    confirm_disable_buy_dialog(page)
            except Exception:
                pass
        saved = _save_listing_edit(page)
        fresh = _buy_control(page)
        verified = _buy_control_state(fresh) if fresh is not None else None
        if verified is not None and verified != enabled:
            return {"ok": False, "changed": False, "reason": "購買按鈕狀態未更新"}
        if not saved and verified is None:
            return {"ok": False, "changed": False, "reason": "找不到保存按鈕，無法確認更新"}
        return {"ok": True, "changed": True}
    except Exception as exc:
        return {"ok": False, "changed": False, "reason": str(exc)[:160]}


def _connect_account_for_action(config: dict):
    try:
        from playwright.sync_api import Error as PlaywrightError
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("尚未安裝 Playwright，請先按「一鍵安裝環境」。") from exc
    playwright = sync_playwright().start()
    try:
        browser = playwright.chromium.connect_over_cdp(str(config.get("cdp_url", "http://127.0.0.1:9222")), timeout=10000)
        if not browser.contexts:
            raise RuntimeError("可接管的 Chrome 沒有可用分頁。")
        return playwright, browser.contexts[0]
    except PlaywrightError as exc:
        playwright.stop()
        raise RuntimeError("找不到可接管的 Chrome。請先按「打開新 Chrome」並登入 Carousell。") from exc


def _account_action_pages(context, listing_page, links):
    pages = [listing_page]
    for _ in range(min(4, max(0, len(links) - 1))):
        try:
            pages.append(context.new_page())
        except Exception:
            break
    return pages


def delete_all_account_listings(config: dict, status: StatusState | None) -> tuple[bool, str]:
    """Delete every account listing, using a detected bulk control when available."""
    playwright, context = _connect_account_for_action(config)
    extra_pages = []
    try:
        candidates = [p for p in context.pages if "carousell" in p.url.lower()]
        base = next((p for p in candidates if "/manage-listings" in p.url.lower()), candidates[0] if candidates else context.new_page())
        listing_page = open_account_listing_page(context, str(config.get("sell_url", "https://www.carousell.com.hk/sell")), page=base)
        if listing_page is None:
            return False, "找不到「我的刊登商品」頁面，請先登入 Carousell。"
        listing_page.bring_to_front()
        listing_url = listing_page.url
        body = normalized_text(listing_page.locator("body").inner_text(timeout=5000))
        bulk_markers = ("批量刪除", "批量管理", "bulk delete", "bulk actions")
        if any(marker in body for marker in bulk_markers):
            select_all = first_locator(listing_page, ["input[type=checkbox]", "button:has-text('全選')", "button:has-text('全部選取')"])
            bulk_delete = first_locator(listing_page, ["button:has-text('批量刪除')", "button:has-text('刪除選取')", "button:has-text('Bulk delete')"])
            if select_all is not None and bulk_delete is not None:
                try:
                    select_all.click(timeout=3000)
                    bulk_delete.click(timeout=3000)
                    _confirm_account_dialog(listing_page)
                    listing_page.wait_for_timeout(350)
                    return True, "已使用 Carousell 批量刪除功能完成刪除。"
                except Exception:
                    pass
        links = _collect_account_listing_links(listing_page)
        if not links:
            return True, "「我的刊登商品」目前沒有可刪除的商品。"
        pages = _account_action_pages(context, listing_page, links)
        extra_pages = pages[1:]
        deleted = 0
        for index, (url, title, _has_buyer_protection) in enumerate(links, 1):
            page = pages[(index - 1) % len(pages)]
            try:
                fast_page_goto(page, url)
                if _delete_listing_page(page):
                    deleted += 1
                if status:
                    status.update(phase="account_action", title=title, current=index, total=len(links), percent=int(index * 100 / len(links)), message=f"正在刪除已刊登商品（{index}/{len(links)}）...")
            except Exception as exc:
                print(f"[提示] 刪除商品失敗 {title}: {exc}")
        try:
            fast_page_goto(listing_page, listing_url)
        except Exception:
            pass
        listing_page.bring_to_front()
        return deleted == len(links), f"已處理 {len(links)} 件已刊登商品，成功刪除 {deleted} 件。"
    finally:
        for page in extra_pages:
            try:
                page.close()
            except Exception:
                pass
        try:
            playwright.stop()
        except Exception:
            pass


def set_all_account_buy_buttons(config: dict, status: StatusState | None, enabled: bool) -> tuple[bool, str]:
    """Set every listing purchase control to the requested state idempotently."""
    playwright, context = _connect_account_for_action(config)
    extra_pages = []
    try:
        candidates = [p for p in context.pages if "carousell" in p.url.lower()]
        base = next((p for p in candidates if "/manage-listings" in p.url.lower()), candidates[0] if candidates else context.new_page())
        listing_page = open_account_listing_page(context, str(config.get("sell_url", "https://www.carousell.com.hk/sell")), page=base)
        if listing_page is None:
            return False, "找不到「我的刊登商品」頁面，請先登入 Carousell。"
        listing_url = listing_page.url
        links = _collect_account_listing_links(listing_page)
        if not links:
            return True, "「我的刊登商品」目前沒有可切換的商品。"
        pages = _account_action_pages(context, listing_page, links)
        extra_pages = pages[1:]
        changed = 0
        already = 0
        skipped = 0
        failed = 0
        for index, (url, title, listed_buyer_protection) in enumerate(links, 1):
            page = pages[(index - 1) % len(pages)]
            try:
                fast_page_goto(page, url)
                has_buyer_protection = listed_buyer_protection or _page_has_buyer_protection(page)
                should_process = has_buyer_protection if not enabled else not has_buyer_protection
                if not should_process:
                    skipped += 1
                    if status:
                        action_label = "關閉" if not enabled else "開啟"
                        marker_label = "有 Buyer Protection" if has_buyer_protection else "沒有 Buyer Protection"
                        status.update(
                            phase="account_action", title=title, current=index, total=len(links),
                            percent=int(index * 100 / len(links)),
                            message=f"已略過：{marker_label}，不需要{action_label}購買按鈕（{index}/{len(links)}）...",
                        )
                    continue
                result = _set_buy_button(page, enabled)
                if result.get("changed"):
                    changed += 1
                elif result.get("already"):
                    already += 1
                else:
                    failed += 1
                    print(f"[提示] {title}：{result.get('reason', '購買按鈕未更新')}")
                if status:
                    verb = "開啟" if enabled else "關閉"
                    status.update(
                        phase="account_action", title=title, current=index, total=len(links),
                        percent=int(index * 100 / len(links)),
                        message=f"正在{verb}購買按鈕（{index}/{len(links)}）... 已修改 {changed} 件，略過 {skipped} 件，失敗 {failed} 件。",
                    )
            except Exception as exc:
                print(f"[提示] 切換購買按鈕失敗 {title}: {exc}")
                failed += 1
        try:
            fast_page_goto(listing_page, listing_url)
        except Exception:
            pass
        listing_page.bring_to_front()
        label = "開啟" if enabled else "關閉"
        state_label = "已開啟" if enabled else "已關閉"
        marker_rule = "有 Buyer Protection" if not enabled else "沒有 Buyer Protection"
        return failed == 0, f"已檢查 {len(links)} 件商品，只處理{marker_rule}的商品；成功{label}購買按鈕 {changed} 件，原本{state_label} {already} 件，略過 {skipped} 件，失敗 {failed} 件。"
    finally:
        for page in extra_pages:
            try:
                page.close()
            except Exception:
                pass
        try:
            playwright.stop()
        except Exception:
            pass


def preflight_all_duplicates(
    folders: list[Path],
    config: dict,
    status: StatusState | None,
    attach: bool,
    shared_context=None,
    shared_playwright=None,
    destination_bucket: str = "completed",
) -> list[dict]:
    """Account-wide gallery scan, then ANY-original-photo checks per group."""
    context = shared_context
    owned_playwright = None
    found = []
    checked_groups = []
    scan = {"complete": False, "listings": 0, "photos": 0, "errors": []}
    config["_duplicate_scan"] = scan
    config["_preflight_checked_groups"] = checked_groups
    # Never let an earlier successful scan authorize a failed refresh.
    config.pop("_account_photo_index", None)
    if not folders:
        scan["complete"] = True
        return found

    def progress(message):
        print(message)
        if status:
            status.update(phase="check", message=message, percent=0)

    try:
        if context is None:
            owned_playwright, context = start_attached_chrome_context(config)
        listing_page = config.get("_shared_publish_page")
        if listing_page is None or listing_page.is_closed():
            candidates = [p for p in context.pages if "carousell" in p.url.lower()]
            listing_page = next((p for p in candidates if "/manage-listings" in p.url.lower()),
                                candidates[-1] if candidates else context.new_page())
            config["_shared_publish_page"] = listing_page
        progress("正在讀取帳戶全部刊登及商品相簿，不只檢查封面…")
        account_page = open_account_listing_page(
            context, str(config.get("sell_url", "https://www.carousell.com.hk/sell")), page=listing_page
        )
        if account_page is None:
            raise DuplicateScanIncomplete("未能進入「我的刊登商品」，請確認已登入 Carousell。")
        index = scan_account(context, account_page, progress)
        config["_account_photo_index"] = index
        scan.update(index.summary())
        image_count = 0
        for number, folder in enumerate(folders, 1):
            if not folder.is_dir():
                continue
            try:
                paths = image_files(folder)
                if not paths:
                    continue
                settings = product_settings(folder, config)
                title = str(settings.get("title", folder.name)).strip()
                if status:
                    status.update(phase="check", title=title, current=number, total=len(folders),
                                  percent=int(number * 100 / max(1, len(folders))),
                                  message=f"逐張比對原圖 {number}/{len(folders)} 組；帳戶 {len(index.listings)} 件／{len(index.records)} 張照片…")
                evidence = index.match(paths)
                image_count += len(paths)
                if index.complete:
                    checked_groups.append(group_check_key(folder))
                if evidence:
                    destination = move_to_deleted(folder.name) if destination_bucket == "deleted" else move_to_completed(folder, title)
                    clear_product_error(folder)
                    found.append({"folder": str(folder), "title": title,
                                  "moved_to": str(destination), "images": len(paths), "match": evidence})
                    print(f"相同照片 {Path(evidence['local_image']).name} → {evidence['listing_url']}；略過整組 {title}，已移到 {destination.parent.name}。")
            except Exception as exc:
                scan["errors"].append(f"{folder.name}: {exc}")
                print(f"[提示] {folder.name} 檢查未完成，保留原檔且不會發布：{exc}")
        scan.update(groups_checked=len(checked_groups), local_photos=image_count, duplicates=found)
        scan["complete"] = index.complete and not scan["errors"]
        return found
    except Exception as exc:
        scan["errors"].append(str(exc))
        print(f"[提示] 帳戶重複檢查未完成：{exc}")
        return found
    finally:
        # Persist failures as well; never leave a stale successful report
        # behind when today's account connection/gallery scan failed.
        try:
            (ROOT / "last_duplicate_check.json").write_text(
                json.dumps({"checked_at": datetime.now().astimezone().isoformat(timespec="seconds"), **scan},
                           ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except OSError as exc:
            print(f"[提示] 無法儲存重複檢查報告：{exc}")
        if owned_playwright is not None:
            owned_playwright.stop()  # Disconnect only; keep the user's Chrome.


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", str(value or ""))
    return tuple(int(part) for part in parts[:3]) if parts else (0,)


def collect_environment_report() -> dict:
    """Return a dashboard-friendly report of every required local dependency."""
    items: list[dict[str, str | bool]] = []

    def add(label: str, ok: bool, detail: str, required: str = "") -> None:
        items.append({
            "label": label,
            "status": "ok" if ok else "missing",
            "ok": bool(ok),
            "detail": detail,
            "required": required,
        })

    py_version = ".".join(str(part) for part in sys.version_info[:3])
    py_ok = sys.version_info[:2] >= (3, 13)
    add("Python", py_ok, f"目前版本：Python {py_version}", "需要 Python 3.13 或以上")

    try:
        config = load_config()
        config_ok = bool(config)
        add("設定檔 config.json", config_ok, "設定檔已讀取" if config_ok else "設定檔是空的或無法使用", "需要可讀取的 config.json")
    except Exception as exc:
        add("設定檔 config.json", False, f"讀取失敗：{exc}", "需要可讀取的 config.json")

    try:
        import PIL
        pillow_version = getattr(PIL, "__version__", "未知")
        add("Pillow", _version_tuple(pillow_version) >= (10, 0), f"目前版本：Pillow {pillow_version}", "需要 Pillow 10.0 或以上")
    except Exception as exc:
        add("Pillow", False, f"未安裝（{exc}）", "需要 Pillow 10.0 或以上")

    try:
        from importlib import metadata as importlib_metadata
        from playwright.sync_api import sync_playwright
        playwright_version = importlib_metadata.version("playwright")
        package_ok = _version_tuple(playwright_version) >= (1, 45)
        with sync_playwright() as playwright:
            executable = Path(playwright.chromium.executable_path)
        browser_ok = executable.is_file()
        if package_ok and browser_ok:
            detail = f"Playwright {playwright_version}，Chromium 已安裝"
            add("Playwright + Chromium", True, detail, "需要 Playwright 1.45+ 與 Chromium")
        elif not package_ok:
            add("Playwright + Chromium", False, f"Playwright {playwright_version} 版本過舊", "需要 Playwright 1.45+ 與 Chromium")
        else:
            add("Playwright + Chromium", False, f"Playwright {playwright_version}，找不到 Chromium 元件", "需要 Playwright 1.45+ 與 Chromium")
    except Exception as exc:
        add("Playwright + Chromium", False, f"未完整安裝：{exc}", "需要 Playwright 1.45+ 與 Chromium")

    chrome = find_chrome_executable()
    add("Google Chrome", chrome is not None, f"已找到：{chrome}" if chrome else "找不到 chrome.exe", "需要電腦已安裝普通 Google Chrome")

    missing_count = sum(1 for item in items if not item["ok"])
    return {
        "ok": missing_count == 0,
        "missing_count": missing_count,
        "items": items,
        "checked_at": datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S"),
    }


def run_diagnostics() -> int:
    """Check local setup without opening a browser or transmitting any data."""
    report = collect_environment_report()
    print("Carousell 上架工具環境檢查")
    print(f"程式資料夾：{ROOT}")
    for item in report["items"]:
        prefix = "[正常]" if item["ok"] else "[錯誤]"
        print(f"{prefix} {item['label']}：{item['detail']}")

    direct_images = image_files(INBOX) if INBOX.exists() else []
    folders = [p for p in sorted(INBOX.iterdir()) if p.is_dir() and not p.name.startswith("_")] if INBOX.exists() else []
    if folders:
        print(f"[正常] 找到 {len(folders)} 個產品資料夾")
        for folder in folders:
            count = len(image_files(folder))
            if count:
                print(f"       {folder.name}：{count} 張圖片")
            else:
                print(f"[提示] {folder.name} 沒有圖片")
    elif direct_images:
        print(f"[正常] 找到 {len(direct_images)} 張直接放在待發布的圖片（會視為一個商品）")
    else:
        print(f"[提示] 尚未找到產品資料夾，請把圖片放入 {INBOX}\\產品名稱\\")
    if report["missing_count"]:
        print(f"檢查完成：{report['missing_count']} 項需要處理。")
        return 1
    print("檢查完成：環境可以使用。")
    return 0


def run_setup() -> int:
    """Install the Python packages and Playwright browser used by the tool."""
    state = StatusState(0)
    try:
        report = collect_environment_report()
    except Exception:
        report = {"missing_count": 2, "items": []}
    missing_labels = {
        str(item.get("label"))
        for item in report.get("items", [])
        if not item.get("ok")
    }
    commands = []
    if missing_labels.intersection({"Pillow", "Playwright + Chromium"}) or not report.get("items"):
        commands.append(
            ([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")], "正在下載 Python 套件...")
        )
    if "Playwright + Chromium" in missing_labels or not report.get("items"):
        commands.append(([sys.executable, "-m", "playwright", "install", "chromium"], "正在下載瀏覽器元件..."))
    if not commands and not report.get("missing_count"):
        state.update(phase="done", percent=100, warning=False, message="環境已完整，不需要重複安裝。")
        return 0
    if not commands:
        state.update(phase="error", percent=0, warning=True, message="目前 Python 版本不足，請按手動下載網址安裝 Python 3.13+。")
        return 1
    for command, message in commands:
        state.update(phase="prepare", message=message, warning=False)
        try:
            result = subprocess.run(command, cwd=str(ROOT), capture_output=True, text=True)
        except OSError as exc:
            state.update(phase="error", warning=True, message=f"環境安裝失敗：{exc}")
            return 1
        if result.returncode != 0:
            state.update(phase="error", warning=True, message="環境安裝失敗，請查看手動下載網址。")
            return result.returncode or 1
    state.update(phase="done", percent=100, warning=False, message="環境安裝完成，可以開始使用。")
    return 0


def run_account_action(action: str) -> int:
    """Run a long account operation in its own stoppable worker process."""
    state = StatusState(0)
    try:
        config = load_config()
        if action == "delete_duplicates":
            folders = [
                folder for folder in sorted(INBOX.iterdir(), key=lambda item: item.name.casefold())
                if folder.is_dir() and not folder.name.startswith("_")
            ] if INBOX.exists() else []
            if not folders:
                message = "未處理資料夾目前沒有商品可檢查。"
                state.update(phase="done", title="檢查完成", percent=100, message=message)
                return 0
            state.update(
                phase="check",
                title="檢查賬戶刊登商品",
                current=0,
                total=len(folders),
                percent=0,
                message="正在檢查 Carousell 賬戶的「我的刊登商品」...",
                completion_summary=None,
                allow_completion=False,
            )
            found = preflight_all_duplicates(
                folders,
                config,
                state,
                attach=True,
                destination_bucket="completed",
            )
            scan = config.get("_duplicate_scan", {})
            checked = len(config.get("_preflight_checked_groups", []))
            counts = f"帳戶 {scan.get('listings', 0)} 件商品／{scan.get('photos', 0)} 張照片，未處理 {checked} 組"
            if not scan.get("complete"):
                ok = False
                message = f"檢查未完成（{counts}）。已確認重複 {len(found)} 組；其餘保留且不會發布。" + '; '.join(scan.get('errors', [])[:2])
            elif found:
                names = "、".join(item["title"] for item in found)
                ok, message = True, f"已檢查 {counts}；任意一張相同就略過整組，已移到已完成檔案 {len(found)} 組：{names}"
            else:
                ok, message = True, f"已檢查 {counts}；全部原始照片沒有找到帳戶已刊登的相同圖片。"
            state.update(
                phase="done" if ok else "error",
                title="檢查完成",
                current=len(folders),
                total=len(folders),
                percent=100 if ok else int(state.snapshot().get("percent") or 0),
                warning=not ok,
                message=message,
                completion_summary=None,
                allow_completion=False,
            )
            return 0 if ok else 1

        if action == "delete_all_listings":
            ok, message = delete_all_account_listings(config, state)
        elif action in {"enable_all_buy_buttons", "disable_all_buy_buttons"}:
            ok, message = set_all_account_buy_buttons(
                config,
                state,
                action == "enable_all_buy_buttons",
            )
        else:
            state.update(phase="error", warning=True, message="不認識的帳戶操作。")
            return 2
        progress = state.snapshot()
        total = int(progress.get("total") or 0)
        state.update(
            phase="done" if ok else "error",
            title="帳戶商品操作",
            current=total if ok and total else int(progress.get("current") or 0),
            total=total,
            percent=100 if ok else int(progress.get("percent") or 0),
            eta_seconds=None,
            total_estimate_seconds=None,
            warning=not ok,
            message=message,
            completion_summary=None,
            allow_completion=False,
        )
        return 0 if ok else 1
    except Exception as exc:
        message = f"帳戶商品操作失敗：{exc}"
        state.update(phase="error", warning=True, message=message, completion_summary=None, allow_completion=False)
        print(message, file=sys.stderr)
        return 1


def main() -> None:
    parser = argparse.ArgumentParser(description="整理圖片並填入 Carousell 商品頁")
    parser.add_argument("--product", help="只處理 待發布 底下指定的產品資料夾")
    parser.add_argument("--publish", action="store_true", help="填完後詢問是否按發布")
    parser.add_argument("--prepare-only", action="store_true", help="只整理圖片和建立草稿，不開啟瀏覽器")
    parser.add_argument("--check", action="store_true", help="檢查環境、設定檔和產品資料，不開啟瀏覽器")
    parser.add_argument("--attach", action="store_true", help="接管已開啟且有遠端控制的 Carousell Chrome 分頁")
    parser.add_argument("--manual-preview", action="store_true", help="只開啟指定商品預覽，不發布（由狀態頁使用）")
    parser.add_argument("--open-chrome", action="store_true", help="只開啟新的普通 Chrome，不開始發布")
    parser.add_argument("--status-server", action="store_true", help="啟動獨立即時狀態頁服務")
    parser.add_argument("--non-interactive", action="store_true", help="由狀態頁控制時不等待終端機輸入")
    parser.add_argument("--setup", action="store_true", help="安裝 Python 套件和 Playwright 瀏覽器元件")
    parser.add_argument(
        "--account-action",
        choices=("delete_duplicates", "delete_all_listings", "enable_all_buy_buttons", "disable_all_buy_buttons"),
        help="由狀態頁啟動的 Carousell 帳戶批量操作",
    )
    args = parser.parse_args()
    if args.status_server:
        run_status_server()
        return
    write_worker_pid()
    if args.open_chrome:
        raise SystemExit(open_new_chrome_only())
    if args.setup:
        raise SystemExit(run_setup())
    if args.check:
        raise SystemExit(run_diagnostics())
    if args.account_action:
        raise SystemExit(run_account_action(args.account_action))
    config = load_config()
    if args.non_interactive:
        config["_non_interactive"] = True
    if args.manual_preview:
        config["_manual_preview"] = True
    folders = product_folders(args.product)
    folders = order_publish_folders(folders, args.attach and args.publish and not args.product)
    report = {
        "started_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "mode": "prepare-only" if args.prepare_only else ("publish" if args.publish else "preview"),
        "success": [],
        "duplicates": [],
        "skipped": [],
        "preview": [],
        "failed": [],
    }
    clear_control_request()
    status_server = None
    status = None
    if bool(config.get("status_dashboard_enabled", True)):
        status_server, status, status_url, reused_dashboard = connect_or_start_status_dashboard(len(folders))
        print(("已連接現有" if reused_dashboard else "已開啟") + f"即時狀態頁面：{status_url}")
        if not reused_dashboard and not open_status_dashboard(status_url):
            print(f"[提示] 無法自動開啟獨立瀏覽器視窗，請手動打開：{status_url}")
    shared_playwright = None
    shared_context = None
    if args.publish and args.attach:
        try:
            shared_playwright, shared_context = start_attached_chrome_context(config)
            print("已接管一個 Chrome 連線，整批商品會在同一個 Carousell 分頁處理。")
        except Exception as exc:
            print(f"[錯誤] 無法接管 Chrome：{exc}", file=sys.stderr)
            if status:
                status.update(phase="error", message=f"無法接管 Chrome：{exc}")
            raise
    elif args.publish and not args.attach:
        try:
            shared_playwright, shared_context = start_shared_chrome_context(config)
            print("已啟動一個新的 Chrome 視窗，後續商品會在同一視窗內依次開啟分頁。")
        except Exception as exc:
            print(f"[錯誤] 無法啟動新的 Chrome：{exc}", file=sys.stderr)
            if status:
                status.update(phase="error", message=f"無法啟動新的 Chrome：{exc}")
            raise
    preflight_duplicate_paths: set[str] = set()
    if args.publish:
        duplicate_items = preflight_all_duplicates(
            folders,
            config,
            status,
            args.attach,
            shared_context=shared_context,
            shared_playwright=shared_playwright,
        )
        for item in duplicate_items:
            report["duplicates"].append(item)
            preflight_duplicate_paths.add(str(Path(item["folder"]).resolve()))
        if not config.get("_duplicate_scan", {}).get("complete"):
            message = "帳戶圖片重複檢查未完成；已略過確認重複的整組，其餘保留，這次未開始發布。"
            report["duplicate_check"] = config.get("_duplicate_scan")
            report["finished_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
            (ROOT / "last_run.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
            if status:
                status.add_issue(message + ' ' + '; '.join(config.get("_duplicate_scan", {}).get("errors", [])[:2]))
                status.update(phase="error", warning=True, message=message, completion_summary=None, allow_completion=False)
            if shared_context is not None and not args.attach:
                shared_context.close()
            if shared_playwright is not None:
                shared_playwright.stop()
            return
        print(f"發布前全量重複檢查完成：找到 {len(duplicate_items)} 件同款商品。")
        if status:
            status.update(
                phase="check",
                message=f"全部未處理商品檢查完成，找到 {len(duplicate_items)} 件同款，準備發布其餘商品...",
                percent=20,
            )
    for index, folder in enumerate(folders, 1):
        if str(folder.resolve()) in preflight_duplicate_paths:
            if status:
                status.update(
                    phase="duplicate",
                    title=folder.name,
                    current=index,
                    total=len(folders),
                    percent=int(index * 100 / max(len(folders), 1)),
                    message="發布前檢查發現同款，已跳過這件商品。",
                )
            continue
        try:
            if status:
                status.update(
                    phase="prepare",
                    title=folder.name,
                    current=index,
                    total=len(folders),
                    percent=int((index - 1) * 100 / max(len(folders), 1)),
                    message="正在建立商品草稿...",
                    manual_review_seconds=None,
                    manual_review_url="",
                )
            draft = make_draft(folder, config)
            print(f"準備 {draft.title}：{len(draft.images)} 張圖片")
            if not args.prepare_only:
                result = publish_in_browser(
                    draft,
                    config,
                    args.publish,
                    attach=args.attach,
                    status=status,
                    shared_context=shared_context,
                    shared_playwright=shared_playwright,
                )
                if result == "duplicate":
                    clear_product_error(folder)
                    if status:
                        status.clear_issues(draft.title)
                    destination = move_to_completed(folder, draft.title)
                    report["duplicates"].append({
                        "folder": str(folder),
                        "title": draft.title,
                        "moved_to": str(destination),
                        "images": len(draft.images),
                        "match": config.get("_last_duplicate_match"),
                    })
                    print(f"已將重複商品圖片移到：{destination}")
                    if status:
                        status.update(phase="duplicate", message="已跳過重複商品並移到已完成檔案。", percent=int(index * 100 / max(len(folders), 1)))
                    continue
                if result == "skipped":
                    report["skipped"].append({
                        "folder": str(folder),
                        "title": draft.title,
                        "images": len(draft.images),
                    })
                    print(f"已跳過商品，保留在待發布：{draft.title}")
                    if status:
                        status.update(phase="skip", message="已跳過目前商品，正在處理下一件。", percent=int(index * 100 / max(len(folders), 1)), manual_review_seconds=None)
                    continue
                if result == "preview":
                    report["preview"].append({
                        "folder": str(folder),
                        "title": draft.title,
                        "images": len(draft.images),
                    })
                    print(f"已完成預覽（未發布）：{draft.title}")
                    if status:
                        status.update(phase="preview", message="預覽頁已開啟，未發布；可直接在 Chrome 檢查。", percent=100, manual_review_seconds=None)
                    continue
                if result == "published":
                    account_index = config.get("_account_photo_index")
                    if isinstance(account_index, AccountIndex):
                        # Add only images actually uploaded (max_images), not
                        # unused originals from a larger product folder.
                        account_index.remember_published([Path(p) for p in draft.images])
                    clear_product_error(folder)
                    if status:
                        status.clear_issues(draft.title)
                    try:
                        destination = move_to_completed(folder, draft.title)
                    except OSError as move_exc:
                        # Windows may briefly keep an uploaded image locked.
                        # Retry before reporting anything to the user; the
                        # listing itself has already been confirmed online.
                        print(f"[提示] 已成功刊登，圖片移動暫時被鎖定，正在重試：{move_exc}")
                        time.sleep(1.2)
                        destination = move_to_completed(folder, draft.title)
                    print(f"已成功刊登，並將圖片移到：{destination}")
                    report["success"].append({
                        "folder": str(folder),
                        "title": draft.title,
                        "images": len(draft.images),
                        "moved_to": str(destination),
                    })
                    if status:
                        status.update(phase="done", message="商品已刊登並移到已完成檔案。", percent=int(index * 100 / max(len(folders), 1)))
                    continue
                if result in ("failed", "failed_duplicate"):
                    error_message = (
                        "Carousell 顯示此商品與已刊登商品相似，未確認發布成功，已保留在未處理。"
                        if result == "failed_duplicate"
                        else "Carousell 頁面有問題，已跳過並繼續下一件商品。"
                    )
                    mark_product_error(folder, draft.title, error_message)
                    report["failed"].append({
                        "folder": str(folder),
                        "title": draft.title,
                        "error": error_message,
                    })
                    if status:
                        status.update(
                            phase="error",
                            warning=result == "failed_duplicate",
                            message=error_message,
                            percent=int(index * 100 / max(len(folders), 1)),
                        )
                    continue
            report["success"].append({"folder": str(folder), "title": draft.title, "images": len(draft.images)})
            if status:
                status.update(phase="done", message="目前商品處理完成。", percent=int(index * 100 / max(len(folders), 1)))
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            print(f"[錯誤] {folder.name}：{exc}", file=sys.stderr)
            mark_product_error(folder, folder.name, str(exc))
            report["failed"].append({"folder": str(folder), "error": str(exc)})
            if status:
                status.add_issue(f"{folder.name}：{exc}")
                status.update(phase="error", warning=False, message="已記錄問題，繼續處理下一件商品。", percent=int(index * 100 / max(len(folders), 1)))
    if args.publish:
        remaining_folders = product_folders(None)
        if remaining_folders:
            if status:
                status.update(
                    phase="check",
                    title="最後檢查未處理商品",
                    current=0,
                    total=len(remaining_folders),
                    percent=98,
                    message="正在重新檢查待發布商品是否已存在於帳戶...",
                    completion_summary=None,
                    allow_completion=False,
                )
            try:
                final_duplicates = preflight_all_duplicates(
                    remaining_folders,
                    config,
                    status,
                    args.attach,
                    shared_context=shared_context,
                    shared_playwright=shared_playwright,
                    destination_bucket="completed",
                )
                for item in final_duplicates:
                    report["duplicates"].append(item)
                    clear_product_error(Path(item["folder"]))
                if not config.get("_duplicate_scan", {}).get("complete"):
                    raise DuplicateScanIncomplete("最後帳戶相簿檢查未完成：" + '; '.join(config.get("_duplicate_scan", {}).get("errors", [])[:2]))
                if final_duplicates:
                    print(f"程序結束前最後重複檢查找到 {len(final_duplicates)} 件同款，已移到已完成檔案。")
                else:
                    print("程序結束前最後重複檢查完成，沒有發現同款商品。")
            except Exception as exc:
                print(f"[提示] 程序結束前重複檢查未完成：{exc}")
                report["duplicate_check_incomplete"] = str(exc)
                if status:
                    status.add_issue(f"最後重複檢查：{exc}")

    report["finished_at"] = datetime.now().astimezone().isoformat(timespec="seconds")
    (ROOT / "last_run.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"完成：成功 {len(report['success'])} 個，重複跳過 {len(report['duplicates'])} 個，手動跳過 {len(report['skipped'])} 個，預覽 {len(report['preview'])} 個，失敗 {len(report['failed'])} 個。")
    print(f"詳細報告：{ROOT / 'last_run.json'}")
    if status:
        if not report["failed"] and not report.get("duplicate_check_incomplete"):
            status.clear_issues()
        summary = {
            "total": len(folders),
            "success": len(report["success"]),
            "duplicates": len(report["duplicates"]),
            "skipped": len(report["skipped"]),
            "failed": len(report["failed"]),
        }
        status.update(
            phase="preview" if args.manual_preview else "done",
            title="全部商品",
            current=len(folders),
            percent=100,
            message="預覽頁已開啟，未發布；可直接在 Chrome 檢查。" if args.manual_preview else "全部處理完成，可以查看這次作業摘要。",
            completion_summary=None if (args.manual_preview or args.prepare_only) else summary,
            allow_completion=not args.manual_preview and not args.prepare_only,
        )
    if status_server is not None:
        threading.Timer(30, status_server.shutdown).start()
    if shared_context is not None:
        try:
            # Closing a CDP context would close the user's existing Chrome
            # tabs. Disconnect the control connection instead and leave Chrome
            # open; ordinary new-Chrome runs can close their owned context.
            if not args.attach:
                shared_context.close()
        finally:
            if shared_playwright is not None:
                shared_playwright.stop()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("已停止。")
    except Exception as exc:
        print(f"錯誤：{exc}", file=sys.stderr)
        raise
    finally:
        clear_worker_pid()
