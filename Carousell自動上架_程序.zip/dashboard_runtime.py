"""Small local-dashboard utilities; no account or publishing operations."""
from __future__ import annotations

from collections import OrderedDict
from io import BytesIO
from pathlib import Path
import json
import os
import tempfile
import threading
import time

from PIL import Image, ImageOps


def read_json(path: Path) -> dict:
    """Windows can briefly deny a read while another process replaces JSON."""
    for attempt in range(4):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except PermissionError:
            if attempt == 3:
                raise
            time.sleep(.003 * (attempt + 1))


def atomic_write_json(path: Path, value: dict) -> None:
    """Readers see the previous complete JSON or the next complete JSON.

    Stage beside the destination so replace stays on the same filesystem.
    Windows antivirus/read handles can briefly delay replacement; retry only
    that operation, never fall back to truncating a live status file.
    """
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                         prefix=".aetheris-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            json.dump(value, stream, ensure_ascii=False)
        for attempt in range(4):
            try:
                os.replace(temporary, path)
                return
            except PermissionError:
                if attempt == 3:
                    raise
                time.sleep(.01 * (attempt + 1))
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


class ThumbnailCache:
    """Bounded encoded-image cache; invalidate when the original changes.

    A semaphore limits concurrent large-image decodes. Cached image bytes can
    be shared safely by dashboard lists, grouping cards and result dialogs.
    """
    def __init__(self, max_entries: int = 192, max_bytes: int = 8 * 1024 * 1024):
        self.max_entries = max_entries
        self.max_bytes = max_bytes
        self._items = OrderedDict()
        self._bytes = 0
        self._lock = threading.Lock()
        self._decoders = threading.Semaphore(2)

    def _read(self, key):
        with self._lock:
            payload = self._items.get(key)
            if payload is not None:
                self._items.move_to_end(key)
            return payload

    def get(self, source: Path, *, edge: int, quality: int, optimize: bool = False) -> bytes:
        info = source.stat()
        key = (str(source.resolve()), info.st_mtime_ns, info.st_ctime_ns,
               info.st_size, edge, quality, optimize)
        cached = self._read(key)
        if cached is not None:
            return cached
        with self._decoders:
            cached = self._read(key)
            if cached is not None:
                return cached
            with Image.open(source) as original:
                image = ImageOps.exif_transpose(original)
                if image.mode in ("RGBA", "LA"):
                    background = Image.new("RGB", image.size, "white")
                    background.paste(image, mask=image.getchannel("A"))
                    image = background
                else:
                    image = image.convert("RGB")
                image.thumbnail((edge, edge), Image.Resampling.LANCZOS)
                output = BytesIO()
                image.save(output, format="JPEG", quality=quality, optimize=optimize)
                payload = output.getvalue()
            if len(payload) <= self.max_bytes:
                with self._lock:
                    if key not in self._items:
                        self._items[key] = payload
                        self._bytes += len(payload)
                    while len(self._items) > self.max_entries or self._bytes > self.max_bytes:
                        _, removed = self._items.popitem(last=False)
                        self._bytes -= len(removed)
            return payload
