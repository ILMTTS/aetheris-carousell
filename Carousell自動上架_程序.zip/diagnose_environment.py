"""Read-only diagnosis of the existing app's Windows native-module failure.

Writes only its own reports under logs. Does not install packages, change
policies, start browsers, read photos/settings/profiles, or transmit reports.
Each import runs once in a bounded child process so a native crash is captured.
"""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timedelta, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import traceback
import xml.etree.ElementTree as ET

SCHEMA = 1
NS = {"e": "http://schemas.microsoft.com/win/2004/08/events/event"}
POLICY_TEXT = ("應用程式控制原則", "应用程序控制策略", "application control policy", "blocked by policy", "0xc0e90002", "0x800711c7")
CHANNELS = {
    "Microsoft-Windows-CodeIntegrity/Operational": (3077, 3033, 3004, 3076),
    "Microsoft-Windows-AppLocker/EXE and DLL": (8003, 8004),
    "Microsoft-Windows-AppLocker/MSI and Script": (8006, 8007, 8028, 8029, 8036),
}


def decode(raw: bytes) -> str:
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", "replace")
    if b"\x00" in raw[:120]:
        return raw.decode("utf-16-le", "replace")
    return raw.decode("utf-8-sig", "replace")


def run(command: list[str], timeout=15) -> dict:
    try:
        process = subprocess.run(command, capture_output=True, timeout=timeout,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return {"exit_code": process.returncode, "stdout": decode(process.stdout), "stderr": decode(process.stderr)}
    except subprocess.TimeoutExpired:
        return {"exit_code": None, "error": "timeout", "timeout_seconds": timeout}
    except OSError as error:
        return {"exit_code": None, "error": str(error), "winerror": getattr(error, "winerror", None)}


def probe(module: str) -> dict:
    code = '''import importlib,json,sys,traceback
name=sys.argv[1]
try:
 m=importlib.import_module(name)
 print(json.dumps(dict(ok=True,module=name,file=getattr(m,'__file__',None)),ensure_ascii=True))
except Exception as e:
 print(json.dumps(dict(ok=False,module=name,error_type=type(e).__name__,error=str(e),winerror=getattr(e,'winerror',None),traceback=traceback.format_exc()),ensure_ascii=True))
 sys.exit(1)
'''
    captured = run([sys.executable, "-I", "-B", "-c", code, module])
    try:
        result = json.loads(captured.get("stdout", "").strip())
    except ValueError:
        result = {"ok": False, "module": module, "error": captured.get("error") or captured.get("stderr") or "Import process exited without a report"}
    result["exit_code"] = captured["exit_code"]
    result["policy_message"] = any(text in str(result.get("error", "")).lower() for text in POLICY_TEXT) or result.get("winerror") == 4551
    return result


def package_inventory() -> tuple[list[dict], list[dict]]:
    packages, native = [], []
    for name in ("Pillow", "playwright", "greenlet"):
        try:
            distribution = metadata.distribution(name)
            packages.append({"name": name, "version": distribution.version, "metadata_path": str(distribution.locate_file(""))})
            for entry in distribution.files or []:
                if entry.suffix.lower() not in {".pyd", ".dll", ".exe"} or "tests" in entry.parts:
                    continue
                path = Path(distribution.locate_file(entry))
                record = {"package": name, "path": str(path), "exists": path.is_file()}
                if path.is_file():
                    record["size"] = path.stat().st_size
                    with path.open("rb") as stream:
                        record["sha256"] = hashlib.file_digest(stream, "sha256").hexdigest()
                    if entry.hash and entry.hash.mode == "sha256":
                        expected = base64.urlsafe_b64decode(entry.hash.value + "=" * (-len(entry.hash.value) % 4)).hex()
                        record["wheel_record_sha256"] = expected
                        record["matches_installed_wheel_record"] = expected == record["sha256"]
                native.append(record)
        except Exception as error:
            packages.append({"name": name, "error": str(error)})
    return packages, native


def parse_events(xml: str) -> list[dict]:
    if not xml.strip():
        return []
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        xml = re.sub(r"<\?xml[^>]*\?>", "", xml)
        root = ET.fromstring("<Events>" + xml + "</Events>")
    elements = [root] if root.tag.endswith("}Event") else list(root.findall(".//e:Event", NS))
    result = []
    for event in elements:
        system = event.find("e:System", NS)
        if system is None:
            continue
        values = {}
        for item in event.findall(".//e:EventData/e:Data", NS):
            values.setdefault(item.attrib.get("Name", "unnamed"), []).append(item.text or "")
        # Classic AppLocker events use UserData/RuleAndFileData instead.
        user_data = event.find("e:UserData", NS)
        if user_data is not None:
            for item in user_data.iter():
                if len(item) == 0 and item.text:
                    values.setdefault(item.tag.rsplit("}", 1)[-1], []).append(item.text)
        created = system.find("e:TimeCreated", NS)
        activity = system.find("e:Correlation", NS)
        result.append({"id": int(system.findtext("e:EventID", "0", NS)),
                       "record_id": system.findtext("e:EventRecordID", "", NS),
                       "time_utc": created.attrib.get("SystemTime", "") if created is not None else "",
                       "activity_id": activity.attrib.get("ActivityID", "") if activity is not None else "",
                       "data": values, "xml": ET.tostring(event, encoding="unicode")})
    return result


def related(event: dict, root: Path, native: list[dict]) -> bool:
    evidence = json.dumps(event["data"], ensure_ascii=False).replace("\\\\", "\\").lower()
    tokens = [str(root).lower(), "_greenlet", "pythonba.dll", "carousell", "aetheris"]
    tokens += [Path(item["path"]).name.lower() for item in native if Path(item["path"]).name.lower().startswith(("_imaging", "_webp", "_avif"))]
    return any(token and token in evidence for token in tokens)


def query_events(root: Path, native: list[dict], started: datetime) -> tuple[list[dict], list[dict]]:
    executable = str(Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32/wevtutil.exe")
    matches, reads = [], []
    for channel, ids in CHANNELS.items():
        # Query block/audit events separately from high-volume signature events.
        expression = "*[System[(" + " or ".join(f"EventID={value}" for value in ids) + ") and TimeCreated[timediff(@SystemTime) <= 604800000]]]"
        capture = run([executable, "qe", channel, "/q:" + expression, "/c:150", "/rd:true", "/f:xml"], timeout=12)
        read = {"channel": channel, "exit_code": capture["exit_code"], "days": 7, "limit": 150}
        if capture["exit_code"] != 0:
            read["error"] = capture.get("error") or capture.get("stderr")
        else:
            try:
                for event in parse_events(capture["stdout"]):
                    if related(event, root, native):
                        event["channel"] = channel
                        try:
                            when = datetime.fromisoformat(event["time_utc"].replace("Z", "+00:00"))
                            event["during_this_check"] = when >= started - timedelta(seconds=2)
                        except ValueError:
                            event["during_this_check"] = False
                        event["is_enforcement_block"] = event["id"] in {3077, 3033, 8004, 8007, 8029, 8036}
                        matches.append(event)
            except (ET.ParseError, ValueError) as error:
                read["error"] = "Cannot parse Windows event output: " + str(error)
        reads.append(read)
    return matches, reads


def control_state() -> dict:
    if os.name != "nt":
        return {"state": None, "note": "Not Windows"}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\CI\Policy") as key:
            value = winreg.QueryValueEx(key, "VerifiedAndReputablePolicyState")[0]
        return {"registry_value": value, "label": {0: "Off", 1: "On", 2: "Evaluation"}.get(value, "Unknown"),
                "note": "This value alone does not identify every possible App Control/AppLocker policy."}
    except OSError as error:
        return {"registry_value": None, "error": str(error)}


def summary(report: dict) -> str:
    lines = ["Aetheris 環境診斷 / Environment diagnosis", "時間 / Time: " + report["created_at"],
             "電腦上的程式路徑 / App: " + report["root"], "實際 Python / Interpreter: " + report["python"]["executable"],
             "Python: " + report["python"]["version"], "", "逐項載入結果 / Native import checks:"]
    for item in report["probes"]:
        lines.append(("[正常 / OK] " if item.get("ok") else "[失敗 / FAIL] ") + item["module"])
        if not item.get("ok"):
            lines.append("  " + item.get("error", "")[:1800])
    blocks = [item for item in report["events"] if item["is_enforcement_block"]]
    current = [item for item in blocks if item["during_this_check"]]
    lines += ["", f"Windows 相關封鎖事件 / Related block events: {len(blocks)}",
              f"本次檢查期間的事件 / During this check: {len(current)}"]
    for event in blocks[:15]:
        lines.append(f"  {event['time_utc']} | {event['channel']} | Event {event['id']}")
        for name, value in event["data"].items():
            if any(word in name.lower() for word in ("file", "path", "policy", "status", "signing")):
                lines.append("    " + name + ": " + "; ".join(value))
    failed_policy = any(item.get("policy_message") for item in report["probes"])
    lines += ["", "判讀 / Interpretation:"]
    if failed_policy:
        lines.append("已重現原生模組載入時的應用程式控制錯誤。請以 JSON 中對應 Windows 事件的檔名及 Policy 欄位確認實際被擋檔案。")
    elif any(not item.get("ok") for item in report["probes"]):
        lines.append("有模組載入失敗；目前錯誤不足以判定為 Windows 原則封鎖。請查看完整錯誤及模組路徑。")
    else:
        lines.append("這台電腦目前能載入受測模組；不能代替發生問題的另一台電腦，也不代表所有功能已驗證。")
    if not current:
        lines.append("未取得本次檢查的對應封鎖事件；不等於沒有封鎖，也不能將候選 .pyd 檔直接認定為唯一原因。")
    for read in report["event_reads"]:
        if read.get("error"):
            lines.append("事件記錄讀取狀態 / Log read: " + read["channel"] + ": " + read["error"][:700])
    lines += ["", "此工具只寫入 logs 下的診斷檔案；沒有安裝套件、修改 Windows 防護、開啟瀏覽器或讀取商品相片／登入資料。",
              "報告不會自動上傳，可能包含本機帳戶路徑。分享前可以遮去個人路徑。",
              "完整資料 / Full details: latest-diagnosis.json"]
    return "\n".join(lines) + "\n"


def collect(root: Path) -> dict:
    started = datetime.now(timezone.utc)
    packages, native = package_inventory()
    checks = []
    for module in ("ssl", "PIL._imaging", "greenlet._greenlet", "playwright.sync_api"):
        print("正在檢查 / Checking: " + module, flush=True)
        checks.append(probe(module))
    events, reads = query_events(root, native, started)
    return {"schema_version": SCHEMA, "created_at": datetime.now().astimezone().isoformat(), "root": str(root),
            "python": {"executable": sys.executable, "version": platform.python_version(), "architecture": platform.machine(), "base_prefix": sys.base_prefix},
            "windows": {"version": platform.platform(), "smart_app_control": control_state()},
            "packages": packages, "native_candidates": native, "probes": checks, "events": events, "event_reads": reads,
            "scope": "Local diagnostic only; no installations, browser actions, security changes or uploads."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--open-report", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    logs = root / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    try:
        report = collect(root)
        (logs / "latest-diagnosis.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        output = logs / "latest-diagnosis.txt"
        output.write_text(summary(report), encoding="utf-8-sig")
        print("\n診斷完成 / Report saved: " + str(output), flush=True)
        if args.open_report and os.name == "nt":
            os.startfile(str(output))
        return 0
    except Exception:
        (logs / "diagnostic-error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        print("診斷未完成，請查看 logs/diagnostic-error.txt", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
