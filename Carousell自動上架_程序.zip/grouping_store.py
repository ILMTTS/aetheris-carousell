"""Lossless manual regrouping of pending product originals.

The browser edits a manifest, not arbitrary paths. Saving requires an exact
partition of the inspected photos and an unchanged disk revision. Originals
are retained as a transaction backup, and interrupted commits are recovered.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import threading
from datetime import datetime
from urllib.parse import quote


class GroupingError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


class GroupingStore:
    def __init__(self, root, inbox, extensions):
        self.root, self.inbox = Path(root), Path(inbox)
        self.extensions = set(extensions)
        self.backups = self.root / '.grouping_backups'
        self.lock = threading.RLock()
        self.saving = False
        self._recover()

    @staticmethod
    def _hash(path):
        digest = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                digest.update(chunk)
        return digest.hexdigest()

    def _folder(self, name):
        if not isinstance(name, str) or name in ('', '.', '..') or '/' in name or '\\' in name:
            raise GroupingError('商品資料夾名稱無效。')
        folder = self.inbox / name
        if folder.is_symlink() or not folder.is_dir() or folder.resolve().parent != self.inbox.resolve():
            raise GroupingError('商品資料夾已變更，請重新讀取分組。', 409)
        return folder

    def photo_path(self, folder, filename):
        parent = self._folder(folder)
        if not isinstance(filename, str) or Path(filename).name != filename or '/' in filename or '\\' in filename:
            raise GroupingError('圖片名稱無效。')
        path = parent / filename
        if path.is_symlink() or not path.is_file() or path.resolve().parent != parent.resolve() or path.suffix.lower() not in self.extensions:
            raise GroupingError('找不到這張原始圖片。', 404)
        return path

    def _snapshot(self, names=None):
        self.inbox.mkdir(exist_ok=True, parents=True)
        if names is None:
            names = sorted(p.name for p in self.inbox.iterdir() if p.is_dir() and not p.name.startswith(('_', '.')))
        if not isinstance(names, list) or len(names) > 2000 or any(not isinstance(n, str) for n in names) or len(set(names)) != len(names):
            raise GroupingError('無效的商品清單。')
        groups, photos, skipped, revision = [], {}, [], []
        for name in sorted(names):
            folder = self._folder(name)
            contents = sorted(folder.iterdir())
            files = [p for p in contents if p.is_file() and not p.is_symlink() and p.suffix.lower() in self.extensions]
            # A prepared listing can contain descriptions and other metadata.
            # Do not silently discard or redistribute that data by regrouping.
            if not files or len(contents) != len(files):
                skipped.append(name)
                continue
            images = []
            for path in files:
                if path.resolve().parent != folder.resolve():
                    raise GroupingError('圖片路徑無效。')
                identity = hashlib.sha256((name + '\0' + path.name).encode('utf-8')).hexdigest()[:24]
                digest = self._hash(path)
                photos[identity] = (path, digest)
                revision.append([name, path.name, digest])
                images.append({'id': identity, 'name': path.name, 'url': '/grouping/photo?folder=' + quote(name) + '&file=' + quote(path.name)})
            groups.append({'key': name, 'name': name, 'photos': images})
        version = hashlib.sha256(json.dumps(revision, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()
        return {'ok': True, 'version': version, 'source_folders': [g['name'] for g in groups], 'groups': groups, 'skipped': skipped}, photos

    def inspect(self, names=None):
        with self.lock:
            return self._snapshot(names)[0]

    @staticmethod
    def _journal(tx, journal):
        temp = tx / 'journal.tmp'
        temp.write_text(json.dumps(journal, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp, tx / 'journal.json')

    def _rollback(self, tx, journal):
        # Move aside only outputs installed by this transaction, then put the
        # original directories back. Nothing is permanently deleted.
        for name in journal['outputs']:
            target, staged = self.inbox / name, tx / 'staged' / name
            if target.exists() and not staged.exists():
                target.rename(staged)
        for name in journal['sources']:
            original, target = tx / 'originals' / name, self.inbox / name
            if original.exists():
                if target.exists():
                    raise GroupingError('恢復分組時發現同名資料夾，原圖已保存在分組備份內。', 409)
                original.rename(target)
        journal['state'] = 'rolled_back'
        self._journal(tx, journal)

    def _recover(self):
        if not self.backups.is_dir():
            return
        for tx in self.backups.iterdir():
            file = tx / 'journal.json'
            if not file.is_file():
                continue
            journal = json.loads(file.read_text(encoding='utf-8'))
            if journal.get('state') == 'committing':
                self._rollback(tx, journal)

    def save(self, payload, busy=lambda: False):
        with self.lock:
            self.saving = True
            try:
                return self._save(payload, busy)
            finally:
                self.saving = False

    def _save(self, payload, busy):
        if not isinstance(payload, dict):
            raise GroupingError('分組資料無效。')
        request_id = payload.get('request_id', '')
        if not isinstance(request_id, str) or not re.fullmatch('[a-f0-9]{32}', request_id):
            raise GroupingError('儲存識別碼無效。')
        payload_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
        tx = self.backups / request_id
        journal_file = tx / 'journal.json'
        if journal_file.is_file():
            previous = json.loads(journal_file.read_text(encoding='utf-8'))
            if previous.get('state') == 'committed' and previous.get('payload_hash') == payload_hash:
                result = self.inspect(previous['outputs'])
                result['backup'] = str(tx / 'originals')
                return result
            raise GroupingError('這次儲存已處理，請重新讀取分組後再調整。', 409)
        if busy():
            raise GroupingError('商品程序正在處理資料夾，請先停止發布／整理，再儲存分組。', 409)
        names = payload.get('source_folders')
        if not names:
            raise GroupingError('沒有可調整的商品。')
        current, photos = self._snapshot(names)
        if current['skipped'] or current['version'] != payload.get('version'):
            raise GroupingError('照片或資料夾已被其他操作變更，尚未覆寫。請重新讀取分組。', 409)
        groups = payload.get('groups')
        if not isinstance(groups, list) or not groups or len(groups) > len(photos):
            raise GroupingError('每組至少需要一張照片。')
        flattened, keys = [], []
        for group in groups:
            if not isinstance(group, dict) or not isinstance(group.get('key'), str) or not isinstance(group.get('photos'), list) or not group['photos']:
                raise GroupingError('商品群組資料無效。')
            if any(not isinstance(i, str) for i in group['photos']):
                raise GroupingError('圖片識別碼無效。')
            keys.append(group['key']);flattened.extend(group['photos'])
        if len(set(keys)) != len(keys) or len(flattened) != len(photos) or set(flattened) != set(photos):
            raise GroupingError('每張照片必須保留，而且只能出現在一個群組。')
        self.backups.mkdir(exist_ok=True)
        tx.mkdir()
        (tx / 'staged').mkdir();(tx / 'originals').mkdir()
        stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        outputs = []
        for index, group in enumerate(groups):
            name = group['key'] if group['key'] in names else f'商品_手動組{index+1:02d}_{stamp}_{request_id[:6]}'
            if name in outputs or ((self.inbox / name).exists() and name not in names):
                raise GroupingError('商品資料夾名稱發生衝突，請重新讀取。', 409)
            outputs.append(name)
            stage = tx / 'staged' / name;stage.mkdir()
            used = set()
            for photo_id in group['photos']:
                source, digest = photos[photo_id]
                filename, number = source.name, 2
                while filename.casefold() in used:
                    filename = f'{source.stem} ({number}){source.suffix}';number += 1
                used.add(filename.casefold())
                target = stage / filename
                shutil.copy2(source, target)
                if self._hash(target) != digest:
                    raise GroupingError('圖片已變更，未儲存分組。', 409)
        # Recheck after staging. A concurrent external edit must not be lost.
        if self._snapshot(names)[0]['version'] != current['version'] or busy():
            raise GroupingError('資料夾正在被修改，未儲存分組。請稍後重新讀取。', 409)
        journal = {'state': 'committing', 'sources': names, 'outputs': outputs, 'payload_hash': payload_hash}
        self._journal(tx, journal)
        try:
            for name in names:
                (self.inbox / name).rename(tx / 'originals' / name)
            for name in outputs:
                (tx / 'staged' / name).rename(self.inbox / name)
            journal['state'] = 'committed';self._journal(tx, journal)
        except Exception:
            self._rollback(tx, journal)
            raise
        result = self.inspect(outputs)
        result['backup'] = str(tx / 'originals')
        return result
