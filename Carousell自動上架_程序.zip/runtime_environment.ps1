﻿# Shared by the installer and launcher. Discovery must survive a stale PATH.
function Initialize-AetherisEnvironment {
    $env:PYTHONUTF8 = '1'; $env:PYTHONIOENCODING = 'utf-8'; $env:PYTHONDONTWRITEBYTECODE = '1'
    Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
    Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
    Update-AetherisProcessPath
}

function Update-AetherisProcessPath {
    $parts = New-Object 'System.Collections.Generic.List[string]'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($value in @($env:Path, [Environment]::GetEnvironmentVariable('Path', 'Machine'), [Environment]::GetEnvironmentVariable('Path', 'User'))) {
        foreach ($part in ([string]$value -split ';')) {
            $part = [Environment]::ExpandEnvironmentVariables($part.Trim().Trim('"'))
            if ($part -and $seen.Add($part)) { $parts.Add($part) }
        }
    }
    $env:Path = $parts -join ';'
}

function ConvertTo-AetherisNativeArgument([string]$Value) {
    if ($Value -ne '' -and $Value -notmatch '[\s"]') { return $Value }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}

function Invoke-AetherisPythonProbe {
    param([string]$Command, [string[]]$Prefix = @(), [switch]$Packages, [switch]$RegisteredStoreAlias)
    if (-not $Command -or -not (Test-Path -LiteralPath $Command -PathType Leaf -ErrorAction SilentlyContinue)) { return $null }
    # Store aliases can open a Store window instead of providing Python.
    if ($Command -match '(?i)\\Microsoft\\WindowsApps\\' -and -not $RegisteredStoreAlias) { return $null }
    $code = @'
import json, os, re, sys
d = dict(executable=sys.executable, version='.'.join(map(str, sys.version_info[:3])), python_ok=sys.version_info >= (3, 13), ready=False, errors=[])
if not d['python_ok']: d['errors'].append('Python 3.13 or newer is required')
if '--packages' in sys.argv:
    try:
        import PIL
        d['pillow'] = PIL.__version__
        if tuple(map(int, re.findall(r'\d+', PIL.__version__)[:2])) < (10, 0): d['errors'].append('Pillow 10.0 or newer is required')
    except Exception as e: d['errors'].append('Pillow: ' + str(e))
    try:
        from importlib.metadata import version
        from playwright.sync_api import sync_playwright
        d['playwright'] = version('playwright')
        if tuple(map(int, re.findall(r'\d+', d['playwright'])[:2])) < (1, 45): d['errors'].append('Playwright 1.45 or newer is required')
        with sync_playwright() as p: d['chromium'] = p.chromium.executable_path
        if not os.path.isfile(d['chromium']): d['errors'].append('Chromium is not installed')
    except Exception as e: d['errors'].append('Playwright: ' + str(e))
d['ready'] = not d['errors']
print(json.dumps(d, ensure_ascii=True))
'@
    $arguments = @($Prefix) + @('-I', '-c', $code)
    if ($Packages) { $arguments += '--packages' }
    $process = New-Object System.Diagnostics.Process
    try {
        $info = New-Object System.Diagnostics.ProcessStartInfo
        $info.FileName = $Command
        $info.Arguments = (($arguments | ForEach-Object { ConvertTo-AetherisNativeArgument $_ }) -join ' ')
        $info.UseShellExecute = $false; $info.CreateNoWindow = $true
        $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
        $process.StartInfo = $info
        [void]$process.Start()
        $outTask = $process.StandardOutput.ReadToEndAsync(); $errTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) { $process.Kill(); return $null }
        $stdout = $outTask.GetAwaiter().GetResult(); [void]$errTask.GetAwaiter().GetResult()
        if ($process.ExitCode -ne 0) { return $null }
        return ($stdout.Trim() | ConvertFrom-Json)
    } catch { return $null }
    finally { $process.Dispose() }
}

function Get-AetherisProjectRuntime([string]$Root) {
    return (Invoke-AetherisPythonProbe -Command (Join-Path $Root '.venv\Scripts\python.exe') -Packages)
}

function Find-AetherisStorePython {
    # Probe a registered PSF package, never the empty Store execution alias.
    # Python's official Store distribution supports pip and normal venvs.
    $appx = Get-Command Get-AppxPackage -ErrorAction SilentlyContinue
    if (-not $appx) { return $null }
    foreach ($package in @(Get-AppxPackage -Name 'PythonSoftwareFoundation.Python.3.13' -ErrorAction SilentlyContinue)) {
        if ($package.Name -ne 'PythonSoftwareFoundation.Python.3.13' -or $package.PublisherId -ne 'qbz5n2kfra8p0') { continue }
        if (-not $package.InstallLocation) { continue }
        foreach ($name in @('python3.13.exe', 'python.exe')) {
            $probe = Invoke-AetherisPythonProbe -Command (Join-Path $package.InstallLocation $name)
            if ($probe -and $probe.python_ok) { return $probe }
        }
        # Some Store installs expose only per-user execution aliases. Allow
        # those only after the PSF package identity above has been verified.
        if ($env:LOCALAPPDATA) {
            $aliases = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
            foreach ($relative in @('PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python3.13.exe', 'PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python.exe', 'python3.13.exe')) {
                $probe = Invoke-AetherisPythonProbe -Command (Join-Path $aliases $relative) -RegisteredStoreAlias
                if ($probe -and $probe.python_ok) { return $probe }
            }
        }
    }
    return $null
}

function Find-AetherisBasePython {
    $candidates = New-Object 'System.Collections.Generic.List[object]'
    $add = { param($exe, $prefix)
        if ($exe) { $candidates.Add([pscustomobject]@{ Command = [string]$exe; Prefix = @($prefix) }) }
    }
    foreach ($name in @('py.exe', 'py')) {
        $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) { & $add $command.Source @('-3.13'); & $add $command.Source @('-3') }
    }
    $storePython = Find-AetherisStorePython
    if ($storePython) { return $storePython }
    # PEP 514 registration is available immediately after a per-user install.
    foreach ($key in @('HKCU:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\WOW6432Node\Python\PythonCore\*\InstallPath')) {
        foreach ($item in @(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue)) {
            if ($item.ExecutablePath) { & $add $item.ExecutablePath @() }
            if ($item.'(default)') { & $add (Join-Path $item.'(default)' 'python.exe') @() }
        }
    }
    foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        foreach ($pattern in @((Join-Path $base 'Programs\Python\Python3*'), (Join-Path $base 'Python3*'))) {
            foreach ($folder in @(Get-ChildItem -Path $pattern -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) { & $add (Join-Path $folder.FullName 'python.exe') @() }
        }
    }
    foreach ($name in @('python.exe', 'python3.exe')) {
        foreach ($command in @(Get-Command $name -All -CommandType Application -ErrorAction SilentlyContinue)) { & $add $command.Source @() }
    }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in $candidates) {
        if (-not $seen.Add($candidate.Command + '|' + ($candidate.Prefix -join ' '))) { continue }
        $probe = Invoke-AetherisPythonProbe -Command $candidate.Command -Prefix $candidate.Prefix
        if ($probe -and $probe.python_ok) { return $probe }
    }
    return $null
}

function Test-AetherisAppControlExitCode($Code) {
    try { $unsigned = ([long]$Code) -band 4294967295L } catch { return $false }
    # HRESULT, NTSTATUS, and Win32 representations of the same policy block.
    return $unsigned -in @(2147946951L, 3236495362L, 4551L)
}

function Get-AetherisAppControlState {
    try {
        return (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
    } catch { return $null }
}

function Save-AetherisSecurityDiagnostics([string]$Root) {
    # Read-only Windows queries. Never change SAC, Defender, or policy settings.
    try {
        $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
        $path = Join-Path $logs 'windows-security.txt'
        @('Aetheris v78 - local Windows installation diagnostics', ('Time: ' + (Get-Date -Format o)), ('Smart App Control registry state (0=Off, 1=On, 2=Evaluation; blank=unknown): ' + (Get-AetherisAppControlState)), 'This file stays on this computer. Event messages may contain local paths.') | Out-File -LiteralPath $path -Encoding utf8
        foreach ($log in @('Microsoft-Windows-CodeIntegrity/Operational', 'Microsoft-Windows-AppLocker/MSI and Script')) {
            ('--- ' + $log + ' (last 30 minutes, at most 15 events) ---') | Out-File -LiteralPath $path -Encoding utf8 -Append
            try {
                $ids = if ($log -like '*CodeIntegrity*') { @(3077,3033,3089) } else { @(8029,8036) }
                Get-WinEvent -FilterHashtable @{ LogName=$log; Id=$ids; StartTime=(Get-Date).AddMinutes(-30) } -MaxEvents 15 -ErrorAction Stop | Select-Object TimeCreated, Id, Message | Format-List | Out-String -Width 240 | Out-File -LiteralPath $path -Encoding utf8 -Append
            } catch { ('No readable matching events: ' + $_.Exception.Message) | Out-File -LiteralPath $path -Encoding utf8 -Append }
        }
        return $path
    } catch { return $null }
}

function Install-AetherisStorePython([string]$Root) {
    $storeUrl = 'https://apps.microsoft.com/detail/9PNRBTZXMB4Z'
    $winget = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $winget) { throw ('找不到 WinGet。請從 Microsoft Store 安裝免費的 Python 3.13（發行者 Python Software Foundation），完成後重開一鍵安裝：' + $storeUrl) }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    Write-Host '正在透過 Microsoft Store 安裝官方 Python 3.13...' -ForegroundColor Cyan
    # The Store package is an alternate official distribution. Do not retry
    # python-3.13.17-amd64.exe / PythonBA.dll after an application-control block.
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $winget.Source install --id 9PNRBTZXMB4Z -e --source msstore --silent --accept-source-agreements --accept-package-agreements --disable-interactivity 2>&1 | Tee-Object -FilePath (Join-Path $logs 'python-store-install.log') | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    Update-AetherisProcessPath
    for ($attempt=0; $attempt -lt 5; $attempt++) {
        $basePython = Find-AetherisBasePython
        if ($basePython -and $basePython.python_ok) { return $basePython }
        if ($attempt -lt 4) { Start-Sleep -Milliseconds 600 }
    }
    if (Test-AetherisAppControlExitCode $code) {
        throw ('Windows 應用程式控制封鎖了 Python 安裝（0x800711C7 / 0xC0E90002）。已停止，不會重試被擋的 EXE 或關閉保護。請由 Microsoft Store 安裝 Python 3.13：' + $storeUrl)
    }
    throw ('Microsoft Store 安裝尚未完成，代碼：' + $code + '。請查看 logs\python-store-install.log，或手動從 Microsoft Store 安裝 Python 3.13 後重試：' + $storeUrl)
}

function Write-AetherisInstallResult {
    param([string]$Root, [bool]$Success, $Runtime, [string]$Message)
    $data = [ordered]@{ success=$Success; checked_at=(Get-Date).ToString('o'); root=$Root; runtime=$Runtime; message=$Message; installer_version=78; smart_app_control_state=(Get-AetherisAppControlState) }
    $path = Join-Path $Root 'environment_install.json'; $temp = $path + '.' + $PID + '.tmp'
    [IO.File]::WriteAllText($temp, ($data | ConvertTo-Json -Depth 7), (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $path -Force
}
