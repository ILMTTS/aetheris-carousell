﻿# Shared by the installer and launcher. Discovery must survive a stale PATH.
function Initialize-AetherisEnvironment {
    $env:PYTHONUTF8 = '1'; $env:PYTHONIOENCODING = 'utf-8'; $env:PYTHONDONTWRITEBYTECODE = '1'
    Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
    Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
    Update-AetherisProcessPath
}

function Update-AetherisProcessPath {
    $parts = New-Object 'System.Collections.Generic.List[string]'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($value in @($env:Path, [Environment]::GetEnvironmentVariable('Path', 'Machine'), [Environment]::GetEnvironmentVariable('Path', 'User'))) {
        foreach ($part in ([string]$value -split ';')) {
            $part = [Environment]::ExpandEnvironmentVariables($part.Trim().Trim('"'))
            if ($part -and $seen.Add($part)) { $parts.Add($part) }
        }
    }
    $env:Path = $parts -join ';'
}

function ConvertTo-AetherisNativeArgument([string]$Value) {
    if ($Value -ne '' -and $Value -notmatch '[\s"]') { return $Value }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}

function Invoke-AetherisPythonProbe {
    param([string]$Command, [string[]]$Prefix = @(), [switch]$Packages)
    if (-not $Command -or -not (Test-Path -LiteralPath $Command -PathType Leaf)) { return $null }
    # Store aliases can open a Store window instead of providing Python.
    if ($Command -match '(?i)\\Microsoft\\WindowsApps\\') { return $null }
    $code = @'
import json, os, re, sys
d = dict(executable=sys.executable, version='.'.join(map(str, sys.version_info[:3])), python_ok=sys.version_info >= (3, 13), ready=False, errors=[])
if not d['python_ok']: d['errors'].append('Python 3.13 or newer is required')
if '--packages' in sys.argv:
    try:
        import PIL
        d['pillow'] = PIL.__version__
        if tuple(map(int, re.findall(r'\d+', PIL.__version__)[:2])) < (10, 0): d['errors'].append('Pillow 10.0 or newer is required')
    except Exception as e: d['errors'].append('Pillow: ' + str(e))
    try:
        from importlib.metadata import version
        from playwright.sync_api import sync_playwright
        d['playwright'] = version('playwright')
        if tuple(map(int, re.findall(r'\d+', d['playwright'])[:2])) < (1, 45): d['errors'].append('Playwright 1.45 or newer is required')
        with sync_playwright() as p: d['chromium'] = p.chromium.executable_path
        if not os.path.isfile(d['chromium']): d['errors'].append('Chromium is not installed')
    except Exception as e: d['errors'].append('Playwright: ' + str(e))
d['ready'] = not d['errors']
print(json.dumps(d, ensure_ascii=True))
'@
    $arguments = @($Prefix) + @('-I', '-c', $code)
    if ($Packages) { $arguments += '--packages' }
    $process = New-Object System.Diagnostics.Process
    try {
        $info = New-Object System.Diagnostics.ProcessStartInfo
        $info.FileName = $Command
        $info.Arguments = (($arguments | ForEach-Object { ConvertTo-AetherisNativeArgument $_ }) -join ' ')
        $info.UseShellExecute = $false; $info.CreateNoWindow = $true
        $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
        $process.StartInfo = $info
        [void]$process.Start()
        $outTask = $process.StandardOutput.ReadToEndAsync(); $errTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) { $process.Kill(); return $null }
        $stdout = $outTask.GetAwaiter().GetResult(); [void]$errTask.GetAwaiter().GetResult()
        if ($process.ExitCode -ne 0) { return $null }
        return ($stdout.Trim() | ConvertFrom-Json)
    } catch { return $null }
    finally { $process.Dispose() }
}

function Get-AetherisProjectRuntime([string]$Root) {
    return (Invoke-AetherisPythonProbe -Command (Join-Path $Root '.venv\Scripts\python.exe') -Packages)
}

function Find-AetherisBasePython {
    $candidates = New-Object 'System.Collections.Generic.List[object]'
    $add = { param($exe, $prefix)
        if ($exe) { $candidates.Add([pscustomobject]@{ Command = [string]$exe; Prefix = @($prefix) }) }
    }
    foreach ($name in @('py.exe', 'py')) {
        $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) { & $add $command.Source @('-3.13'); & $add $command.Source @('-3') }
    }
    # PEP 514 registration is available immediately after a per-user install.
    foreach ($key in @('HKCU:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\WOW6432Node\Python\PythonCore\*\InstallPath')) {
        foreach ($item in @(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue)) {
            if ($item.ExecutablePath) { & $add $item.ExecutablePath @() }
            if ($item.'(default)') { & $add (Join-Path $item.'(default)' 'python.exe') @() }
        }
    }
    foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        foreach ($pattern in @((Join-Path $base 'Programs\Python\Python3*'), (Join-Path $base 'Python3*'))) {
            foreach ($folder in @(Get-ChildItem -Path $pattern -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) { & $add (Join-Path $folder.FullName 'python.exe') @() }
        }
    }
    foreach ($name in @('python.exe', 'python3.exe')) {
        foreach ($command in @(Get-Command $name -All -CommandType Application -ErrorAction SilentlyContinue)) { & $add $command.Source @() }
    }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in $candidates) {
        if (-not $seen.Add($candidate.Command + '|' + ($candidate.Prefix -join ' '))) { continue }
        $probe = Invoke-AetherisPythonProbe -Command $candidate.Command -Prefix $candidate.Prefix
        if ($probe -and $probe.python_ok) { return $probe }
    }
    return $null
}

function Write-AetherisInstallResult {
    param([string]$Root, [bool]$Success, $Runtime, [string]$Message)
    $data = [ordered]@{ success=$Success; checked_at=(Get-Date).ToString('o'); root=$Root; runtime=$Runtime; message=$Message }
    $path = Join-Path $Root 'environment_install.json'; $temp = $path + '.' + $PID + '.tmp'
    [IO.File]::WriteAllText($temp, ($data | ConvertTo-Json -Depth 7), (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $path -Force
}
