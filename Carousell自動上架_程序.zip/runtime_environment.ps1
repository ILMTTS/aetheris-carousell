﻿# Shared by the installer and launcher. Discovery must survive a stale PATH.
function Initialize-AetherisEnvironment {
    $env:PYTHONUTF8 = '1'; $env:PYTHONIOENCODING = 'utf-8'; $env:PYTHONDONTWRITEBYTECODE = '1'
    Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
    Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
    Update-AetherisProcessPath
}

function Update-AetherisProcessPath {
    $parts = New-Object 'System.Collections.Generic.List[string]'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($value in @($env:Path, [Environment]::GetEnvironmentVariable('Path', 'Machine'), [Environment]::GetEnvironmentVariable('Path', 'User'))) {
        foreach ($part in ([string]$value -split ';')) {
            $part = [Environment]::ExpandEnvironmentVariables($part.Trim().Trim('"'))
            if ($part -and $seen.Add($part)) { $parts.Add($part) }
        }
    }
    $env:Path = $parts -join ';'
}

function ConvertTo-AetherisNativeArgument([string]$Value) {
    if ($Value -ne '' -and $Value -notmatch '[\s"]') { return $Value }
    $escaped = [regex]::Replace($Value, '(\\*)"', '$1$1\"')
    $escaped = [regex]::Replace($escaped, '(\\+)$', '$1$1')
    return '"' + $escaped + '"'
}

function Invoke-AetherisPythonProbe {
    param([string]$Command, [string[]]$Prefix = @(), [switch]$Packages, [switch]$RegisteredStoreAlias)
    if (-not $Command -or -not (Test-Path -LiteralPath $Command -PathType Leaf -ErrorAction SilentlyContinue)) { return $null }
    # Store aliases can open a Store window instead of providing Python.
    if ($Command -match '(?i)\\Microsoft\\WindowsApps\\' -and -not $RegisteredStoreAlias) { return $null }
    $code = @'
import io, json, os, re, sys
from importlib.metadata import distribution, version
d = dict(executable=sys.executable, version='.'.join(map(str, sys.version_info[:3])),
         python_ok=sys.version_info >= (3, 13), ready=False, policy_blocked=False,
         browser_missing=False, packages_ok=False, errors=[], issues=[], probe_version=2)

def issue(component, message, kind, **extra):
    d['errors'].append(component + ': ' + message)
    d['issues'].append(dict(component=component, kind=kind, message=message, **extra))
    if kind == 'policy_blocked': d['policy_blocked'] = True

def failed(component, error, package):
    # DLL import errors may wrap the Windows policy error without a winerror.
    # Match only known policy messages/codes, not every DLL load failure.
    messages, codes, seen, current = [], [], set(), error
    while current is not None and id(current) not in seen:
        seen.add(id(current)); messages.append(str(current))
        for key in ('winerror', 'errno'):
            value = getattr(current, key, None)
            if isinstance(value, int): codes.append(value & 0xffffffff)
        current = current.__cause__ or current.__context__
    message = '; '.join(dict.fromkeys(messages))
    lower = message.lower()
    blocked = bool(set(codes) & {4551, 2147946951, 3236495362}) or any(
        text in lower for text in ('application control policy has blocked',
        'blocked by application control', '應用程式控制原則已封鎖',
        '应用程序控制策略已阻止', '应用程序控制策略已封锁',
        '0xc0e90002', '0x800711c7', 'winerror 4551'))
    paths = []
    try:
        dist = distribution(package)
        for file in dist.files or ():
            if str(file).lower().endswith('.pyd'):
                paths.append(str(dist.locate_file(file)))
    except Exception: pass
    kind = 'policy_blocked' if blocked else ('missing_package' if isinstance(error, ModuleNotFoundError) else 'load_failed')
    issue(component, message, kind, error_type=type(error).__name__, codes=codes,
          native_candidates=paths)

if not d['python_ok']: issue('Python', 'Python 3.13 or newer is required', 'unsupported_version')
if '--packages' in sys.argv:
    try:
        import PIL
        d['pillow'] = PIL.__version__
        # Importing PIL alone does NOT load its native image core.
        import PIL._imaging
        from PIL import Image, ImageOps
        stream = io.BytesIO()
        Image.new('RGB', (2, 2), (23, 45, 67)).save(stream, format='PNG')
        stream.seek(0)
        with Image.open(stream) as image:
            image.load()
            if image.getpixel((0, 0)) != (23, 45, 67): raise RuntimeError('PNG round-trip failed')
        d['pillow_native_ok'] = True
        if tuple(map(int, re.findall(r'\d+', PIL.__version__)[:2])) < (10, 0):
            issue('Pillow', 'Pillow 10.0 or newer is required', 'unsupported_version')
    except Exception as e: failed('PIL._imaging', e, 'Pillow')
    greenlet_ok = False
    try:
        import greenlet
        import greenlet._greenlet
        if greenlet.greenlet(lambda: 'ok').switch() != 'ok': raise RuntimeError('greenlet switch failed')
        d['greenlet'] = version('greenlet')
        d['greenlet_native_ok'] = greenlet_ok = True
    except Exception as e: failed('greenlet._greenlet', e, 'greenlet')
    if greenlet_ok:
        try:
            from playwright.sync_api import sync_playwright
            d['playwright'] = version('playwright')
            if tuple(map(int, re.findall(r'\d+', d['playwright'])[:2])) < (1, 45):
                issue('Playwright', 'Playwright 1.45 or newer is required', 'unsupported_version')
            # Do not start the driver when any dependency already failed.
            if not d['issues']:
                with sync_playwright() as p: d['chromium'] = p.chromium.executable_path
                if not os.path.isfile(d['chromium']):
                    d['browser_missing'] = True
                    issue('Chromium', 'Chromium is not installed', 'missing_browser')
        except Exception as e: failed('Playwright', e, 'playwright')
    d['packages_ok'] = not any(i['kind'] != 'missing_browser' for i in d['issues'])
d['ready'] = not d['errors']
print(json.dumps(d, ensure_ascii=True))
'@
    $arguments = @($Prefix) + @('-I', '-c', $code)
    if ($Packages) { $arguments += '--packages' }
    $process = New-Object System.Diagnostics.Process
    try {
        $info = New-Object System.Diagnostics.ProcessStartInfo
        $info.FileName = $Command
        $info.Arguments = (($arguments | ForEach-Object { ConvertTo-AetherisNativeArgument $_ }) -join ' ')
        $info.UseShellExecute = $false; $info.CreateNoWindow = $true
        $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
        $process.StartInfo = $info
        [void]$process.Start()
        $outTask = $process.StandardOutput.ReadToEndAsync(); $errTask = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(15000)) { $process.Kill(); return $null }
        $stdout = $outTask.GetAwaiter().GetResult(); $stderr = $errTask.GetAwaiter().GetResult()
        if ($process.ExitCode -ne 0) {
            return (Get-AetherisBlockedProcessProbe -Command $Command -Code $process.ExitCode -Message $stderr)
        }
        return ($stdout.Trim() | ConvertFrom-Json)
    } catch {
        $exception = $_.Exception
        while ($exception.InnerException) { $exception = $exception.InnerException }
        return (Get-AetherisBlockedProcessProbe -Command $Command -Code $exception.NativeErrorCode -Message $exception.Message)
    }
    finally { $process.Dispose() }
}

function Get-AetherisBlockedProcessProbe {
    param([string]$Command, $Code, [string]$Message)
    if (-not (Test-AetherisAppControlExitCode $Code) -and $Message -notmatch '(?i)0xc0e90002|0x800711c7|WinError 4551|application control policy has blocked|blocked by application control|應用程式控制原則已封鎖|应用程序控制策略已阻止|应用程序控制策略已封锁') { return $null }
    $details = 'Windows application control blocked the Python process. ' + $Message
    return [pscustomobject]@{ executable=$Command; python_ok=$false; ready=$false; policy_blocked=$true; probe_version=2; errors=@($details); issues=@([pscustomobject]@{component='Python';kind='policy_blocked';message=$details;exit_code=$Code}) }
}

function Assert-AetherisRuntimeNotBlocked {
    param([string]$Root, $Runtime)
    if (-not $Runtime -or -not $Runtime.policy_blocked) { return }
    # Keep an actionable local result instead of reinstalling identical DLLs.
    # The candidate paths aid diagnosis; they are not proof of the blocked file.
    try {
        $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
        [IO.File]::WriteAllText((Join-Path $logs 'environment-check.json'), ($Runtime | ConvertTo-Json -Depth 9), (New-Object Text.UTF8Encoding($false)))
    } catch {}
    $components = @($Runtime.issues | Where-Object { $_.kind -eq 'policy_blocked' } | ForEach-Object { $_.component }) -join ', '
    throw ('Windows 應用程式控制已封鎖元件 / Windows application control blocked: ' + $components + '。已停止自動重裝；重裝相同套件不能解除原則封鎖。詳情 / Details: logs\environment-check.json；assets\install-support.html。原有圖片、設定及環境已保留。')
}

function Get-AetherisProjectRuntime([string]$Root) {
    return (Invoke-AetherisPythonProbe -Command (Join-Path $Root '.venv\Scripts\python.exe') -Packages)
}

function Find-AetherisStorePython {
    # Probe a registered PSF package, never the empty Store execution alias.
    # Python's official Store distribution supports pip and normal venvs.
    $appx = Get-Command Get-AppxPackage -ErrorAction SilentlyContinue
    if (-not $appx) { return $null }
    foreach ($package in @(Get-AppxPackage -Name 'PythonSoftwareFoundation.Python.3.13' -ErrorAction SilentlyContinue)) {
        if ($package.Name -ne 'PythonSoftwareFoundation.Python.3.13' -or $package.PublisherId -ne 'qbz5n2kfra8p0') { continue }
        if (-not $package.InstallLocation) { continue }
        foreach ($name in @('python3.13.exe', 'python.exe')) {
            $probe = Invoke-AetherisPythonProbe -Command (Join-Path $package.InstallLocation $name)
            if ($probe -and $probe.python_ok) { return $probe }
        }
        # Some Store installs expose only per-user execution aliases. Allow
        # those only after the PSF package identity above has been verified.
        if ($env:LOCALAPPDATA) {
            $aliases = Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps'
            foreach ($relative in @('PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python3.13.exe', 'PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python.exe', 'python3.13.exe')) {
                $probe = Invoke-AetherisPythonProbe -Command (Join-Path $aliases $relative) -RegisteredStoreAlias
                if ($probe -and $probe.python_ok) { return $probe }
            }
        }
    }
    return $null
}

function Find-AetherisBasePython {
    $candidates = New-Object 'System.Collections.Generic.List[object]'
    $add = { param($exe, $prefix)
        if ($exe) { $candidates.Add([pscustomobject]@{ Command = [string]$exe; Prefix = @($prefix) }) }
    }
    foreach ($name in @('py.exe', 'py')) {
        $command = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($command) { & $add $command.Source @('-3.13'); & $add $command.Source @('-3') }
    }
    $storePython = Find-AetherisStorePython
    if ($storePython) { return $storePython }
    # PEP 514 registration is available immediately after a per-user install.
    foreach ($key in @('HKCU:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\Python\PythonCore\*\InstallPath', 'HKLM:\Software\WOW6432Node\Python\PythonCore\*\InstallPath')) {
        foreach ($item in @(Get-ItemProperty -Path $key -ErrorAction SilentlyContinue)) {
            if ($item.ExecutablePath) { & $add $item.ExecutablePath @() }
            if ($item.'(default)') { & $add (Join-Path $item.'(default)' 'python.exe') @() }
        }
    }
    foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $base) { continue }
        foreach ($pattern in @((Join-Path $base 'Programs\Python\Python3*'), (Join-Path $base 'Python3*'))) {
            foreach ($folder in @(Get-ChildItem -Path $pattern -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) { & $add (Join-Path $folder.FullName 'python.exe') @() }
        }
    }
    foreach ($name in @('python.exe', 'python3.exe')) {
        foreach ($command in @(Get-Command $name -All -CommandType Application -ErrorAction SilentlyContinue)) { & $add $command.Source @() }
    }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($candidate in $candidates) {
        if (-not $seen.Add($candidate.Command + '|' + ($candidate.Prefix -join ' '))) { continue }
        $probe = Invoke-AetherisPythonProbe -Command $candidate.Command -Prefix $candidate.Prefix
        if ($probe -and $probe.python_ok) { return $probe }
    }
    return $null
}

function Test-AetherisAppControlExitCode($Code) {
    try { $unsigned = ([long]$Code) -band 4294967295L } catch { return $false }
    # HRESULT, NTSTATUS, and Win32 representations of the same policy block.
    return $unsigned -in @(2147946951L, 3236495362L, 4551L)
}

function Get-AetherisAppControlState {
    try {
        return (Get-ItemProperty -LiteralPath 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -Name VerifiedAndReputablePolicyState -ErrorAction Stop).VerifiedAndReputablePolicyState
    } catch { return $null }
}

function Save-AetherisSecurityDiagnostics([string]$Root) {
    # Read-only Windows queries. Never change SAC, Defender, or policy settings.
    try {
        $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
        $path = Join-Path $logs 'windows-security.txt'
        @('Aetheris v78 - local Windows installation diagnostics', ('Time: ' + (Get-Date -Format o)), ('Smart App Control registry state (0=Off, 1=On, 2=Evaluation; blank=unknown): ' + (Get-AetherisAppControlState)), 'This file stays on this computer. Event messages may contain local paths.') | Out-File -LiteralPath $path -Encoding utf8
        foreach ($log in @('Microsoft-Windows-CodeIntegrity/Operational', 'Microsoft-Windows-AppLocker/MSI and Script')) {
            ('--- ' + $log + ' (last 30 minutes, at most 15 events) ---') | Out-File -LiteralPath $path -Encoding utf8 -Append
            try {
                $ids = if ($log -like '*CodeIntegrity*') { @(3077,3033,3089) } else { @(8029,8036) }
                Get-WinEvent -FilterHashtable @{ LogName=$log; Id=$ids; StartTime=(Get-Date).AddMinutes(-30) } -MaxEvents 15 -ErrorAction Stop | Select-Object TimeCreated, Id, Message | Format-List | Out-String -Width 240 | Out-File -LiteralPath $path -Encoding utf8 -Append
            } catch { ('No readable matching events: ' + $_.Exception.Message) | Out-File -LiteralPath $path -Encoding utf8 -Append }
        }
        return $path
    } catch { return $null }
}

function Install-AetherisStorePython([string]$Root) {
    $storeUrl = 'https://apps.microsoft.com/detail/9PNRBTZXMB4Z'
    $winget = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $winget) { throw ('找不到 WinGet。請從 Microsoft Store 安裝免費的 Python 3.13（發行者 Python Software Foundation），完成後重開一鍵安裝：' + $storeUrl) }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    Write-Host '正在透過 Microsoft Store 安裝官方 Python 3.13...' -ForegroundColor Cyan
    # The Store package is an alternate official distribution. Do not retry
    # python-3.13.17-amd64.exe / PythonBA.dll after an application-control block.
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $winget.Source install --id 9PNRBTZXMB4Z -e --source msstore --silent --accept-source-agreements --accept-package-agreements --disable-interactivity 2>&1 | Tee-Object -FilePath (Join-Path $logs 'python-store-install.log') | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    Update-AetherisProcessPath
    for ($attempt=0; $attempt -lt 5; $attempt++) {
        $basePython = Find-AetherisBasePython
        if ($basePython -and $basePython.python_ok) { return $basePython }
        if ($attempt -lt 4) { Start-Sleep -Milliseconds 600 }
    }
    if (Test-AetherisAppControlExitCode $code) {
        throw ('Windows 應用程式控制封鎖了 Python 安裝（0x800711C7 / 0xC0E90002）。已停止，不會重試被擋的 EXE 或關閉保護。請由 Microsoft Store 安裝 Python 3.13：' + $storeUrl)
    }
    throw ('Microsoft Store 安裝尚未完成，代碼：' + $code + '。請查看 logs\python-store-install.log，或手動從 Microsoft Store 安裝 Python 3.13 後重試：' + $storeUrl)
}

function Find-AetherisChrome {
    # Look in both per-user and system locations; never replace a working Chrome.
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    foreach ($key in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')) {
        try {
            $value = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).'(default)'
            if ($value) { $candidates.Add(([string]$value).Trim('"')) }
        } catch {}
    }
    foreach ($base in @($env:LOCALAPPDATA, $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($base) { $candidates.Add((Join-Path $base 'Google\Chrome\Application\chrome.exe')) }
    }
    foreach ($command in @(Get-Command chrome.exe -CommandType Application -ErrorAction SilentlyContinue)) {
        if ($command.Source) { $candidates.Add($command.Source) }
    }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf -ErrorAction SilentlyContinue) { return $candidate }
    }
    return $null
}

function Install-AetherisChrome([string]$Root) {
    $existing = Find-AetherisChrome
    if ($existing) { Write-Host 'Google Chrome 已安裝，直接沿用。' -ForegroundColor Green; return $existing }
    $winget = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $winget) { throw '找不到 WinGet，無法自動安裝 Chrome。請開啟「環境下載.html」的備用下載；選擇 Google Chrome，安裝後再執行本檔。' }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    Write-Host '正在自動下載並安裝 Google Chrome；Windows 可能要求你同意安裝。' -ForegroundColor Cyan
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $winget.Source install --id Google.Chrome --exact --source winget --silent --accept-source-agreements --accept-package-agreements --disable-interactivity 2>&1 | Tee-Object -FilePath (Join-Path $logs 'chrome-install.log') | Out-Host
        $code = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    Update-AetherisProcessPath
    for ($attempt=0; $attempt -lt 5; $attempt++) {
        $chrome = Find-AetherisChrome
        if ($chrome) { return $chrome }
        if ($attempt -lt 4) { Start-Sleep -Milliseconds 600 }
    }
    if (Test-AetherisAppControlExitCode $code) { throw 'Windows 應用程式控制封鎖了 Chrome 安裝。已停止，不會重試或修改防護；詳情：logs\chrome-install.log。' }
    throw ('Chrome 尚未安裝成功，代碼：' + $code + '。請查看 logs\chrome-install.log；若取消了 Windows 安裝確認，請重新執行一鍵安裝。')
}

function Write-AetherisInstallResult {
    param([string]$Root, [bool]$Success, $Runtime, [string]$Message)
    $data = [ordered]@{ success=$Success; checked_at=(Get-Date).ToString('o'); root=$Root; runtime=$Runtime; message=$Message; installer_version=78; runtime_probe_version=2; smart_app_control_state=(Get-AetherisAppControlState) }
    $path = Join-Path $Root 'environment_install.json'; $temp = $path + '.' + $PID + '.tmp'
    [IO.File]::WriteAllText($temp, ($data | ConvertTo-Json -Depth 7), (New-Object Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $path -Force
}
