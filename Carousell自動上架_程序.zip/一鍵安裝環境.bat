@echo off
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Aetheris 一鍵安裝
if not exist "%~dp0安裝環境.ps1" goto MISSING
if not exist "%~dp0runtime_environment.ps1" goto MISSING
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0安裝環境.ps1"
set "AETHERIS_SETUP_CODE=%errorlevel%"
if not "%AETHERIS_SETUP_CODE%"=="0" (
  echo.
  echo 安裝尚未完成，請查看上方訊息。詳情保留在 logs 資料夾。
  pause
  exit /b 1
)
if not exist "%~dp0啟動工具.bat" goto MISSING
echo.
echo 環境驗證成功，正在自動開啟工具。
call "%~dp0啟動工具.bat"
exit /b %errorlevel%
:MISSING
echo 請先把完整程序包解壓縮到同一個資料夾，再雙擊「一鍵安裝環境.bat」。
pause
exit /b 1
