@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Carousell 環境安裝

if not exist "%~dp0安裝環境.ps1" (
  echo 找不到安裝環境.ps1，請重新下載完整部署包。
  pause
  exit /b 1
)
if not exist "%~dp0runtime_environment.ps1" (
  echo 請先完整解壓縮最新程序包，缺少 runtime_environment.ps1。
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0安裝環境.ps1"
if errorlevel 1 (
  echo.
  echo 安裝未完成，請查看上面的錯誤訊息。
  pause
  exit /b 1
)
echo.
pause
