@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Carousell status launcher

if not exist "config.json" if exist "config.example.json" copy /y "config.example.json" "config.json" >nul

if exist "%~dp0.venv\Scripts\pythonw.exe" goto START_VENV

where py >nul 2>&1
if not errorlevel 1 (
    py -3.13 -c "import PIL,playwright" >nul 2>&1
    if not errorlevel 1 goto START_PY313
    py -c "import PIL,playwright" >nul 2>&1
    if not errorlevel 1 goto START_PY_DEFAULT
)

where pythonw >nul 2>&1
if not errorlevel 1 (
    python -c "import PIL,playwright" >nul 2>&1
    if not errorlevel 1 goto START_PYTHON
)

echo 找不到可用的 Python 環境，請先雙擊「一鍵安裝環境.bat」。
echo 需要 Python 3.13+、Pillow 和 Playwright。
pause
exit /b 1

:START_VENV
start "" /b "%~dp0.venv\Scripts\pythonw.exe" carousell_publish.py --status-server <nul
exit /b 0

:START_PY313
start "" /b pyw -3.13 carousell_publish.py --status-server <nul
exit /b 0

:START_PY_DEFAULT
start "" /b pyw carousell_publish.py --status-server <nul
exit /b 0

:START_PYTHON
start "" /b pythonw carousell_publish.py --status-server <nul
exit /b 0
