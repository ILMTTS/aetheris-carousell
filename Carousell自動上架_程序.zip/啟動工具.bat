@echo off
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Aetheris
if not exist "%~dp0啟動工具.ps1" goto MISSING
if not exist "%~dp0runtime_environment.ps1" goto MISSING
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0啟動工具.ps1"
if errorlevel 1 (
  echo.
  echo 啟動未完成，請查看上方錯誤及 logs 資料夾。
  pause
  exit /b 1
)
exit /b 0
:MISSING
echo 請先完整解壓縮最新程序包，再執行啟動工具。
pause
exit /b 1
