@echo off
chcp 65001 >nul
setlocal
set PYTHONUTF8=1
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Aetheris
if not exist "%~dp0啟動工具.ps1" goto MISSING
if not exist "%~dp0runtime_environment.ps1" goto MISSING
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0啟動工具.ps1"
set "AETHERIS_LAUNCH_CODE=%errorlevel%"
if "%AETHERIS_LAUNCH_CODE%"=="0" exit /b 0
if "%AETHERIS_LAUNCH_CODE%"=="3" exit /b 0
echo.
echo 啟動未完成，先開啟環境下載與安裝頁。錯誤記錄在 logs 資料夾。
goto HELP
:MISSING
echo 程序包尚未完整解壓縮，先開啟環境下載與安裝頁。
:HELP
if exist "%~dp0環境下載.html" (
  start "" "%~dp0環境下載.html"
) else (
  start "" "https://ilmtts.github.io/aetheris-carousell/%%E7%%92%%B0%%E5%%A2%%83%%E4%%B8%%8B%%E8%%BC%%89.html?v=78-env3"
)
echo 安裝完成後，請重新雙擊「啟動工具.bat」。
pause
exit /b 1
