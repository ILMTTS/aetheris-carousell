﻿param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
try {
    . (Join-Path $Root 'runtime_environment.ps1')
    Initialize-AetherisEnvironment
    Set-Location -LiteralPath $Root
    $runtime = Get-AetherisProjectRuntime $Root
    if ($CheckOnly) {
        [pscustomobject]@{ ready=[bool]($runtime -and $runtime.ready); runtime=$runtime } | ConvertTo-Json -Depth 7
        if ($runtime -and $runtime.ready) { exit 0 }; exit 2
    }
    if (-not $runtime -or -not $runtime.ready) {
        # The setup page is static HTML: no Python, packages, or local server.
        # Do not run the installer just to show download links to a new user.
        if ($runtime -and $runtime.policy_blocked) {
            try { Assert-AetherisRuntimeNotBlocked -Root $Root -Runtime $runtime }
            catch { Write-Host $_.Exception.Message -ForegroundColor Yellow }
            try { [void](Save-AetherisSecurityDiagnostics $Root) } catch {}
        } else {
            Write-Host '環境尚未就緒，先開啟環境下載與安裝頁。' -ForegroundColor Cyan
            if ($runtime -and $runtime.errors) { Write-Host ($runtime.errors -join '; ') -ForegroundColor Yellow }
        }
        $page = Join-Path $Root '環境下載.html'
        if (Test-Path -LiteralPath $page -PathType Leaf) {
            Start-Process -FilePath $page | Out-Null
        } else {
            Start-Process -FilePath 'https://ilmtts.github.io/aetheris-carousell/%E7%92%B0%E5%A2%83%E4%B8%8B%E8%BC%89.html?v=78-env3' | Out-Null
        }
        Write-Host '請按網頁指引安裝；完成後重新雙擊「啟動工具.bat」。' -ForegroundColor Cyan
        # Distinguish a successful handoff to setup from a failed app launch.
        exit 3
    }
    if (-not (Test-Path -LiteralPath (Join-Path $Root 'config.json'))) { Copy-Item -LiteralPath (Join-Path $Root 'config.example.json') -Destination (Join-Path $Root 'config.json') }
    $entry = Join-Path $Root 'carousell_publish.py'
    if (-not (Test-Path -LiteralPath $entry)) { throw '缺少 carousell_publish.py，請先完整解壓縮程序包。' }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    $stamp = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + $PID
    $stdout = Join-Path $logs ('startup-' + $stamp + '.log'); $stderr = Join-Path $logs ('startup-' + $stamp + '.error.log')
    # Keep exactly the executable validated above, without relying on pyw or
    # pythonw from PATH. Hidden console output is retained for diagnostics.
    $arguments = (ConvertTo-AetherisNativeArgument $entry) + ' --status-server'
    $process = Start-Process -FilePath $runtime.executable -ArgumentList $arguments -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    # Cache the handle before waiting: Windows PowerShell can otherwise lose
    # ExitCode when an existing dashboard makes the child exit immediately.
    $processHandle = $process.Handle
    if ($process.WaitForExit(1800) -and $process.ExitCode -ne 0) { throw ('工具啟動失敗。錯誤記錄：' + $stderr) }
    Write-Host '工具已啟動，正在開啟狀態網頁。' -ForegroundColor Green
    exit 0
} catch {
    try { [void](Save-AetherisSecurityDiagnostics $Root) } catch {}
    Write-Host ('啟動失敗：' + $_.Exception.Message) -ForegroundColor Red
    Write-Host '若 Windows 封鎖了元件，請查看 logs\windows-security.txt 及 assets\install-support.html。' -ForegroundColor Yellow
    exit 1
}
