﻿param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
try {
    . (Join-Path $Root 'runtime_environment.ps1')
    Initialize-AetherisEnvironment
    Set-Location -LiteralPath $Root
    $runtime = Get-AetherisProjectRuntime $Root
    if ($CheckOnly) {
        [pscustomobject]@{ ready=[bool]($runtime -and $runtime.ready); runtime=$runtime } | ConvertTo-Json -Depth 7
        if ($runtime -and $runtime.ready) { exit 0 }; exit 2
    }
    if (-not $runtime -or -not $runtime.ready) {
        Write-Host '正在修復本工具的獨立環境；完成後會自動啟動。' -ForegroundColor Cyan
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root '安裝環境.ps1')
        if ($LASTEXITCODE -ne 0) { throw '環境尚未安裝完成，請查看 logs\install.log。' }
        $runtime = Get-AetherisProjectRuntime $Root
    }
    if (-not $runtime -or -not $runtime.ready) { throw '安裝後仍未通過環境檢查，請查看 logs\install.log。' }
    if (-not (Test-Path -LiteralPath (Join-Path $Root 'config.json'))) { Copy-Item -LiteralPath (Join-Path $Root 'config.example.json') -Destination (Join-Path $Root 'config.json') }
    $entry = Join-Path $Root 'carousell_publish.py'
    if (-not (Test-Path -LiteralPath $entry)) { throw '缺少 carousell_publish.py，請先完整解壓縮程序包。' }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    $stamp = (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '-' + $PID
    $stdout = Join-Path $logs ('startup-' + $stamp + '.log'); $stderr = Join-Path $logs ('startup-' + $stamp + '.error.log')
    # Keep exactly the executable validated above, without relying on pyw or
    # pythonw from PATH. Hidden console output is retained for diagnostics.
    $arguments = (ConvertTo-AetherisNativeArgument $entry) + ' --status-server'
    $process = Start-Process -FilePath $runtime.executable -ArgumentList $arguments -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    # Cache the handle before waiting: Windows PowerShell can otherwise lose
    # ExitCode when an existing dashboard makes the child exit immediately.
    $processHandle = $process.Handle
    if ($process.WaitForExit(1800) -and $process.ExitCode -ne 0) { throw ('工具啟動失敗。錯誤記錄：' + $stderr) }
    Write-Host '工具已啟動，正在開啟狀態網頁。' -ForegroundColor Green
    exit 0
} catch {
    Write-Host ('啟動失敗：' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
