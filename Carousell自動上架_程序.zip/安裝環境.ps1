﻿param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$mutex = $null; $locked = $false; $transcribing = $false; $runtime = $null
try {
    . (Join-Path $Root 'runtime_environment.ps1')
    Initialize-AetherisEnvironment
    Set-Location -LiteralPath $Root
    $runtime = Get-AetherisProjectRuntime $Root
    if ($CheckOnly) {
        [pscustomobject]@{ ready=[bool]($runtime -and $runtime.ready); runtime=$runtime } | ConvertTo-Json -Depth 7
        if ($runtime -and $runtime.ready) { exit 0 }; exit 2
    }
    $digest = [Security.Cryptography.SHA256]::Create()
    try { $name = ([BitConverter]::ToString($digest.ComputeHash([Text.Encoding]::UTF8.GetBytes($Root.ToLowerInvariant())))).Replace('-', '').Substring(0,24) }
    finally { $digest.Dispose() }
    $mutex = New-Object Threading.Mutex($false, ('Local\AetherisSetup-' + $name))
    try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
    if (-not $locked) { throw '這個資料夾的環境正在安裝中，請等現有安裝完成。' }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    Start-Transcript -Path (Join-Path $logs 'install.log') -Append | Out-Null
    $transcribing = $true
    if (-not $runtime -or -not $runtime.python_ok) {
        $basePython = Find-AetherisBasePython
        if (-not $basePython) {
            $basePython = Install-AetherisStorePython $Root
        }
        if (-not $basePython) { throw '找不到 Python 3.13+。請從 Microsoft Store 安裝 Python 3.13 後再試。' }
        $venv = Join-Path $Root '.venv'
        if (Test-Path -LiteralPath $venv) {
            # A copied venv can retain an invalid path to another computer.
            $backup = '.venv.before-repair-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID
            Rename-Item -LiteralPath $venv -NewName $backup
            Write-Host ('舊環境無法使用，已保留為 ' + $backup) -ForegroundColor Yellow
        }
        Write-Host '[1/4] 建立本工具專用環境...' -ForegroundColor Cyan
        & $basePython.executable -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw '建立獨立 Python 環境失敗。' }
    }
    $python = Join-Path $Root '.venv\Scripts\python.exe'
    Write-Host ('使用 Python：' + $python)
    Write-Host '[2/4] 安裝必要套件...' -ForegroundColor Cyan
    & $python -m pip --version *> $null
    if ($LASTEXITCODE -ne 0) {
        & $python -m ensurepip --upgrade
        if ($LASTEXITCODE -ne 0) { throw '安裝 pip 失敗。' }
    }
    & $python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Python 套件安裝失敗，請查看 logs\install.log。' }
    Write-Host '[3/4] 檢查並安裝 Chromium...' -ForegroundColor Cyan
    $runtime = Get-AetherisProjectRuntime $Root
    if (-not $runtime -or -not $runtime.ready) {
        & $python -m playwright install chromium
        if ($LASTEXITCODE -ne 0) { throw 'Chromium 下載失敗，請查看 logs\install.log。' }
    }
    foreach ($folder in @('待發布', '已完成檔案', '已刪除檔案', '已整理圖片')) { [void](New-Item -ItemType Directory -Force -Path (Join-Path $Root $folder)) }
    if (-not (Test-Path -LiteralPath (Join-Path $Root 'config.json'))) { Copy-Item -LiteralPath (Join-Path $Root 'config.example.json') -Destination (Join-Path $Root 'config.json') }
    Write-Host '[4/4] 使用啟動工具相同的檢查方式驗證...' -ForegroundColor Cyan
    $runtime = Get-AetherisProjectRuntime $Root
    if (-not $runtime -or -not $runtime.ready) {
        $details = if ($runtime) { $runtime.errors -join '; ' } else { 'Python 無法啟動。' }
        throw ('環境檢查未通過：' + $details)
    }
    Write-AetherisInstallResult -Root $Root -Success $true -Runtime $runtime -Message 'Environment ready; installer and launcher use the same executable.'
    Write-Host ('驗證成功：Python ' + $runtime.version + '、Pillow ' + $runtime.pillow + '、Playwright ' + $runtime.playwright + '、Chromium。') -ForegroundColor Green
    Write-Host '環境安裝完成。請雙擊「啟動工具.bat」，不需要重新啟動電腦。' -ForegroundColor Green
    exit 0
} catch {
    $message = $_.Exception.Message
    try { [void](Save-AetherisSecurityDiagnostics $Root) } catch {}
    try { Write-AetherisInstallResult -Root $Root -Success $false -Runtime $runtime -Message $message } catch {}
    Write-Host ('安裝未完成：' + $message) -ForegroundColor Red
    Write-Host '安裝記錄：logs\install.log。只看到「下載完成」並不代表已通過驗證。' -ForegroundColor Yellow
    Write-Host 'Windows 封鎖記錄：logs\windows-security.txt；說明：assets\install-support.html。' -ForegroundColor Yellow
    exit 1
} finally {
    if ($transcribing) { Stop-Transcript | Out-Null }
    if ($locked) { $mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
}
