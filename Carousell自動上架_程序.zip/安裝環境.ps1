﻿param([switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$mutex = $null; $locked = $false; $transcribing = $false; $runtime = $null
try {
    . (Join-Path $Root 'runtime_environment.ps1')
    Initialize-AetherisEnvironment
    Set-Location -LiteralPath $Root
    $runtime = Get-AetherisProjectRuntime $Root
    if ($CheckOnly) {
        [pscustomobject]@{ ready=[bool]($runtime -and $runtime.ready); runtime=$runtime } | ConvertTo-Json -Depth 7
        if ($runtime -and $runtime.ready) { exit 0 }; exit 2
    }
    $digest = [Security.Cryptography.SHA256]::Create()
    try { $name = ([BitConverter]::ToString($digest.ComputeHash([Text.Encoding]::UTF8.GetBytes($Root.ToLowerInvariant())))).Replace('-', '').Substring(0,24) }
    finally { $digest.Dispose() }
    $mutex = New-Object Threading.Mutex($false, ('Local\AetherisSetup-' + $name))
    try { $locked = $mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $locked = $true }
    if (-not $locked) { throw '這個資料夾的環境正在安裝中，請等現有安裝完成。' }
    $logs = Join-Path $Root 'logs'; [void](New-Item -ItemType Directory -Path $logs -Force)
    Start-Transcript -Path (Join-Path $logs 'install.log') -Append | Out-Null
    $transcribing = $true
    if (-not $runtime -or -not $runtime.python_ok) {
        $basePython = Find-AetherisBasePython
        if (-not $basePython) {
            $winget = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($winget) {
                Write-Host '正在安裝 Python 3.13（目前使用者）...' -ForegroundColor Cyan
                & $winget.Source install --id Python.Python.3.13 -e --source winget --scope user --silent --accept-source-agreements --accept-package-agreements --disable-interactivity
                Update-AetherisProcessPath
                $basePython = Find-AetherisBasePython
            }
        }
        if (-not $basePython) {
            # Official signed per-user fallback; never run an unsigned download.
            $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64' -or $env:PROCESSOR_ARCHITEW6432 -eq 'ARM64') { 'arm64' } elseif ([Environment]::Is64BitOperatingSystem) { 'amd64' } else { 'win32' }
            $suffix = if ($arch -eq 'win32') { '' } else { '-' + $arch }
            $filename = 'python-3.13.17' + $suffix + '.exe'; $installer = Join-Path $logs $filename
            Write-Host '正在從 Python 官方網站下載安裝程式...' -ForegroundColor Cyan
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri ('https://www.python.org/ftp/python/3.13.17/' + $filename) -OutFile $installer -UseBasicParsing
            $signature = Get-AuthenticodeSignature -LiteralPath $installer
            if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') { throw 'Python 安裝檔未通過官方數位簽章驗證，已停止安裝。' }
            $installed = Start-Process -FilePath $installer -ArgumentList '/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0 Include_launcher=1 InstallLauncherAllUsers=0' -Wait -PassThru -WindowStyle Hidden
            if ($installed.ExitCode -notin @(0,3010)) { throw ('Python 安裝失敗，代碼：' + $installed.ExitCode) }
            Update-AetherisProcessPath
            $basePython = Find-AetherisBasePython
        }
        if (-not $basePython) { throw '找不到 Python 3.13+。手動下載：https://www.python.org/downloads/windows/' }
        $venv = Join-Path $Root '.venv'
        if (Test-Path -LiteralPath $venv) {
            # A copied venv can retain an invalid path to another computer.
            $backup = '.venv.before-repair-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + $PID
            Rename-Item -LiteralPath $venv -NewName $backup
            Write-Host ('舊環境無法使用，已保留為 ' + $backup) -ForegroundColor Yellow
        }
        Write-Host '[1/4] 建立本工具專用環境...' -ForegroundColor Cyan
        & $basePython.executable -m venv $venv
        if ($LASTEXITCODE -ne 0) { throw '建立獨立 Python 環境失敗。' }
    }
    $python = Join-Path $Root '.venv\Scripts\python.exe'
    Write-Host ('使用 Python：' + $python)
    Write-Host '[2/4] 安裝必要套件...' -ForegroundColor Cyan
    & $python -m pip --version *> $null
    if ($LASTEXITCODE -ne 0) {
        & $python -m ensurepip --upgrade
        if ($LASTEXITCODE -ne 0) { throw '安裝 pip 失敗。' }
    }
    & $python -m pip install --disable-pip-version-check -r (Join-Path $Root 'requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Python 套件安裝失敗，請查看 logs\install.log。' }
    Write-Host '[3/4] 檢查並安裝 Chromium...' -ForegroundColor Cyan
    $runtime = Get-AetherisProjectRuntime $Root
    if (-not $runtime -or -not $runtime.ready) {
        & $python -m playwright install chromium
        if ($LASTEXITCODE -ne 0) { throw 'Chromium 下載失敗，請查看 logs\install.log。' }
    }
    foreach ($folder in @('待發布', '已完成檔案', '已刪除檔案', '已整理圖片')) { [void](New-Item -ItemType Directory -Force -Path (Join-Path $Root $folder)) }
    if (-not (Test-Path -LiteralPath (Join-Path $Root 'config.json'))) { Copy-Item -LiteralPath (Join-Path $Root 'config.example.json') -Destination (Join-Path $Root 'config.json') }
    Write-Host '[4/4] 使用啟動工具相同的檢查方式驗證...' -ForegroundColor Cyan
    $runtime = Get-AetherisProjectRuntime $Root
    if (-not $runtime -or -not $runtime.ready) {
        $details = if ($runtime) { $runtime.errors -join '; ' } else { 'Python 無法啟動。' }
        throw ('環境檢查未通過：' + $details)
    }
    Write-AetherisInstallResult -Root $Root -Success $true -Runtime $runtime -Message 'Environment ready; installer and launcher use the same executable.'
    Write-Host ('驗證成功：Python ' + $runtime.version + '、Pillow ' + $runtime.pillow + '、Playwright ' + $runtime.playwright + '、Chromium。') -ForegroundColor Green
    Write-Host '環境安裝完成。請雙擊「啟動工具.bat」，不需要重新啟動電腦。' -ForegroundColor Green
    exit 0
} catch {
    $message = $_.Exception.Message
    try { Write-AetherisInstallResult -Root $Root -Success $false -Runtime $runtime -Message $message } catch {}
    Write-Host ('安裝未完成：' + $message) -ForegroundColor Red
    Write-Host '安裝記錄：logs\install.log。只看到「下載完成」並不代表已通過驗證。' -ForegroundColor Yellow
    exit 1
} finally {
    if ($transcribing) { Stop-Transcript | Out-Null }
    if ($locked) { $mutex.ReleaseMutex() }
    if ($mutex) { $mutex.Dispose() }
}
