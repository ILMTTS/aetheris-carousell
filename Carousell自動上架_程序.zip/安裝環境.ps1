﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root

function Test-Python([string]$Command, [string[]]$Prefix) {
    $arguments = @($Prefix) + @('-c', 'import sys; raise SystemExit(0 if sys.version_info >= (3, 13) else 1)')
    & $Command @arguments *> $null
    return $LASTEXITCODE -eq 0
}

$Launcher = Get-Command py -ErrorAction SilentlyContinue
$PythonCommand = $null
$PythonPrefix = @()
if ($Launcher -and (Test-Python $Launcher.Source @('-3.13'))) {
    $PythonCommand = $Launcher.Source
    $PythonPrefix = @('-3.13')
} elseif ($Launcher -and (Test-Python $Launcher.Source @())) {
    $PythonCommand = $Launcher.Source
} else {
    $Python = Get-Command python -ErrorAction SilentlyContinue
    if ($Python -and (Test-Python $Python.Source @())) { $PythonCommand = $Python.Source }
}

if (-not $PythonCommand) {
    $Winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $Winget) {
        Write-Host '找不到 Python 3.13+ 和 winget。請從 https://www.python.org/downloads/windows/ 手動安裝 Python。' -ForegroundColor Yellow
        exit 1
    }
    Write-Host '正在下載並安裝 Python 3.13...' -ForegroundColor Cyan
    & $Winget.Source install --id Python.Python.3.13 -e --source winget --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { throw 'Python 安裝失敗。' }
    $Launcher = Get-Command py -ErrorAction SilentlyContinue
    if ($Launcher -and (Test-Python $Launcher.Source @('-3.13'))) {
        $PythonCommand = $Launcher.Source
        $PythonPrefix = @('-3.13')
    }
}
if (-not $PythonCommand) { throw '找不到可用的 Python 3.13+，請重新執行安裝程式。' }

$Venv = Join-Path $Root '.venv'
Write-Host '[1/3] 建立獨立 Python 環境...' -ForegroundColor Cyan
$VenvArguments = @($PythonPrefix) + @('-m', 'venv', $Venv)
& $PythonCommand @VenvArguments
if ($LASTEXITCODE -ne 0) { throw '建立 Python 環境失敗。' }
$VenvPython = Join-Path $Venv 'Scripts\python.exe'

Write-Host '[2/3] 安裝 Pillow 和 Playwright...' -ForegroundColor Cyan
& $VenvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw '更新 pip 失敗。' }
& $VenvPython -m pip install -r (Join-Path $Root 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw '安裝 Python 套件失敗。' }

Write-Host '[3/3] 下載 Chromium 瀏覽器元件...' -ForegroundColor Cyan
& $VenvPython -m playwright install chromium
if ($LASTEXITCODE -ne 0) { throw '安裝 Chromium 失敗。' }

foreach ($Folder in @('待發布', '已完成檔案', '已刪除檔案', '已整理圖片')) {
    New-Item -ItemType Directory -Force -Path (Join-Path $Root $Folder) | Out-Null
}
if ((-not (Test-Path (Join-Path $Root 'config.json'))) -and (Test-Path (Join-Path $Root 'config.example.json'))) {
    Copy-Item (Join-Path $Root 'config.example.json') (Join-Path $Root 'config.json')
}
& $VenvPython -c "import PIL,playwright"
if ($LASTEXITCODE -ne 0) { throw '安裝後檢查失敗，請重新執行一鍵安裝。' }
Write-Host '環境安裝完成，可以雙擊「啟動工具.bat」。' -ForegroundColor Green
