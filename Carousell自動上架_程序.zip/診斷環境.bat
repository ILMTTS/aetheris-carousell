@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title Aetheris 環境診斷
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
echo 此工具只檢查及儲存本機報告，不會安裝套件或改動 Windows 防護。
if not exist "%~dp0.venv\Scripts\python.exe" goto no_python
"%~dp0.venv\Scripts\python.exe" -I -B "%~dp0diagnose_environment.py" --root "%~dp0." --open-report
if "%errorlevel%"=="0" goto end
echo Python 診斷無法完成，正在讀取 Windows 封鎖記錄。
:no_python
if not exist "%~dp0logs" mkdir "%~dp0logs"
echo Aetheris diagnostic fallback - Python could not complete diagnosis.>"%~dp0logs\diagnosis-without-python.txt"
echo This report is local only and can contain local file paths.>>"%~dp0logs\diagnosis-without-python.txt"
"%SystemRoot%\System32\wevtutil.exe" qe Microsoft-Windows-CodeIntegrity/Operational /q:"*[System[(EventID=3077 or EventID=3033) and TimeCreated[timediff(@SystemTime) <= 604800000]]]" /c:40 /rd:true /f:text >>"%~dp0logs\diagnosis-without-python.txt" 2>&1
echo 報告：logs\diagnosis-without-python.txt
start "" notepad.exe "%~dp0logs\diagnosis-without-python.txt"
:end
echo.
echo 請在發生錯誤的電腦執行。報告不會自動上傳。
pause
