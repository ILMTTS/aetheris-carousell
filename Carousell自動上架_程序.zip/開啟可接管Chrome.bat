@echo off
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"
set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" (
    echo 找不到 Google Chrome。
    pause
    exit /b 1
)
start "Carousell Chrome" "%CHROME%" --remote-debugging-port=9222 --user-data-dir="%~dp0chrome_attach_profile" --window-size=1280,900 "https://www.carousell.com.hk/sell"
echo 已開啟可接管的普通 Chrome。
echo 登入 Carousell 後，回到「啟動工具.bat」選擇 4。
